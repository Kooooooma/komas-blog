export default {
    CHUNK_SIZE: 3 * 1024 * 1024, // 3MB
    BACKEND_URL: 'http://localhost:3300',
    PORT: 3302,
    EVENT_TYPE: {
        PING: 'PING',
        PONG: 'PONG',
        RECORD: 'RECORD',
        RUN: 'RUN',
        LANE_RUN: 'LANE_RUN',
        RECORD_FINISHED: 'RECORD_FINISHED',
        EXECUTION_FINISHED: 'EXECUTION_FINISHED',
        LANE_EXECUTION_FINISHED: 'LANE_EXECUTION_FINISHED'
    },
    RUN_TIMEOUT_MS: 3_600_000
};
