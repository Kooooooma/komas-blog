# How to use

1. Start the bridge
```bash
npm run start
```

2. Support configuration(reference config.js)
```bash
# Backend URL
BACKEND_URL=http://localhost:3301

# PORT
PORT=3302

# BROWSER_EXECUTABLE_PATH
BROWSER_EXECUTABLE_PATH=/path/to/chrome
```
