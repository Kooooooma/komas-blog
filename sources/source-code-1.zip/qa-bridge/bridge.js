import express from 'express';
import axios from 'axios';
import { chromium } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { randomUUID } from 'crypto';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import config from './config.js';
import dotenv from 'dotenv';

// Global exception capture
process.on('uncaughtException', (error) => {
    console.error('❌ Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

// Initialize paths
const projectRoot = dirname(fileURLToPath(import.meta.url));
const tmpDir = path.join(projectRoot, '.tmp');
const testSpecDir = path.join(tmpDir, 'tests');
const reportsDir = path.join(tmpDir, 'reports');

if (!fs.existsSync(tmpDir)) {
    fs.mkdirSync(tmpDir);
}

if (!fs.existsSync(testSpecDir)) {
    fs.mkdirSync(testSpecDir);
}

if (!fs.existsSync(reportsDir)) {
    fs.mkdirSync(reportsDir);
}

dotenv.config({ path: path.resolve(projectRoot, '.env') });

const app = express();

// Persist BRIDGE_UUID in .env
let BRIDGE_UUID = process.env.BRIDGE_UUID;
if (!BRIDGE_UUID) {
    BRIDGE_UUID = randomUUID();
    console.log(`✨ Generating new Bridge UUID: ${BRIDGE_UUID}`);
    const envPath = path.resolve(projectRoot, '.env');
    const envContent = `\nBRIDGE_UUID=${BRIDGE_UUID}\n`;
    fs.appendFileSync(envPath, envContent);
}

function startBridge() {
    console.log('='.repeat(60));
    console.log(`🔑 Bridge UUID: ${BRIDGE_UUID}`);
    console.log('='.repeat(60));
    console.log('📢 Please enter this UUID in the E2E page to connect.');
    console.log(`📢 Config: Browser=${config.BROWSER_EXECUTABLE_PATH || 'default'}, Timeout=${config.RUN_TIMEOUT_MS}ms`);
    console.log('='.repeat(60));

    app.listen(config.PORT, () => {
        console.log(`🚀 Bridge server running on port ${config.PORT}`);
        connectToBackend();
    });
}

function connectToBackend() {
    console.log('📢 Connecting to backend with UUID:', BRIDGE_UUID);
    axios({
        method: 'get',
        url: `${config.BACKEND_URL}/api/bridge/register?source=bridge&bridgeUuid=${BRIDGE_UUID}`,
        responseType: 'stream'
    }).then(response => {
        console.log('📢 Connected to backend');
        const stream = response.data;

        stream.on('data', (chunk) => {
            const dataStr = chunk.toString();
            try {
                const lines = dataStr.split('\n').filter(line => line.trim() !== '');
                lines.forEach(line => {
                    try {
                        let jsonStr = line;
                        if (line.startsWith('data:')) {
                            jsonStr = line.substring(5).trim();
                        }
                        if (!jsonStr) return;

                        const event = JSON.parse(jsonStr);
                        console.log('📢 Parsed event:', event);

                        if (event.eventType === config.EVENT_TYPE.PING) {
                            handlePingEvent();
                        } else if (event.eventType === config.EVENT_TYPE.RECORD) {
                            handleRecordEvent(event).catch(err => {
                                console.error('❌ Record error:', err);
                            });
                        } else if (event.eventType === config.EVENT_TYPE.RUN) {
                            handleRunEvent(event, config.EVENT_TYPE.RUN).catch(err => {
                                console.error('❌ Run error:', err);
                            });
                        } else if (event.eventType === config.EVENT_TYPE.LANE_RUN) {
                            handleRunEvent(event, config.EVENT_TYPE.LANE_RUN).catch(err => {
                                console.error('❌ Lane run error:', err);
                            });
                        }
                    } catch (e) {
                        // ignore parse errors for non-JSON lines
                    }
                });
            } catch (error) {
                console.error('❌ Error parsing event data:', error);
            }
        });

        stream.on('end', () => {
            console.log('❌ Connection ended, reconnecting in 5 seconds...');
            setTimeout(connectToBackend, 5000);
        });

        stream.on('error', (err) => {
            console.error('❌ Stream error:', err);
            setTimeout(connectToBackend, 5000);
        });

    }).catch(err => {
        console.error('❌ Connection failed:', err.message);
        setTimeout(connectToBackend, 5000);
    });
}

async function handleRecordEvent(event) {
    console.log('📢 Received record event:', event);
    const { url } = event.eventPayload;
    console.log(`📢 Starting record for URL: ${url}`);
    const tmpScriptFile = path.join(tmpDir, randomUUID() + '.js');

    let browser;
    let isFinished = false;
    let isError = false;

    const finishRecording = async (message) => {
        console.log(`📢 Recording finished with status: ${isError ? 'failed' : 'success'}, message: ${message}`);
        if (isFinished) return;
        isFinished = true;

        let finalCode;
        if (!isError && fs.existsSync(tmpScriptFile)) {
            finalCode = fs.readFileSync(tmpScriptFile, 'utf-8');
            if (finalCode.trim().length === 0) {
                finalCode = "No code generated";
            }
        }

        await notifyBackend({
            eventType: config.EVENT_TYPE.RECORD_FINISHED,
            eventStatus: isError ? 'failed' : 'success',
            bridgeUuid: BRIDGE_UUID,
            message: message,
            eventPayload: { script: finalCode || "No code generated" }
        });

        try {
            if (fs.existsSync(tmpScriptFile)) {
                fs.unlinkSync(tmpScriptFile);
                console.log('📢 Cleaned up temp file:', tmpScriptFile);
            }
        } catch (err) {
            console.error('❌ Failed to clean up temp file:', err);
        }
    };

    try {
        browser = await chromium.launch({
            channel: 'msedge',
            headless: false,
            args: ['--start-maximized'],
            slowMo: 500
        });

        browser.on('disconnected', () => {
            console.log('📢 Browser disconnected, recording finished');
        });
    } catch (error) {
        isError = true;
        console.error('❌ Error launching browser:', error);
        return await finishRecording('Bridge failed to launch browser: ' + error.message);
    }

    try {
        const context = await browser.newContext({
            viewport: null
        });

        await context._enableRecorder({
            language: 'playwright-test',
            outputFile: tmpScriptFile,
            mode: 'recording'
        });

        context.on('close', () => {
            console.log('📢 Context closed, recording finished');
        });

        context.on('weberror', async err => {
            console.error('❌ Context weberror:', err);
            // isError = true;
            // context.close();
            // browser.close();
            // await finishRecording('Context weberror: ' + err.failure().errorText);
        })

        context.on('requestfailed', async err => {
            console.error('❌ Context requestfailed:', err);
            // isError = true;
            // context.close();
            // browser.close();
            // await finishRecording('Context requestfailed: ' + err.failure().errorText);
        })

        const page = await context.newPage();

        page.on('close', async () => {
            console.log('📢 Page closed, recording finished');
            context.close();
            browser.close();
            await finishRecording('Page closed, recording finished');
        });

        page.on('error', async err => {
            console.error('❌ Page error:', err);
            // isError = true;
            // context.close();
            // browser.close();
            // await finishRecording('Page error: ' + err.failure().errorText);
        });

        page.on('requestfailed', async err => {
            console.log('❌ Page requestfailed:' + err);
            // isError = true;
            // context.close();
            // browser.close();
            // await finishRecording('Page requestfailed: ' + err.failure().errorText);
        });

        page.on('pageerror', async err => {
            console.log('❌ Page pageerror:' + err);
            // isError = true;
            // context.close();
            // browser.close();
            // await finishRecording('Page pageerror: ' + err.failure().errorText);
        });

        page.on('crash', async err => {
            console.error('❌ Page crashed:', err);
            isError = true;
            context.close();
            browser.close();
            await finishRecording('Page crash: ' + err.failure().errorText);
        })

        await page.goto(url);
    } catch (error) {
        isError = true;
        console.error('❌ Error during recording session:', error);
        await finishRecording('Error during recording session: ' + error.message);
    }
}

function handleRunEvent(event, type) {
    console.log(`📢 Received run event: ${JSON.stringify(event)}, type: ${type}`);
    const { testCaseId, executionId, script, headless } = event.eventPayload;
    console.log(`📢 Received run request for execution ${executionId}`);

    const testFilePath = path.join(testSpecDir, `${executionId}.spec.js`);
    fs.writeFileSync(testFilePath, script);

    const executionReportDir = path.join(reportsDir, executionId);
    if (!fs.existsSync(executionReportDir)) {
        fs.mkdirSync(executionReportDir, { recursive: true });
    }

    const runEnv = {
        ...process.env,
        PLAYWRIGHT_HTML_REPORT: executionReportDir
    };

    console.log(`📢 Executing test: ${testFilePath}`);
    console.log(`📢 Report will be saved to: ${executionReportDir}`);

    const playwrightArgs = [
        'playwright',
        'test',
        `${executionId}.spec.js`
    ];

    if (String(headless).toLowerCase() === 'false') {
        playwrightArgs.push('--headed');
    }

    const runProcess = spawn('npx', playwrightArgs, {
        env: runEnv,
        shell: true,
        cwd: projectRoot
    });

    let stdout = '';
    let stderr = '';
    let isFinished = false;

    const timeout = setTimeout(() => {
        console.error('❌ Test execution timeout');
        runProcess.kill('SIGKILL');

        notifyBackend({
            eventType: config.EVENT_TYPE.LANE_RUN === type ? config.EVENT_TYPE.LANE_EXECUTION_FINISHED : config.EVENT_TYPE.EXECUTION_FINISHED,
            eventStatus: 'failed',
            bridgeUuid: BRIDGE_UUID,
            message: 'Test execution timeout',
            eventPayload: {
                executionId: executionId,
                testCaseId: testCaseId,
                executionLogs: stdout + '\n' + stderr + '\n\n[TIMEOUT AFTER ' + (config.RUN_TIMEOUT_MS / 1000) + 's]'
            }
        }, config.EVENT_TYPE.LANE_RUN === type ? 'lane' : 'user');

    }, config.RUN_TIMEOUT_MS);

    runProcess.stdout.on('data', (data) => {
        stdout += '\n' + data.toString();
        console.log('📢 stdout:', data.toString());
    });

    runProcess.stderr.on('data', (data) => {
        stderr += '\n' + data.toString();
        console.error('❌ stderr:', data.toString());
    });

    runProcess.on('error', (error) => {
        clearTimeout(timeout);
        console.error('❌ Spawn error:', error);
        if (isFinished) return;
        isFinished = true;

        notifyBackend({
            eventType: config.EVENT_TYPE.LANE_RUN === type ? config.EVENT_TYPE.LANE_EXECUTION_FINISHED : config.EVENT_TYPE.EXECUTION_FINISHED,
            eventStatus: 'failed',
            bridgeUuid: BRIDGE_UUID,
            message: "Test case run failed in a spawn error: " + error.message,
            eventPayload: {
                executionId: executionId,
                testCaseId: testCaseId,
                executionLogs: stdout + '\n' + stderr
            }
        }, config.EVENT_TYPE.LANE_RUN === type ? 'lane' : 'user');
    });

    runProcess.on('close', async (code) => {
        clearTimeout(timeout);
        console.log(`📢 Test finished with code: ${code}`);
        if (isFinished) return;
        isFinished = true;

        const reportIndexPath = path.join(executionReportDir, 'index.html');
        let reportContent = '';
        if (fs.existsSync(reportIndexPath)) {
            reportContent = fs.readFileSync(reportIndexPath, 'utf-8');
        }

        let executionStatus = 'success';
        if (code !== 0) {
            executionStatus = 'failed';
        }

        notifyBackend({
            eventType: config.EVENT_TYPE.LANE_RUN === type ? config.EVENT_TYPE.LANE_EXECUTION_FINISHED : config.EVENT_TYPE.EXECUTION_FINISHED,
            eventStatus: executionStatus,
            bridgeUuid: BRIDGE_UUID,
            message: "Test case run finished",
            eventPayload: {
                reportContent: reportContent,
                executionLogs: stdout + '\n' + stderr,
                executionId: executionId,
                testCaseId: testCaseId
            }
        }, config.EVENT_TYPE.LANE_RUN === type ? 'lane' : 'user');
    });
}

function handlePingEvent() {
    console.log('📢 Received ping, sending pong...');
    notifyBackend({
        eventType: config.EVENT_TYPE.PONG,
        bridgeUuid: BRIDGE_UUID
    });
}

async function notifyBackend(payload, type = 'user', retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            await axios.post(`${config.BACKEND_URL}/api/bridge/notify/${type}`, payload, {
                maxContentLength: 10 * 1024 * 1024,
                maxBodyLength: 10 * 1024 * 1024
            });
            console.log(`📢 Notification sent, eventType: ${payload.eventType}, notifyType: ${type}`);
            return;
        } catch (err) {
            console.error(`❌ Attempt ${i + 1}/${retries} failed for ${payload.eventType}`);
            logError(err);

            if (i === retries - 1) {
                console.error('❌ All retries exhausted');
                return;
            }

            // Exponential backoff
            await new Promise(r => setTimeout(r, 1000 * (i + 1)));
        }
    }
}

function logError(err) {
    console.error('❌   URL:', err.config?.url);
    console.error('❌   Method:', err.config?.method?.toUpperCase());
    console.error('❌   Status:', err.response?.status);
    console.error('❌   StatusText:', err.response?.statusText);
    if (err.response?.data) {
        console.error('❌   Response Data:', JSON.stringify(err.response.data, null, 2));
    }
    console.error('❌   Message:', err.message);
}

startBridge();
