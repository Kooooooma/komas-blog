import { defineConfig } from '@playwright/test';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

/**
 * Read environment variables from file.
 * https://github.com/motdotla/dotenv
 */
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
dotenv.config({ path: path.resolve(__dirname, '.env') });

/**
 * See https://playwright.dev/docs/test-configuration.
 */
export default defineConfig({
  testDir: './.tmp/tests',
  outputDir: './.tmp/tests-results',
  fullyParallel: true,
  retries: 0,
  workers: 1,
  reporter: [
    ['html', {
      open: 'never'
    }],
    ['list']
  ],
  timeout: 3_600_000, // 1 hours for each test
  use: {
    navigationTimeout: 300_000, // 5 minutes for navigation
    actionTimeout: 300_000, // 5 minutes for actions
    browserName: 'chromium',
    channel: 'msedge',
    launchOptions: {
      args: ['--start-maximized'],
      slowMo: 1000,
      ...(process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ? { executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH } : {}),
    },
    trace: 'on-first-retry',
    video: 'on-first-retry',
    viewport: null,
  }
});
