# QA Agent System

> 🚀 Java Agent 框架，支持模块化 agent 加载、生命周期管理和 SLF4J 日志

## 📋 目录

- [架构概览](#架构概览)
- [功能特性](#功能特性)
- [快速开始](#快速开始)
- [模块说明](#模块说明)
- [配置指南](#配置指南)
- [实现新 Agent](#实现新-agent)
- [API 文档](#api-文档)
- [最佳实践](#最佳实践)

## 🏗️ 架构概览

```
qa-agent/
├── agent-api/          # 公共 API 模块（Agent 接口和 AgentState）
├── agent-boot/         # Agent 加载器和生命周期管理
└── jms-agent/         # JMS 监控 Agent（参考实现）
```

### 依赖关系

```
agent-boot  ──depends on──> agent-api
    ↓
 loads & manages
    ↓
jms-agent   ──depends on──> agent-api
```

## ✨ 功能特性

### 核心特性

- ✅ **标准化 Agent 接口** - 基于 `Agent` 接口的统一规范
- ✅ **动态加载机制** - 通过配置文件动态加载多个 agent
- ✅ **生命周期管理** - 支持 start/stop/restart 操作
- ✅ **状态跟踪** - STOPPED/RUNNING/FAILED 状态管理
- ✅ **SLF4J 日志** - 专业日志框架，可配置日志级别
- ✅ **线程安全** - AgentContext 使用 ConcurrentHashMap

### JMS Agent 功能

- 监控 Spring `JmsTemplate.send()` 方法
- 记录 Topic/Queue 名称
- 记录 ConnectionFactory 信息
- 支持启用/禁用控制

## 🚀 快速开始

### 1. 构建项目

```bash
cd qa-agent
mvn clean package -DskipTests
```

### 2. 配置 Agent

创建 `agent-config.properties`：

```properties
# 要加载的 agent 列表（逗号分隔）
agents=jms-agent

# JMS Agent 配置
agent.jms-agent.path=./jms-agent/target/jms-agent-0.0.1-SNAPSHOT.jar
agent.jms-agent.class=com.kooooooma.agent.jms.JmsAgent
```

### 3. 启动应用

```bash
java -javaagent:agent-boot/target/agent-boot-0.0.1-SNAPSHOT.jar \
     -jar your-application.jar
```

或使用自定义配置路径：

```bash
java -javaagent:agent-boot/target/agent-boot-0.0.1-SNAPSHOT.jar=configPath=./custom-config.properties \
     -jar your-application.jar
```

### 4. 查看日志

```
19:51:28.123 INFO  [Agent-Boot] Starting Agent Boot Loader
19:51:29.345 INFO  [Agent-Boot] Agent implements Agent interface, calling start()
19:51:29.456 INFO  [JMS-Agent] Starting JMS monitoring agent
19:51:29.567 INFO  [JMS-Agent] Successfully registered JmsTemplate transformer
19:51:29.890 INFO  [Agent-Boot] Registered agent: jms-agent
19:51:29.901 INFO  [Agent-Boot] Agent loading complete
19:51:29.912 INFO  [Agent-Boot]   Success: 1
```

## 📦 模块说明

### agent-api

**职责**: 定义公共接口和数据结构

**关键类**:
- `Agent` - Agent 标准接口
- `AgentState` - Agent 状态枚举

**依赖**: 无外部依赖

### agent-boot

**职责**: Agent 加载器和生命周期管理器

**关键组件**:

| 类 | 说明 |
|---|---|
| `AgentMain` | 入口点，解析配置并启动 agent |
| `AgentLoader` | 动态加载 agent JAR 并实例化 |
| `AgentConfig` | 配置文件解析器 |
| `AgentContext` | Agent 注册表（单例） |
| `AgentLifecycleManager` | 生命周期管理（start/stop/restart） |
| `AgentInstance` | Agent 实例包装类 |
| `AgentLogger` | SLF4J 日志工具 |

**依赖**: agent-api, SLF4J, Logback, ByteBuddy

### jms-agent

**职责**: JMS 监控参考实现

**关键组件**:
- `JmsAgent` - 实现 Agent 接口
- `JmsTemplateTransformer` - ByteBuddy 转换器
- `JmsTemplateInterceptor` - 方法拦截器

**依赖**: agent-api, SLF4J, ByteBuddy, JMS API

## ⚙️ 配置指南

### agent-config.properties 格式

```properties
# 全局配置
agents=agent1,agent2,agent3

# Agent 1 配置
agent.agent1.path=/path/to/agent1.jar     # JAR 路径（支持相对路径）
agent.agent1.class=com.example.Agent1      # 完全限定类名

# Agent 2 配置
agent.agent2.path=./relative/path/agent2.jar
agent.agent2.class=com.example.Agent2
```

### 路径规则

- **绝对路径**: `D:\agents\my-agent.jar` 或 `/opt/agents/my-agent.jar`
- **相对路径**: 相对于配置文件所在目录
  - `./agent.jar` - 配置文件同目录
  - `../lib/agent.jar` - 配置文件上级目录的 lib 子目录

### Logback 配置

编辑 `agent-boot/src/main/resources/logback.xml`:

```xml
<configuration>
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder>
            <pattern>%d{HH:mm:ss.SSS} %-5level %msg%n</pattern>
        </encoder>
    </appender>
    
    <!-- 设置日志级别: TRACE, DEBUG, INFO, WARN, ERROR -->
    <root level="INFO">
        <appender-ref ref="CONSOLE" />
    </root>
</configuration>
```

## 🔨 实现新 Agent

### Step 1: 创建 Maven 模块

在 `qa-agent/pom.xml` 添加新模块：

```xml
<modules>
    <module>agent-api</module>
    <module>agent-boot</module>
    <module>jms-agent</module>
    <module>my-agent</module>  <!-- 新增 -->
</modules>
```

### Step 2: 创建 POM

`my-agent/pom.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 
         http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>com.kooooooma.agent</groupId>
        <artifactId>qa-agent</artifactId>
        <version>0.0.1-SNAPSHOT</version>
    </parent>

    <artifactId>my-agent</artifactId>

    <dependencies>
        <!-- 必须依赖 agent-api -->
        <dependency>
            <groupId>com.kooooooma.agent</groupId>
            <artifactId>agent-api</artifactId>
            <version>${project.version}</version>
        </dependency>
        
        <!-- 添加其他需要的依赖 -->
    </dependencies>

    <build>
        <plugins>
            <!-- Maven Shade Plugin 打包 Fat JAR -->
            <!-- 注意：jms-agent 是普通 JAR，不是 javaagent -->
            <!-- 不需要配置 Premain-Class 或 Agent-Class -->
            <plugin>
                <groupId>org.apache.maven.plugins</groupId>
                <artifactId>maven-shade-plugin</artifactId>
                <version>3.5.0</version>
                <executions>
                    <execution>
                        <phase>package</phase>
                        <goals>
                            <goal>shade</goal>
                        </goals>
                        <configuration>
                            <!-- 打包所有依赖，避免与目标 JVM 冲突 -->
                            <createDependencyReducedPom>false</createDependencyReducedPom>
                            
                            <!-- 过滤签名文件 -->
                            <filters>
                                <filter>
                                    <artifact>*:*</artifact>
                                    <excludes>
                                        <exclude>META-INF/*.SF</exclude>
                                        <exclude>META-INF/*.DSA</exclude>
                                        <exclude>META-INF/*.RSA</exclude>
                                    </excludes>
                                </filter>
                            </filters>
                        </configuration>
                    </execution>
                </executions>
            </plugin>
        </plugins>
    </build>
</project>
```

### Step 3: 实现 Agent 接口

`my-agent/src/main/java/com/example/MyAgent.java`:

```java
package com.example;

import com.kooooooma.agent.api.Agent;
import com.kooooooma.agent.api.AgentState;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.lang.instrument.Instrumentation;

/**
 * My Custom Agent
 */
public class MyAgent implements Agent {
    
    private static final Logger logger = LoggerFactory.getLogger(MyAgent.class);
    private static final String AGENT_NAME = "my-agent";
    
    private static AgentState currentState = AgentState.STOPPED;
    
    @Override
    public void start(Instrumentation inst) {
        logger.info("[MyAgent] Starting my custom agent");
        
        try {
            // 1. 在这里实现你的初始化逻辑
            // 例如：注册 ByteBuddy transformer
            
            // new AgentBuilder.Default()
            //     .type(ElementMatchers.named("com.example.TargetClass"))
            //     .transform(new MyTransformer())
            //     .installOn(inst);
            
            currentState = AgentState.RUNNING;
            logger.info("[MyAgent] Successfully started");
            
        } catch (Exception e) {
            logger.error("[MyAgent] Failed to start", e);
            currentState = AgentState.FAILED;
        }
    }
    
    @Override
    public void stop() {
        logger.info("[MyAgent] Stopping agent");
        currentState = AgentState.STOPPED;
        logger.info("[MyAgent] Agent stopped");
    }
    
    @Override
    public String getName() {
        return AGENT_NAME;
    }
    
    @Override
    public AgentState getState() {
        return currentState;
    }
}
```

### Step 4: 配置和测试

在 `agent-config.properties` 添加：

```properties
agents=jms-agent,my-agent

agent.my-agent.path=./my-agent/target/my-agent-0.0.1-SNAPSHOT.jar
agent.my-agent.class=com.example.MyAgent
```

构建并测试：

```bash
mvn clean package -DskipTests
java -javaagent:agent-boot/target/agent-boot-0.0.1-SNAPSHOT.jar -jar your-app.jar
```

## 📚 API 文档

### Agent 接口

```java
public interface Agent {
    /**
     * 启动 agent
     * @param inst Instrumentation 实例，用于字节码转换
     */
    void start(Instrumentation inst);
    
    /**
     * 停止 agent
     * 注意：ByteBuddy transformer 无法完全卸载，仅标记为停止状态
     */
    void stop();
    
    /**
     * 获取 agent 名称
     * @return Agent 唯一标识名称
     */
    String getName();
    
    /**
     * 获取当前状态
     * @return STOPPED, RUNNING, 或 FAILED
     */
    AgentState getState();
}
```

### AgentLifecycleManager

```java
// 启动指定 agent
boolean success = AgentLifecycleManager.start("my-agent");

// 停止指定 agent
boolean success = AgentLifecycleManager.stop("my-agent");

// 重启指定 agent
boolean success = AgentLifecycleManager.restart("my-agent");

// 查询 agent 状态
AgentState state = AgentLifecycleManager.getStatus("my-agent");
```

### AgentContext

```java
// 获取单例实例
AgentContext context = AgentContext.getInstance();

// 获取指定 agent
AgentInstance instance = context.getAgent("my-agent");

// 获取所有 agent
Collection<AgentInstance> agents = context.getAllAgents();

// 检查 agent 是否存在
boolean exists = context.hasAgent("my-agent");
```

## 💡 最佳实践

### 1. 状态管理

```java
public class MyAgent implements Agent {
    // 使用静态变量存储共享状态
    private static AgentState currentState = AgentState.STOPPED;
    private static final AtomicBoolean enabled = new AtomicBoolean(false);
    
    @Override
    public void start(Instrumentation inst) {
        // 初始化成功后设置状态
        enabled.set(true);
        currentState = AgentState.RUNNING;
    }
    
    @Override
    public void stop() {
        // 停止时禁用监控
        enabled.set(false);
        currentState = AgentState.STOPPED;
    }
    
    // 在拦截器中检查enabled状态
    public static boolean isEnabled() {
        return enabled.get();
    }
}
```

### 2. 日志使用

```java
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MyAgent implements Agent {
    private static final Logger logger = LoggerFactory.getLogger(MyAgent.class);
    
    @Override
    public void start(Instrumentation inst) {
        logger.info("[MyAgent] Starting...");
        logger.debug("[MyAgent] Debug info: {}", someVariable);
        logger.warn("[MyAgent] Warning message");
        logger.error("[MyAgent] Error occurred", exception);
    }
}
```

### 3. ByteBuddy Transformer

```java
new AgentBuilder.Default()
    // 忽略 JDK 和内部类
    .ignore(ElementMatchers.nameStartsWith("java."))
    .ignore(ElementMatchers.nameStartsWith("javax."))
    .ignore(ElementMatchers.nameStartsWith("sun."))
    
    // 目标类
    .type(ElementMatchers.named("com.example.TargetClass"))
    
    // 应用转换
    .transform(new MyTransformer())
    
    // 安装到 Instrumentation
    .installOn(inst);
```

### 4. 方法拦截

```java
public class MyInterceptor {
    
    @Advice.OnMethodEnter
    public static void onEnter(@Advice.This Object thisObject,
                              @Advice.AllArguments Object[] args) {
        // 在目标方法执行前检查是否启用
        if (!MyAgent.isEnabled()) {
            return;
        }
        
        try {
            // 执行监控逻辑
            logger.info("Method called with args: {}", Arrays.toString(args));
        } catch (Exception e) {
            // 捕获异常，避免影响业务逻辑
            logger.warn("Interceptor error", e);
        }
    }
}
```

### 5. 异常处理

```java
@Override
public void start(Instrumentation inst) {
    try {
        // 初始化逻辑
        initializeAgent(inst);
        currentState = AgentState.RUNNING;
        
    } catch (Exception e) {
        // 记录错误并设置失败状态
        logger.error("[MyAgent] Failed to start", e);
        currentState = AgentState.FAILED;
        // 不要抛出异常，避免影响其他 agent 加载
    }
}
```

## 🔍 故障排查

### Agent 未加载

**症状**: 日志中没有 agent 启动信息

**检查**:
1. 确认 `-javaagent` 参数正确
2. 检查 `agent-config.properties` 路径
3. 验证配置文件中 `agents` 列表包含你的 agent

### ClassNotFoundException

**症状**: `Agent class not found: com.example.MyAgent`

**解决**:
1. 确认类名完全限定（包含包名）
2. 验证 JAR 文件包含该类
3. 使用 `jar tf my-agent.jar` 检查 JAR 内容

### Agent 接口方法未调用

**症状**: `Agent does not implement Agent interface`

**解决**:
1. 确认类声明了 `implements Agent`
2. 确认正确依赖了 `agent-api` 模块
3. 检查 Maven 构建是否成功

### 日志未输出

**症状**: Agent 运行但没有日志

**解决**:
1. 检查 `logback.xml` 配置
2. 确认日志级别设置（DEBUG/INFO/WARN/ERROR）
3. 验证 SLF4J 和 Logback 依赖已包含在 JAR 中

## 📝 限制和注意事项

> [!WARNING]
> **ByteBuddy Transformer 限制**
> 
> 由于 JVM 的限制，已注册的 ByteBuddy transformer **无法完全卸载**。
> 
> Agent 的 `stop()` 方法只能：
> - 标记 agent 为 STOPPED 状态
> - 禁用拦截器的监控逻辑（通过 `isEnabled()` 检查）
> - Class 转换仍然存在于 JVM 中

> [!NOTE]
> **ClassLoader 隔离**
> 
> 每个 agent 使用独立的 URLClassLoader 加载，但该 ClassLoader 的父类加载器是 `AgentLoader.class.getClassLoader()`，以确保可以访问 `agent-api` 中的类。

## 📄 许可证

MIT License

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

---

**作者**: Koma  
**邮箱**: komaqiangqiang.zhang@sc.com
