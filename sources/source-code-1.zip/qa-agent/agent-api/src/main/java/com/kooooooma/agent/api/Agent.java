package com.kooooooma.agent.api;

import java.lang.instrument.Instrumentation;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public interface Agent {

    void start(Instrumentation inst);

    void stop();

    String getName();

    AgentState getState();
}
