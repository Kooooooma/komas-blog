package com.kooooooma.agent.api;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public enum AgentState {

    STOPPED,

    RUNNING,

    FAILED
}
