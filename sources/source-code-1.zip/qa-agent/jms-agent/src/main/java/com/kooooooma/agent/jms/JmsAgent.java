package com.kooooooma.agent.jms;

import com.kooooooma.agent.api.Agent;
import com.kooooooma.agent.api.AgentState;
import com.kooooooma.agent.jms.interceptor.JmsTemplateInterceptor;
import com.kooooooma.agent.jms.transformer.JmsTemplateTransformer;
import com.kooooooma.agent.jms.util.AgentLogger;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.matcher.ElementMatchers;

import java.lang.instrument.Instrumentation;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class JmsAgent implements Agent {

    private static final AgentLogger logger = AgentLogger.getLogger(JmsTemplateInterceptor.class);
    private static final String AGENT_NAME = "jms-agent";

    private static final AtomicBoolean enabled = new AtomicBoolean(false);
    private static AgentState currentState = AgentState.STOPPED;

    @Override
    public void start(Instrumentation inst) {
        logger.info("Starting JMS monitoring agent");

        try {
            new AgentBuilder.Default()
                    // Ignore ByteBuddy internal and JDK classes
                    .ignore(ElementMatchers.nameStartsWith("net.bytebuddy."))
                    .ignore(ElementMatchers.nameStartsWith("java."))
                    .ignore(ElementMatchers.nameStartsWith("javax."))
                    .ignore(ElementMatchers.nameStartsWith("sun."))
                    .ignore(ElementMatchers.nameStartsWith("com.sun."))

                    // Target Spring JmsTemplate class
                    .type(ElementMatchers.named("org.springframework.jms.core.JmsTemplate"))
                    .transform(new JmsTemplateTransformer())

                    // Install to instrumentation
                    .installOn(inst);

            enabled.set(true);
            currentState = AgentState.RUNNING;

            logger.info("Successfully registered JmsTemplate transformer");
            logger.info("Will monitor: org.springframework.jms.core.JmsTemplate.send()");
        } catch (Exception e) {
            logger.error("ERROR: Failed to initialize JMS monitoring", e);
            currentState = AgentState.FAILED;
        }
    }

    @Override
    public void stop() {
        logger.info("Stopping JMS agent");
        enabled.set(false);
        currentState = AgentState.STOPPED;
        logger.info("JMS agent stopped (transformers remain in JVM)");
    }

    @Override
    public String getName() {
        return AGENT_NAME;
    }

    @Override
    public AgentState getState() {
        return currentState;
    }

    public static boolean isEnabled() {
        return enabled.get();
    }
}
