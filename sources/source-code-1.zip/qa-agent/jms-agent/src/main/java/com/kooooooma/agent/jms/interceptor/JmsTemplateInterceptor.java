package com.kooooooma.agent.jms.interceptor;

import com.kooooooma.agent.jms.JmsAgent;
import com.kooooooma.agent.jms.util.AgentLogger;
import net.bytebuddy.asm.Advice;

import javax.jms.Destination;
import javax.jms.Queue;
import javax.jms.Topic;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class JmsTemplateInterceptor {

    private static final AgentLogger logger = AgentLogger.getLogger(JmsTemplateInterceptor.class);

    @Advice.OnMethodEnter
    public static void onEnter(@Advice.This Object jmsTemplate, @Advice.AllArguments Object[] args) {

        if (!JmsAgent.isEnabled()) {
            return;
        }

        try {
            logger.separator();
            logger.info("JmsTemplate.send() intercepted");

            Destination destination = findDestination(args);

            if (destination != null) {
                printDestinationInfo(destination);
            } else {
                logger.info("Destination: Using default destination");
            }

            printConnectionInfo(jmsTemplate);

            logger.separator();
        } catch (Exception e) {
            logger.warn("WARNING: Failed to log JMS send info: {}", e.getMessage());
        }
    }

    private static Destination findDestination(Object[] args) {
        if (args == null || args.length == 0) {
            return null;
        }

        for (Object arg : args) {
            if (arg instanceof Destination) {
                return (Destination) arg;
            }
        }

        return null;
    }

    private static void printDestinationInfo(Destination destination) {
        try {
            if (destination instanceof Topic) {
                Topic topic = (Topic) destination;
                String topicName = topic.getTopicName();
                logger.info("Destination Type: TOPIC");
                logger.info("Topic Name: {}", topicName);
            } else if (destination instanceof Queue) {
                Queue queue = (Queue) destination;
                String queueName = queue.getQueueName();
                logger.info("Destination Type: QUEUE");
                logger.info("Queue Name: {}", queueName);
            } else {
                logger.info("Destination Type: {}", destination.getClass().getName());
                logger.info("Destination: {}", destination.toString());
            }
        } catch (Exception e) {
            logger.info("Destination: {} (unable to extract name)", destination.getClass().getName());
        }
    }

    private static void printConnectionInfo(Object jmsTemplate) {
        try {
            Class<?> clazz = jmsTemplate.getClass();
            Object connectionFactory = clazz.getMethod("getConnectionFactory").invoke(jmsTemplate);

            if (connectionFactory != null) {
                logger.info("Connection Factory: {}", connectionFactory.getClass().getName());
                logger.info("Connection Factory Instance: {}", connectionFactory.toString());
            } else {
                logger.info("Connection Factory: null");
            }
        } catch (Exception e) {
            logger.info("Connection Factory: Unable to retrieve ({})", e.getMessage());
        }
    }
}
