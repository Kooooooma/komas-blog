package com.kooooooma.agent.jms.transformer;

import com.kooooooma.agent.jms.interceptor.JmsTemplateInterceptor;
import com.kooooooma.agent.jms.util.AgentLogger;
import net.bytebuddy.agent.builder.AgentBuilder;
import net.bytebuddy.asm.Advice;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.dynamic.DynamicType;
import net.bytebuddy.matcher.ElementMatchers;
import net.bytebuddy.utility.JavaModule;

import java.security.ProtectionDomain;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class JmsTemplateTransformer implements AgentBuilder.Transformer {
    private static final AgentLogger logger = AgentLogger.getLogger(JmsTemplateInterceptor.class);

    @Override
    public DynamicType.Builder<?> transform(
            DynamicType.Builder<?> builder,
            TypeDescription typeDescription,
            ClassLoader classLoader,
            JavaModule module,
            ProtectionDomain protectionDomain) {

        logger.info("Transforming class: {}", typeDescription.getName());

        return builder
                // Intercept all methods named "send"
                .visit(Advice.to(JmsTemplateInterceptor.class)
                        .on(ElementMatchers.named("send")));
    }
}
