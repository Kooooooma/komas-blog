package com.kooooooma.agent.lifecycle;

import com.kooooooma.agent.util.AgentLogger;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class AgentContext {

    private static final AgentLogger logger = AgentLogger.getLogger(AgentContext.class);
    private static final AgentContext INSTANCE = new AgentContext();

    private final Map<String, AgentInstance> agents = new ConcurrentHashMap<>();

    private AgentContext() {
    }

    public static AgentContext getInstance() {
        return INSTANCE;
    }

    public void registerAgent(AgentInstance agent) {
        agents.put(agent.getName(), agent);
        logger.info("Registered agent: {}", agent.getName());
    }

    public AgentInstance getAgent(String name) {
        return agents.get(name);
    }

    public Collection<AgentInstance> getAllAgents() {
        return agents.values();
    }

    public boolean hasAgent(String name) {
        return agents.containsKey(name);
    }

    public void unregisterAgent(String name) {
        AgentInstance removed = agents.remove(name);
        if (removed != null) {
            logger.info("Unregistered agent: {}", name);
        }
    }

    public int getAgentCount() {
        return agents.size();
    }
}
