package com.kooooooma.agent.loader;

import com.kooooooma.agent.api.Agent;
import com.kooooooma.agent.lifecycle.AgentInstance;
import com.kooooooma.agent.util.AgentLogger;

import java.io.File;
import java.lang.instrument.Instrumentation;
import java.net.URL;
import java.net.URLClassLoader;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class AgentLoader {

    private static final AgentLogger logger = AgentLogger.getLogger(AgentLoader.class);

    public static AgentInstance loadAgent(String agentName, String jarPath, String className, Instrumentation inst) {
        logger.info("Loading agent: {}", agentName);
        logger.info("  JAR Path: {}", jarPath);
        logger.info("  Class: {}", className);

        File jarFile = new File(jarPath);
        if (!jarFile.exists()) {
            logger.error("Agent jar not found: {}", jarPath);
            return null;
        }

        if (!jarFile.isFile()) {
            logger.error("Agent jar is not a file: {}", jarPath);
            return null;
        }

        try {
            URL jarUrl = jarFile.toURI().toURL();
            // Create isolated ClassLoader with Bootstrap as parent
            // This prevents agent-boot dependencies from conflicting with target JVM
            URLClassLoader classLoader = new URLClassLoader(new URL[]{jarUrl}, null);

            Class<?> agentClass = classLoader.loadClass(className);
            logger.info("Loaded agent class: {}", agentClass.getName());

            Object agentObject = agentClass.getDeclaredConstructor().newInstance();
            logger.info("Created agent instance: {}", agentName);

            if (!(agentObject instanceof Agent agent)) {
                throw new RuntimeException("Agent class " + agentClass.getName() + " is not an instance of Agent");
            }

            logger.info("Agent implements Agent interface, calling start()");
            agent.start(inst);

            AgentInstance instance = new AgentInstance(
                    agentName, className, jarPath,
                    agentObject, classLoader, inst
            );

            logger.info("Successfully started agent: {}", agentName);
            return instance;
        } catch (ClassNotFoundException e) {
            logger.error("Agent class not found: {}", className, e);
        } catch (Exception e) {
            logger.error("Failed to load/start agent: {}", agentName, e);
        }
        return null;
    }
}
