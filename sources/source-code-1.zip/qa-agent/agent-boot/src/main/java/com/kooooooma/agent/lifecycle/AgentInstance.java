package com.kooooooma.agent.lifecycle;

import com.kooooooma.agent.api.Agent;
import com.kooooooma.agent.api.AgentState;

import java.lang.instrument.Instrumentation;
import java.net.URLClassLoader;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class AgentInstance {

    private final String name;
    private final String className;
    private final String jarPath;
    private final Object agentObject;
    private final URLClassLoader classLoader;
    private final Instrumentation instrumentation;
    private AgentState state;

    public AgentInstance(String name, String className, String jarPath, Object agentObject, URLClassLoader classLoader, Instrumentation instrumentation) {
        this.name = name;
        this.className = className;
        this.jarPath = jarPath;
        this.agentObject = agentObject;
        this.classLoader = classLoader;
        this.instrumentation = instrumentation;
        this.state = AgentState.STOPPED;
    }

    public String getName() {
        return name;
    }

    public String getClassName() {
        return className;
    }

    public String getJarPath() {
        return jarPath;
    }

    public Object getAgentObject() {
        return agentObject;
    }

    public URLClassLoader getClassLoader() {
        return classLoader;
    }

    public Instrumentation getInstrumentation() {
        return instrumentation;
    }

    public AgentState getState() {
        return state;
    }

    public void setState(AgentState state) {
        this.state = state;
    }

    public boolean isStandardAgent() {
        return agentObject instanceof Agent;
    }

    public Agent asStandardAgent() {
        if (isStandardAgent()) {
            return (Agent) agentObject;
        }
        return null;
    }

    @Override
    public String toString() {
        return String.format("AgentInstance{name='%s', class='%s', state=%s}", name, className, state);
    }
}
