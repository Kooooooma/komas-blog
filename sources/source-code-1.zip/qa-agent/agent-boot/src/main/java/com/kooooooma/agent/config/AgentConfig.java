package com.kooooooma.agent.config;

import com.kooooooma.agent.util.AgentLogger;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class AgentConfig {

    private static final AgentLogger logger = AgentLogger.getLogger(AgentConfig.class);

    private static final String DEFAULT_CONFIG_FILE = "agent-config.properties";
    private static final String AGENTS_KEY = "agents";
    private static final String AGENT_PATH_PREFIX = "agent.";
    private static final String AGENT_PATH_SUFFIX = ".path";
    private static final String AGENT_CLASS_SUFFIX = ".class";

    private final Properties properties;
    private final File configFileDir;

    public AgentConfig(String configPath) throws IOException {
        this.properties = new Properties();
        File configFile = new File(configPath);

        if (!configFile.exists()) {
            throw new IOException("Configuration file not found: " + configPath);
        }

        try (InputStream input = new FileInputStream(configFile)) {
            properties.load(input);
        }

        this.configFileDir = configFile.getParentFile();
        logger.info("Loaded configuration from: {}", configFile.getAbsolutePath());
    }

    public static AgentConfig loadDefault(File jarDir) throws IOException {
        File configFile = new File(jarDir, DEFAULT_CONFIG_FILE);
        return new AgentConfig(configFile.getAbsolutePath());
    }

    public List<String> getAgentNames() {
        String agentsStr = properties.getProperty(AGENTS_KEY, "");
        if (agentsStr.trim().isEmpty()) {
            return Collections.emptyList();
        }

        String[] agents = agentsStr.split(",");
        List<String> result = new ArrayList<>();
        for (String agent : agents) {
            String trimmed = agent.trim();
            if (!trimmed.isEmpty()) {
                result.add(trimmed);
            }
        }
        return result;
    }

    public String getAgentPath(String agentName) {
        String pathKey = AGENT_PATH_PREFIX + agentName + AGENT_PATH_SUFFIX;
        String path = properties.getProperty(pathKey);

        if (path == null) {
            return null;
        }

        return getAbsolutePath(path);
    }

    public String getAgentClass(String agentName) {
        String classKey = AGENT_PATH_PREFIX + agentName + AGENT_CLASS_SUFFIX;
        return properties.getProperty(classKey);
    }

    public String getAgentApiJarPath() {
        String agentApiJarPath = properties.getProperty("agent-api.jar.path", "");
        if (agentApiJarPath.isEmpty()) {
            throw new RuntimeException("agent-api.jar.path is empty");
        }

        return getAbsolutePath(agentApiJarPath);
    }

    public String getAbsolutePath(String path) {
        File file = new File(path);

        if (!file.isAbsolute()) {
            file = new File(configFileDir, path);
        }

        return file.getAbsolutePath();
    }

    public String getAgentInfo(String agentName) {
        return String.format("Agent[name=%s, path=%s, class=%s]",
                agentName,
                getAgentPath(agentName),
                getAgentClass(agentName)
        );
    }
}
