package com.kooooooma.agent.util;

import org.slf4j.Logger;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class AgentLogger {

    private static final String AGENT_PREFIX = "[Agent-Boot] ";

    private final Logger logger;
    private final String prefix;

    private AgentLogger(Logger logger, String prefix) {
        this.logger = logger;
        this.prefix = prefix;
    }

    public static AgentLogger getLogger(Class<?> clazz) {
        return new AgentLogger(org.slf4j.LoggerFactory.getLogger(clazz), AGENT_PREFIX);
    }

    public static AgentLogger getLogger(Class<?> clazz, String agentPrefix) {
        return new AgentLogger(org.slf4j.LoggerFactory.getLogger(clazz), agentPrefix);
    }

    public void info(String message) {
        logger.info(prefix + message);
    }

    public void info(String format, Object... args) {
        logger.info(prefix + format, args);
    }

    public void warn(String message) {
        logger.warn(prefix + message);
    }

    public void warn(String format, Object... args) {
        logger.warn(prefix + format, args);
    }

    public void error(String message) {
        logger.error(prefix + message);
    }

    public void error(String message, Throwable throwable) {
        logger.error(prefix + message, throwable);
    }

    public void error(String format, Object... args) {
        logger.error(prefix + format, args);
    }

    public void debug(String message) {
        logger.debug(prefix + message);
    }

    public void debug(String format, Object... args) {
        logger.debug(prefix + format, args);
    }

    public void separator() {
        logger.info("========================================");
    }
}
