package com.kooooooma.agent.lifecycle;

import com.kooooooma.agent.api.Agent;
import com.kooooooma.agent.api.AgentState;
import com.kooooooma.agent.util.AgentLogger;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class AgentLifecycleManager {

    private static final AgentLogger logger = AgentLogger.getLogger(AgentLifecycleManager.class);
    private static final AgentContext context = AgentContext.getInstance();

    public static boolean start(String agentName) {
        AgentInstance instance = context.getAgent(agentName);

        if (instance == null) {
            logger.error("Agent not found: {}", agentName);
            return false;
        }

        if (instance.getState() == AgentState.RUNNING) {
            logger.warn("Agent already running: {}", agentName);
            return true;
        }

        try {
            logger.info("Starting agent: {}", agentName);

            if (!instance.isStandardAgent()) {
                throw new RuntimeException("Agent class " + instance.getName() + " is not an instance of Agent");
            }

            Agent agent = instance.asStandardAgent();
            agent.start(instance.getInstrumentation());
            instance.setState(AgentState.RUNNING);
            logger.info("Agent started successfully: {}", agentName);
            return true;
        } catch (Exception e) {
            logger.error("Failed to start agent: {}", agentName, e);
            instance.setState(AgentState.FAILED);
            return false;
        }
    }

    public static boolean stop(String agentName) {
        AgentInstance instance = context.getAgent(agentName);

        if (instance == null) {
            logger.error("Agent not found: {}", agentName);
            return false;
        }

        if (instance.getState() == AgentState.STOPPED) {
            logger.warn("Agent already stopped: {}", agentName);
            return true;
        }

        try {
            logger.info("Stopping agent: {}", agentName);

            if (!instance.isStandardAgent()) {
                throw new RuntimeException("Agent class " + instance.getName() + " is not an instance of Agent");
            }

            Agent agent = instance.asStandardAgent();
            agent.stop();
            instance.setState(AgentState.STOPPED);
            logger.info("Agent stopped: {}", agentName);
            return true;
        } catch (Exception e) {
            logger.error("Failed to stop agent: {}", agentName, e);
            return false;
        }
    }

    public static boolean restart(String agentName) {
        logger.info("Restarting agent: {}", agentName);

        if (!stop(agentName)) {
            return false;
        }

        return start(agentName);
    }

    public static AgentState getStatus(String agentName) {
        AgentInstance instance = context.getAgent(agentName);

        if (instance == null) {
            return null;
        }

        if (!instance.isStandardAgent()) {
            logger.error("Agent class " + instance.getName() + " is not an instance of Agent");
            return null;
        }

        return instance.asStandardAgent().getState();
    }
}
