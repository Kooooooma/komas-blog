package com.kooooooma.agent;

import com.kooooooma.agent.api.AgentState;
import com.kooooooma.agent.config.AgentConfig;
import com.kooooooma.agent.lifecycle.AgentContext;
import com.kooooooma.agent.lifecycle.AgentInstance;
import com.kooooooma.agent.loader.AgentLoader;
import com.kooooooma.agent.util.AgentLogger;

import java.io.File;
import java.lang.instrument.Instrumentation;
import java.util.List;
import java.util.jar.JarFile;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class AgentBootstrap {

    private static final AgentLogger logger = AgentLogger.getLogger(AgentBootstrap.class);

    public static void start(String agentArgs, Instrumentation inst, boolean isAttach) {
        try {
            logger.separator();
            if (isAttach) {
                logger.info("Attaching Agent Boot Loader");
            } else {
                logger.info("Starting Agent Boot Loader");
            }
            logger.separator();

            String bootAgentJarPath = AgentBootstrap.class.getProtectionDomain().getCodeSource().getLocation().getPath();
            File bootAgentJarFile = new File(bootAgentJarPath);

            String configPath = parseConfigPath(agentArgs);

            AgentConfig config;
            if (configPath != null) {
                logger.info("Using custom config path: {}", configPath);
                config = new AgentConfig(configPath);
            } else {
                logger.info("Using default config file");
                config = AgentConfig.loadDefault(bootAgentJarFile.getParentFile());
            }

            // load agent api into bootstrap classloader
            // to make all agent interfaces are visible to all agents and target jvm
            File agentApiJarFile = new File(config.getAgentApiJarPath());
            if (!agentApiJarFile.exists()) {
                throw new RuntimeException("Agent Api Jar Not Found!");
            }
            inst.appendToBootstrapClassLoaderSearch(new JarFile(agentApiJarFile));
            logger.info("Loaded agent-api into Bootstrap ClassLoader");

            List<String> agentNames = config.getAgentNames();

            if (agentNames.isEmpty()) {
                logger.warn("No agents configured to load");
                return;
            }

            logger.info("Found {} agent(s) to load: {}", agentNames.size(), agentNames);

            int successCount = 0;
            int failCount = 0;

            for (String agentName : agentNames) {
                String agentJarPath = config.getAgentPath(agentName);
                String agentClassName = config.getAgentClass(agentName);

                if (agentJarPath == null || agentClassName == null) {
                    logger.error("Incomplete configuration for agent: {}", agentName);
                    failCount++;
                    continue;
                }

                AgentInstance instance = AgentLoader.loadAgent(agentName, agentJarPath, agentClassName, inst);
                if (instance != null) {
                    AgentContext.getInstance().registerAgent(instance);
                    instance.setState(AgentState.RUNNING);
                    successCount++;
                } else {
                    failCount++;
                }
            }

            logger.separator();
            logger.info("Agent loading complete");
            logger.info("  Success: {}", successCount);
            logger.info("  Failed: {}", failCount);
            logger.separator();
        } catch (Exception e) {
            logger.error("FATAL ERROR: Failed to initialize agent boot loader", e);
            throw new RuntimeException(e);
        }
    }

    private static String parseConfigPath(String agentArgs) {
        if (agentArgs == null || agentArgs.trim().isEmpty()) {
            return null;
        }

        String[] parts = agentArgs.split("=", 2);
        if (parts.length == 2 && "configPath".equals(parts[0].trim())) {
            return parts[1].trim();
        }

        return null;
    }
}
