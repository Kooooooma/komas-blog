package com.kooooooma.agent;

import java.lang.instrument.Instrumentation;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class AgentMain {

    public static void premain(String agentArgs, Instrumentation inst) {
        bootstrap(agentArgs, inst, false);
    }

    public static void agentmain(String agentArgs, Instrumentation inst) {
        bootstrap(agentArgs, inst, true);
    }

    private static void bootstrap(String agentArgs, Instrumentation inst, boolean isAttach) {
        try {
            URL bootJar = AgentMain.class.getProtectionDomain().getCodeSource().getLocation();

            // Create isolated ClassLoader with Bootstrap as parent
            // This prevents agent-boot dependencies from conflicting with target JVM
            URLClassLoader bootLoader = new URLClassLoader(new URL[] { bootJar }, null);

            Class<?> bootstrapClass = bootLoader.loadClass(AgentMain.class.getPackageName() + ".AgentBootstrap");
            Method startMethod = bootstrapClass.getMethod(
                    "start",
                    String.class,
                    Instrumentation.class,
                    boolean.class
            );
            startMethod.invoke(null, agentArgs, inst, isAttach);
        } catch (Exception e) {
            // Cannot use SLF4J here - not loaded yet
            System.err.println("FATAL: Failed to bootstrap agent: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
