package com.kooooooma.qahome.utils;

import ch.qos.logback.classic.Logger;
import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.encoder.PatternLayoutEncoder;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.OutputStreamAppender;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class LogCaptureUtil {
    // please make sure keep this pattern same with logback-spring.xml
    public static final String DEFAULT_LOG_PATTERN = "%clr(%d{yyyy-MM-dd HH:mm:ss.SSS}){faint} %clr([%thread]){magenta} %clr(%-5level) %clr(%logger{40}){cyan} - %msg%n";

    public static void capture(Runnable task, StringBuilder logOutput) {
        Logger rootLogger = (Logger) LoggerFactory.getLogger(org.slf4j.Logger.ROOT_LOGGER_NAME);
        LoggerContext context = rootLogger.getLoggerContext();

        ByteArrayOutputStream os = new ByteArrayOutputStream();
        PatternLayoutEncoder encoder = new PatternLayoutEncoder();
        encoder.setContext(context);
        encoder.setPattern(DEFAULT_LOG_PATTERN);
        encoder.setCharset(StandardCharsets.UTF_8);
        encoder.start();

        OutputStreamAppender<ILoggingEvent> appender = new OutputStreamAppender<>();
        appender.setContext(context);
        appender.setEncoder(encoder);
        appender.setOutputStream(os);
        appender.start();
        rootLogger.addAppender(appender);
        try {
            task.run();
        } finally {
            rootLogger.detachAppender(appender);
            appender.stop();
            logOutput.append(os.toString(StandardCharsets.UTF_8));
        }
    }
}
