package com.kooooooma.qahome.dagengine;

import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class GlobalExecutionContext {
    public final ConcurrentHashMap<String, Object> data = new ConcurrentHashMap<>();

    public void put(String key, Object value) {
        data.put(key, value);
    }

    public Object get(String key) {
        return data.getOrDefault(key, null);
    }
}
