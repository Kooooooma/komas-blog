package com.kooooooma.qahome.dagengine;

import com.kooooooma.qahome.dto.NodeDto;
import lombok.Builder;
import lombok.Data;

import java.util.List;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Builder
@Data
public class GraphStage {
    private int level;
    private List<NodeDto> nodes;
}
