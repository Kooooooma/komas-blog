package com.kooooooma.qahome.event;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Data
@AllArgsConstructor
public class LaneRunEvent {
    private UUID laneId;
    private String employeeId;
}
