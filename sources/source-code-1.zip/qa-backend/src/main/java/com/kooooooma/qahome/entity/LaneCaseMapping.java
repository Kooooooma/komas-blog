package com.kooooooma.qahome.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Builder
@Entity
@Table(name = "lane_case_mapping")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LaneCaseMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private UUID laneId;

    @Column(nullable = false)
    private UUID testCaseId;

    @Column
    private UUID lastExecutionId;

    @Column(nullable = false)
    private Integer orderIndex = 0; // case order in the lane
}
