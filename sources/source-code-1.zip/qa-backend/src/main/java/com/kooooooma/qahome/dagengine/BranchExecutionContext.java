package com.kooooooma.qahome.dagengine;

import com.kooooooma.qahome.dto.NodeDto;
import lombok.Builder;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Builder
public class BranchExecutionContext {
    private final Map<String, Object> data = new HashMap<>();

    private NodeDto node;
    private List<BranchExecutionContext> parents;

    public void put(String key, Object value) {
        data.put(key, value);
    }

    public Object get(String key) {
        if (data.containsKey(key)) {
            return data.get(key);
        }

        if (Objects.isNull(parents)) {
            return null;
        }

        for (BranchExecutionContext parent : parents) {
            return parent.get(key);
        }

        return null;
    }
}
