package com.kooooooma.qahome.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kooooooma.qahome.dagengine.GraphExecutor;
import com.kooooooma.qahome.dto.BridgeMessageDto;
import com.kooooooma.qahome.dto.ContractDto;
import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.entity.TestExecution;
import com.kooooooma.qahome.enums.BridgeMessageType;
import com.kooooooma.qahome.enums.ExecutionStatus;
import com.kooooooma.qahome.enums.TestCaseType;
import com.kooooooma.qahome.repository.TestCaseRepository;
import com.kooooooma.qahome.repository.TestExecutionRepository;
import com.kooooooma.qahome.utils.LogCaptureUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class ExecutionService {
    @Autowired
    private TestCaseRepository testCaseRepository;

    @Autowired
    private TestExecutionRepository testExecutionRepository;

    @Autowired
    private GraphExecutor graphExecutor;

    @Lazy
    @Autowired
    private BridgeService bridgeService;

    @Value("${report.path}")
    private String reportPath;

    @Transactional
    public TestExecution runTestCase(UUID testCaseId, String employeeId) {
        TestCase testCase = testCaseRepository.findById(testCaseId)
                .orElseThrow(() -> new RuntimeException("TestCase not found"));

        if (TestCaseType.BACKEND.equals(testCase.getType())) {
            return runBackendTestCase(testCase);
        }

        if (TestCaseType.FRONTEND.equals(testCase.getType())) {
            return runFrontendTestCase(testCase, employeeId);
        }

        throw new RuntimeException("TestCase type not supported");
    }

    public TestExecution runBackendTestCase(TestCase testCase) {
        if (StringUtils.isBlank(testCase.getContract())) {
            throw new RuntimeException("TestCase has no content to run");
        }

        // Parse contract JSON
        ContractDto contract;
        try {
            ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            contract = mapper.readValue(testCase.getContract(), ContractDto.class);
        } catch (Exception e) {
            log.error("Failed to read contract from test case {}", testCase.getId(), e);
            throw new RuntimeException("Failed to parse test case contract", e);
        }

        if (Objects.isNull(contract.getEdges()) || Objects.isNull(contract.getNodes()) || contract.getNodes().isEmpty()) {
            throw new RuntimeException("TestCase has no content to run");
        }

        TestExecution execution = TestExecution.builder()
                .status(ExecutionStatus.RUNNING)
                .startTime(LocalDateTime.now())
                .endTime(LocalDateTime.now()) // Temporary
                .testCaseId(testCase.getId())
                .build();
        execution = testExecutionRepository.save(execution);

        try {
            StringBuilder logs = new StringBuilder();
            LogCaptureUtil.capture(() -> graphExecutor.execute(contract), logs);
            execution.setLogs(logs.toString());
            execution.setStatus(ExecutionStatus.SUCCESS);
        } catch (Exception e) {
            execution.setStatus(ExecutionStatus.FAILED);
            throw e;
        } finally {
            execution.setEndTime(LocalDateTime.now());
            testExecutionRepository.save(execution);
            testCase.setLastExecutionId(execution.getId());
            testCaseRepository.save(testCase);
            log.info("Finished run test case {}, executionId {}", testCase.getId(), execution.getId());
        }
        return execution;
    }

    public TestExecution runFrontendTestCase(TestCase testCase, String employeeId) {
        if (StringUtils.isBlank(testCase.getScript())) {
            throw new RuntimeException("TestCase has no content to run");
        }

        TestExecution execution = TestExecution.builder()
                .status(ExecutionStatus.RUNNING)
                .startTime(LocalDateTime.now())
                .endTime(LocalDateTime.now()) // Temporary
                .testCaseId(testCase.getId())
                .build();
        execution = testExecutionRepository.save(execution);

        testCase.setLastExecutionId(execution.getId());
        testCaseRepository.save(testCase);
        bridgeService.runCase(testCase, execution, employeeId, BridgeMessageType.RUN, false);
        log.info("Starting run test case {}, executionId {}", testCase.getId(), execution.getId());
        return execution;
    }

    public void updateExecutionFromBridgeEvent(BridgeMessageDto bridgeMessageDto) {
        Optional<TestExecution> executionOptional = testExecutionRepository.findById(UUID.fromString(bridgeMessageDto.getEventPayload().get("executionId")));
        if (executionOptional.isPresent()) {
            TestExecution execution = executionOptional.get();
            execution.setStatus(ExecutionStatus.valueOf(bridgeMessageDto.getEventStatus().toUpperCase()));
            execution.setEndTime(LocalDateTime.now());
            String executionReportPath = reportPath + File.separator + execution.getId();
            try {
                FileUtils.forceMkdir(FileUtils.getFile(executionReportPath));
                executionReportPath = executionReportPath + File.separator + execution.getId() + ".html";
                FileUtils.write(FileUtils.getFile(executionReportPath), bridgeMessageDto.getEventPayload().get("reportContent"), StandardCharsets.UTF_8.name());
                execution.setReportPath(executionReportPath);
                execution.setLogs(bridgeMessageDto.getEventPayload().get("executionLogs"));
            } catch (IOException e) {
                throw new RuntimeException("Report directory could not be created " + executionReportPath, e);
            }
            testExecutionRepository.save(execution);
            log.info("Finished run test case {}, executionId {}", execution.getTestCaseId(), execution.getId());
        }
    }

    public String getExecutionReport(UUID executionId) throws IOException {
        Optional<TestExecution> executionOptional = testExecutionRepository.findById(executionId);
        if (!executionOptional.isPresent()) {
            throw new RuntimeException("Execution " + executionId + " report not found");
        }

        TestExecution execution = executionOptional.get();
        return FileUtils.readFileToString(FileUtils.getFile(execution.getReportPath()), StandardCharsets.UTF_8.name());
    }
}
