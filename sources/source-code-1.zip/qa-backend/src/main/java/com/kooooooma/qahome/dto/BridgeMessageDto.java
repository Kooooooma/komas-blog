package com.kooooooma.qahome.dto;

import com.kooooooma.qahome.enums.BridgeMessageType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BridgeMessageDto {
    private BridgeMessageType eventType;
    private String eventStatus;
    private String message;

    private Map<String,String> eventPayload;

    private String bridgeUuid;
    private String employeeId;
}
