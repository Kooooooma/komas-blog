package com.kooooooma.qahome.utils;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class SignalUtil {
    private static final ConcurrentHashMap<String, CountDownLatch> signalLatchMapping = new ConcurrentHashMap<>();

    public static boolean waitSignal(String signalKey, long timeout, TimeUnit timeUnit) throws InterruptedException {
        CountDownLatch latch = new CountDownLatch(1);
        signalLatchMapping.put(signalKey, latch);

        try {
            return latch.await(timeout, timeUnit);
        } finally {
            signalLatchMapping.remove(signalKey);
        }
    }

    public static void signal(String signalKey) {
        CountDownLatch latch = signalLatchMapping.remove(signalKey);
        if (latch != null) {
            latch.countDown();
        }
    }
}
