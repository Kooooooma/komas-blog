package com.kooooooma.qahome.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class JmsMessageQuery {
    private int page = 0;
    private int size = 20;
    private String vpn;
    private String type;
    private String destination;
    private String server;
    private String appName;
    private String trackingId;
}
