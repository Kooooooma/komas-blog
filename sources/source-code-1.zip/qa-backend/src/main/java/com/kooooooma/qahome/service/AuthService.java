package com.kooooooma.qahome.service;

import com.kooooooma.qahome.dto.AuthDto;
import com.kooooooma.qahome.entity.Employee;
import com.kooooooma.qahome.entity.Workspace;
import com.kooooooma.qahome.enums.WorkspaceType;
import com.kooooooma.qahome.repository.EmployeeRepository;
import com.kooooooma.qahome.repository.WorkspaceRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class AuthService {

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private WorkspaceRepository workspaceRepository;

    public Employee login(AuthDto.LoginRequest request, String clientIp) {
        String employeeId = request.getEmployeeId();

        Employee employee = employeeRepository.findByEmployeeId(employeeId)
                .orElseGet(() -> employeeRepository.save(
                        Employee.builder()
                                .employeeId(employeeId)
                                .lastLoginTime(LocalDateTime.now())
                                .build()
                ));

        log.info("EmployeeId {} login with IP: {}", request.getEmployeeId(), clientIp);

        List<Workspace> workspaces = workspaceRepository.findByEmployeeId(employee.getEmployeeId());

        if (Objects.isNull(workspaces) || workspaces.isEmpty()) {
            workspaceRepository.save(Workspace.builder()
                    .employeeId(employee.getEmployeeId())
                    .createTime(LocalDateTime.now())
                    .name("Default Workspace")
                    .type(WorkspaceType.STANDARD)
                    .build());
        }

        return employee;
    }

    public void logout(String employeeId) {
        log.info("EmployeeId {} logout", employeeId);
    }
}
