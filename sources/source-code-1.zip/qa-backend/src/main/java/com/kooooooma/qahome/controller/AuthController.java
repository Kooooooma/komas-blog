package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.dto.AuthDto;
import com.kooooooma.qahome.entity.Employee;
import com.kooooooma.qahome.service.AuthService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public AuthDto.AuthResponse login(@RequestBody AuthDto.LoginRequest request, HttpServletRequest servletRequest) {
        Employee employee = authService.login(request, servletRequest.getRemoteAddr());
        return AuthDto.AuthResponse.builder()
                .employeeId(employee.getEmployeeId())
                .build();
    }

    @PostMapping("/logout")
    public void logout(@RequestBody AuthDto.LoginRequest request) {
        authService.logout(request.getEmployeeId());
    }
}
