package com.kooooooma.qahome.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kooooooma.qahome.dagengine.GraphExecutor;
import com.kooooooma.qahome.dto.BridgeMessageDto;
import com.kooooooma.qahome.dto.ContractDto;
import com.kooooooma.qahome.entity.Lane;
import com.kooooooma.qahome.entity.LaneCaseMapping;
import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.entity.TestExecution;
import com.kooooooma.qahome.enums.BridgeMessageType;
import com.kooooooma.qahome.enums.ExecutionStatus;
import com.kooooooma.qahome.enums.TestCaseType;
import com.kooooooma.qahome.event.LaneRunEvent;
import com.kooooooma.qahome.repository.LaneCaseMappingRepository;
import com.kooooooma.qahome.repository.LaneRepository;
import com.kooooooma.qahome.repository.TestCaseRepository;
import com.kooooooma.qahome.repository.TestExecutionRepository;
import com.kooooooma.qahome.utils.LogCaptureUtil;
import com.kooooooma.qahome.utils.SignalUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Lazy;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class LaneService {

    @Autowired
    private LaneRepository laneRepository;

    @Autowired
    private LaneCaseMappingRepository laneCaseMappingRepository;

    @Autowired
    private TestCaseRepository testCaseRepository;

    @Autowired
    private TestExecutionRepository testExecutionRepository;

    @Autowired
    private GraphExecutor graphExecutor;

    @Lazy
    @Autowired
    private BridgeService bridgeService;

    @Autowired
    private ExecutionService executionService;

    @Autowired
    private ApplicationEventPublisher eventPublisher;

    @Transactional
    public Lane createLane(Lane lane) {
        lane.setCreateTime(LocalDateTime.now());
        return laneRepository.save(lane);
    }

    @Transactional
    public Lane updateLaneName(UUID id, String name) {
        Lane lane = laneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Lane not found: " + id));
        lane.setName(name);
        return laneRepository.save(lane);
    }

    @Transactional
    public void updateLaneOrder(UUID laneId, List<UUID> laneCaseMappingIds) {
        List<LaneCaseMapping> mappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndexAsc(laneId);

        Map<UUID, LaneCaseMapping> map = new HashMap<>();
        for (LaneCaseMapping m : mappings) {
            map.put(m.getId(), m);
        }

        for (int i = 0; i < laneCaseMappingIds.size(); i++) {
            UUID laneCaseMappingId = laneCaseMappingIds.get(i);
            LaneCaseMapping mapping = map.get(laneCaseMappingId);
            if (mapping == null) {
                continue;
            }
            mapping.setOrderIndex(i + 1);
            laneCaseMappingRepository.save(mapping);
        }
    }

    @Transactional
    public void deleteLane(UUID id) {
        Lane lane = laneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Lane not found: " + id));

        List<LaneCaseMapping> mappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndexAsc(lane.getId());
        List<UUID> executionIds = mappings.stream().map(LaneCaseMapping::getLastExecutionId).filter(Objects::nonNull).toList();
        if (!executionIds.isEmpty()) {
            testExecutionRepository.deleteAllById(executionIds);
        }
        laneCaseMappingRepository.deleteByLaneId(id);
        laneRepository.delete(lane);
    }

    public List<Map<String, Object>> getLanesByWorkspace(UUID workspaceId) {
        List<Lane> lanes = laneRepository.findByWorkspaceIdOrderByCreateTimeDesc(workspaceId);
        return lanes.stream().map(this::enrichLaneWithStats).collect(Collectors.toList());
    }

    private Map<String, Object> enrichLaneWithStats(Lane lane) {
        Map<String, Object> result = new HashMap<>();
        result.put("lane", lane);

        List<Map<String, Object>> cases = new ArrayList<>();
        List<LaneCaseMapping> laneCaseMappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndexAsc(lane.getId());
        laneCaseMappings.forEach(laneCaseMapping -> {
            Map<String, Object> caseData = new HashMap<>();
            Optional<TestCase> testCaseOptional = testCaseRepository.findById(laneCaseMapping.getTestCaseId());
            testCaseOptional.ifPresent(testCase -> caseData.put("case", testCase));
            if (Objects.nonNull(laneCaseMapping.getLastExecutionId())) {
                Optional<TestExecution> testExecutionOptional = testExecutionRepository.findById(laneCaseMapping.getLastExecutionId());
                testExecutionOptional.ifPresent(testExecution -> caseData.put("lastExecution", testExecution));
            }
            caseData.put("lanecasemapping", laneCaseMapping);
            cases.add(caseData);
        });

        result.put("cases", cases);
        return result;
    }

    @Transactional
    public void addCaseToLane(UUID laneId, UUID caseId) {
        laneRepository.findById(laneId)
                .orElseThrow(() -> new RuntimeException("Lane not found: " + laneId));

        List<LaneCaseMapping> existing = laneCaseMappingRepository.findByLaneIdOrderByOrderIndexAsc(laneId);
        int nextOrder = existing.isEmpty() ? 1 : existing.get(existing.size() - 1).getOrderIndex() + 1;

        LaneCaseMapping mapping = LaneCaseMapping.builder()
                .laneId(laneId)
                .testCaseId(caseId)
                .orderIndex(nextOrder)
                .build();
        laneCaseMappingRepository.save(mapping);
    }

    @Transactional
    public void runLane(UUID laneId, String employeeId) {
        laneRepository.findById(laneId).orElseThrow(() -> new RuntimeException("Lane not found: " + laneId));

        List<LaneCaseMapping> laneCaseMappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndexAsc(laneId);
        List<TestExecution> testExecutionList = new ArrayList<>();
        laneCaseMappings.forEach(laneCaseMapping -> {
            TestExecution testExecution = TestExecution.builder()
                    .status(ExecutionStatus.PENDING)
                    .testCaseId(laneCaseMapping.getTestCaseId())
                    .laneId(laneCaseMapping.getLaneId())
                    .laneCaseMappingId(laneCaseMapping.getId())
                    .startTime(LocalDateTime.now())
                    .build();
            testExecutionList.add(testExecution);
        });
        testExecutionRepository.saveAll(testExecutionList);

        laneCaseMappings.forEach(laneCaseMapping -> {
            for (TestExecution testExecution : testExecutionList) {
                if (testExecution.getLaneCaseMappingId().equals(laneCaseMapping.getId())) {
                    laneCaseMapping.setLastExecutionId(testExecution.getId());
                    break;
                }
            }
        });
        laneCaseMappingRepository.saveAll(laneCaseMappings);

        // Publish event to run lane asynchronously after transaction commit
        eventPublisher.publishEvent(new LaneRunEvent(laneId, employeeId));
    }

    @Async
    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT) // default run in sync mode
    public void handleLaneRunEvent(LaneRunEvent event) {
        UUID laneId = event.getLaneId();
        String employeeId = event.getEmployeeId();

        log.info("Starting lane execution for laneId: {} after transaction commit", laneId);

        List<LaneCaseMapping> laneCaseMappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndexAsc(laneId);

        for (int idx = 0; idx < laneCaseMappings.size(); idx++) {
            LaneCaseMapping laneCaseMapping = laneCaseMappings.get(idx);
            Optional<TestExecution> testExecutionOptional = testExecutionRepository.findById(laneCaseMapping.getLastExecutionId());
            Optional<TestCase> testCaseOptional = testCaseRepository.findById(laneCaseMapping.getTestCaseId());
            if (testCaseOptional.isEmpty() || testExecutionOptional.isEmpty()) {
                log.error("Test case {} or execution {} not found in lane {}", testCaseOptional, testExecutionOptional, laneCaseMapping);
                break;
            }
            TestExecution testExecution = testExecutionOptional.get();
            TestCase testCase = testCaseOptional.get();

            try {
                testExecution.setStartTime(LocalDateTime.now());
                testExecution.setStatus(ExecutionStatus.RUNNING);
                testExecution = testExecutionRepository.save(testExecution);

                if (TestCaseType.BACKEND.equals(testCase.getType())) {
                    ContractDto contract;
                    try {
                        ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                        contract = mapper.readValue(testCase.getContract(), ContractDto.class);
                    } catch (Exception e) {
                        log.error("Failed to read contract from test case {}", testCase.getId(), e);
                        break;
                    }

                    if (Objects.isNull(contract.getEdges()) || Objects.isNull(contract.getNodes()) || contract.getNodes().isEmpty()) {
                        log.error("TestCase has no content to run");
                        break;
                    }

                    StringBuilder logs = new StringBuilder();
                    LogCaptureUtil.capture(() -> graphExecutor.execute(contract), logs);
                    // log.error(logs.toString());

                    testExecution.setLogs(logs.toString());
                    testExecution.setStatus(ExecutionStatus.SUCCESS);
                    testExecution.setEndTime(LocalDateTime.now());
                    testExecutionRepository.save(testExecution);
                } else if (TestCaseType.FRONTEND.equals(testCase.getType())) {
                    Thread.sleep(1000 * 30);
                    bridgeService.runCase(testCase, testExecution, employeeId, BridgeMessageType.LANE_RUN, true);
                    log.info("Lane run command sent to Bridge, waiting for Bridge execution finish... test case id: {}", testCase.getId());
                    boolean normalExit = SignalUtil.waitSignal(testExecution.getId().toString(), 60, TimeUnit.MINUTES);
                    if (!normalExit) {
                        throw new RuntimeException("Bridge execution timed out");
                    }

                    testExecution = testExecutionRepository.findById(laneCaseMapping.getLastExecutionId()).get();
                    if (ExecutionStatus.FAILED.equals(testExecution.getStatus())) {
                        log.error("Failed to run test case {}, testExecution {}", testCase.getId(), testExecution.getId());
                        break;
                    }
                }
            } catch (Exception e) {
                log.error("Test case {} - {} run failed {}", testCase.getId(), testCase.getName(), e.getMessage(), e);
                testExecution.setStatus(ExecutionStatus.FAILED);
                testExecution.setEndTime(LocalDateTime.now());
                try {
                    testExecutionRepository.save(testExecution);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
                throw new RuntimeException(e);
            } finally {
                // update rest executions to FAST_FAILED
                List<UUID> restExecutionIds = new ArrayList<>();
                List<UUID> restTestCaseIds = new ArrayList<>();
                for (int i = idx + 1; i < laneCaseMappings.size(); i++) {
                    restExecutionIds.add(laneCaseMappings.get(i).getLastExecutionId());
                    restTestCaseIds.add(laneCaseMappings.get(i).getTestCaseId());
                }
                testExecutionRepository.updateStatusAndEndTimeByIds(restExecutionIds, ExecutionStatus.FAST_FAILED, LocalDateTime.now());
                log.info("Lane execution failed, fast failed for rest test case id: {}, execution id: {}", restTestCaseIds, restExecutionIds);
            }
        }
    }

    public void notifyLane(BridgeMessageDto bridgeMessageDto) {
        String bridgeUuid = bridgeMessageDto.getBridgeUuid();
        log.info("Received notification from bridge: {}, message {}", bridgeUuid, bridgeMessageDto);

        try {
            if (BridgeMessageType.LANE_EXECUTION_FINISHED.equals(bridgeMessageDto.getEventType())) {
                executionService.updateExecutionFromBridgeEvent(bridgeMessageDto);
            }
        } catch (Exception e) {
            log.error("Bridge message for lane process failed", e);
        } finally {
            SignalUtil.signal(bridgeMessageDto.getEventPayload().get("executionId"));
        }
    }
}
