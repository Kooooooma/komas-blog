package com.kooooooma.qahome.dagengine;

import com.kooooooma.qahome.dto.NodeDto;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public interface GraphTaskNode {
    default String key() {
        String simpleName = this.getClass().getSimpleName();
        return Character.toLowerCase(simpleName.charAt(0)) + simpleName.substring(1);
    }

    default String name() {
        return this.key();
    }

    String category();

    default boolean accept(String nodeId) {
        return this.key().equals(nodeId);
    }

    void execute(NodeDto node, BranchExecutionContext branchContext, GlobalExecutionContext globalContext);
}
