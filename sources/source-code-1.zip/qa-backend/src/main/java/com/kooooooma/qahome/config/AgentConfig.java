package com.kooooooma.qahome.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Data
@Configuration
@ConfigurationProperties(prefix = "agent")
public class AgentConfig {

    private AgentBoot  agentBoot;

    @Data
    public static class AgentBoot {
        private String jarPath;
    }
}
