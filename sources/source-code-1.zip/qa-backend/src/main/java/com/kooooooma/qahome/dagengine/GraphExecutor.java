package com.kooooooma.qahome.dagengine;

import com.kooooooma.qahome.dto.ContractDto;
import com.kooooooma.qahome.dto.NodeDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.CancellationException;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class GraphExecutor {
    @Autowired
    private List<GraphTaskNode> graphTaskNodeList;

    public void execute(ContractDto contractDTO) {
        GlobalExecutionContext globalExecutionContext = new GlobalExecutionContext();
        Map<String, BranchExecutionContext> branchExecutionContextMap = new ConcurrentHashMap<>();
        List<GraphStage> graphStages = GraphAnalyzer.analyzeGraph(contractDTO);

        if (graphStages.isEmpty()) {
            log.warn("Graph is empty");
            throw new RuntimeException("Graph is empty");
        }

        Map<String, Set<String>> childToParentMapping = new HashMap<>();
        contractDTO.getEdges().forEach(edge ->
                childToParentMapping.computeIfAbsent(edge.getTarget(), k -> new HashSet<>()).add(edge.getSource()));

        AtomicBoolean isErrorOccurred = new AtomicBoolean(false);
        Map<String, CompletableFuture<Void>> taskNodeFutures = new ConcurrentHashMap<>();

        for (GraphStage graphStage : graphStages) {
            for (NodeDto node : graphStage.getNodes()) {
                Set<String> parentIds = childToParentMapping.getOrDefault(node.getId(), Collections.emptySet());

                List<CompletableFuture<Void>> parentFutures = parentIds.stream().map(taskNodeFutures::get).toList();

                Runnable taskWrapper = () -> {
                    if (isErrorOccurred.get()) {
                        throw new CancellationException("Graph execution aborted due to error in node.");
                    }

                    try {
                        executeNodeTask(node, parentIds, branchExecutionContextMap, globalExecutionContext);
                    } catch (Exception e) {
                        log.error("Node [{}] failed. Aborting graph execution.", node.getId(), e);
                        if (isErrorOccurred.compareAndSet(false, true)) {
                            // cancel all tasks
                            taskNodeFutures.values().forEach(f -> {
                                if (f != null && !f.isDone()) {
                                    f.cancel(true);
                                }
                            });
                        }
                        throw e; // mark current future as failed
                    }
                };

                CompletableFuture<Void> future;
                if (!parentFutures.isEmpty()) {
                    // wait all parents complete and then start
                    future = CompletableFuture.allOf(parentFutures.toArray(new CompletableFuture[0])).thenRunAsync(taskWrapper);
                } else {
                    // entry node, start immediately
                    future = CompletableFuture.runAsync(taskWrapper);
                }

                taskNodeFutures.put(node.getId(), future);
            }
        }

        try {
            // wait all nodes complete
            CompletableFuture.allOf(taskNodeFutures.values().toArray(new CompletableFuture[0])).join();
            log.info("Graph Execution Completed Successfully.");
        } catch (Exception e) {
            log.error("Graph Execution Failed.", e);
            // extract original exception
            Throwable cause = e.getCause();
            if (cause instanceof RuntimeException) {
                throw (RuntimeException) cause;
            }
            throw new RuntimeException(cause != null ? cause : e);
        }
    }

    public void executeNodeTask(NodeDto node, Set<String> parentIds, Map<String, BranchExecutionContext> branchExecutionContextMap, GlobalExecutionContext globalExecutionContext) {
        graphTaskNodeList.stream().filter(graphTaskNode -> graphTaskNode.accept(node.getData().get("key"))).findFirst().ifPresent(graphTaskNode -> {
            BranchExecutionContext.BranchExecutionContextBuilder builder = BranchExecutionContext.builder().node(node);
            if (Objects.nonNull(parentIds) && !parentIds.isEmpty()) {
                List<BranchExecutionContext> parents = new LinkedList<>();
                parentIds.forEach(parentId -> parents.add(branchExecutionContextMap.get(parentId)));
                builder.parents(parents);
            }
            graphTaskNode.execute(node, builder.build(), globalExecutionContext);
        });
    }
}
