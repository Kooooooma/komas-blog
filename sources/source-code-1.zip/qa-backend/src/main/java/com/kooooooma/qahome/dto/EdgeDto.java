package com.kooooooma.qahome.dto;

import lombok.Data;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Data
public class EdgeDto {
    private String id;
    private String source;
    private String target;
}
