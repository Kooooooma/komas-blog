package com.kooooooma.qahome.service;

import com.kooooooma.qahome.entity.LaneCaseMapping;
import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.repository.LaneCaseMappingRepository;
import com.kooooooma.qahome.repository.TestCaseRepository;
import com.kooooooma.qahome.repository.TestExecutionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class LaneCaseMappingService {
    @Autowired
    private LaneCaseMappingRepository laneCaseMappingRepository;

    @Autowired
    private TestCaseRepository testCaseRepository;

    @Autowired
    private TestExecutionRepository testExecutionRepository;

    public void removeCaseFromLane(UUID id) {
        laneCaseMappingRepository.deleteById(id);
    }

    public Map<String, Object> getDetailById(UUID id) {
        LaneCaseMapping laneCaseMapping = laneCaseMappingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("LaneCaseMapping Not Found"));

        TestCase testCase = testCaseRepository.findById(laneCaseMapping.getTestCaseId())
                .orElseThrow(() -> new RuntimeException("LaneCaseMapping - TestCase not found: " + laneCaseMapping.getTestCaseId()));

        Map<String, Object> result = new HashMap<>();
        result.put("case", testCase);

        if (Objects.nonNull(laneCaseMapping.getLastExecutionId())) {
            testExecutionRepository.findById(laneCaseMapping.getLastExecutionId())
                    .ifPresent(execution -> result.put("lastExecution", execution));
        }

        return result;
    }
}
