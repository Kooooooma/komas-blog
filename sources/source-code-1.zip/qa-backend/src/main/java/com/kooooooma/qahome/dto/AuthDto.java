package com.kooooooma.qahome.dto;

import lombok.Builder;
import lombok.Data;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class AuthDto {
    @Data
    public static class LoginRequest {
        private String employeeId;
    }

    @Builder
    @Data
    public static class AuthResponse {
        private String employeeId;
    }
}
