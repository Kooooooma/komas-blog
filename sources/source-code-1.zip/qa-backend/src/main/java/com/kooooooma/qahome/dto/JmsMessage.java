package com.kooooooma.qahome.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class JmsMessage {
    private String vpn;
    private String type;
    private String destination;
    private String server;
    private String appName;
    private LocalDateTime time;
    private String trackingId;
    private String messageContent;
}
