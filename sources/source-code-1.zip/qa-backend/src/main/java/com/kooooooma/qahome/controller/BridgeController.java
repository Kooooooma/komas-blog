package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.dto.BridgeMessageDto;
import com.kooooooma.qahome.service.BridgeService;
import com.kooooooma.qahome.service.LaneService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.Map;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@RestController
@RequestMapping("/api/bridge")
public class BridgeController {
    @Autowired
    private BridgeService bridgeService;

    @Autowired
    private LaneService laneService;

    @GetMapping("/register")
    public SseEmitter register(@RequestParam String source, @RequestParam(required = false) String bridgeUuid, @RequestHeader(value = "x-employee-id", required = false) String employeeId) {
        return bridgeService.register(source, employeeId, bridgeUuid);
    }

    @PostMapping("/bind")
    public Map<String, Object> bindUserToBridge(@RequestBody Map<String, String> payload, @RequestHeader(value = "x-employee-id") String employeeId) {
        boolean success = bridgeService.bindUserToBridge(employeeId, payload.get("bridgeUuid"));
        return Map.of("success", success);
    }

    @GetMapping("/status")
    public Map<String, Object> getStatus(@RequestHeader(value = "x-employee-id") String employeeId) {
        boolean connected = bridgeService.isUserBridgeConnected(employeeId);
        String bridgeUuid = bridgeService.getUserBridgeUuid(employeeId);
        return Map.of("connected", connected, "bridgeUuid", bridgeUuid != null ? bridgeUuid : "");
    }

    @PostMapping("/ping")
    public Map<String, Object> pingBridge(@RequestHeader(value = "x-employee-id") String employeeId) {
        bridgeService.pingBridge(employeeId);
        return Map.of("sent", true);
    }

    @PostMapping("/record")
    public void record(@RequestBody BridgeMessageDto bridgeMessageDto, @RequestHeader(value = "x-employee-id") String employeeId) {
        bridgeService.record(bridgeMessageDto, employeeId);
    }

    @PostMapping("/notify/user")
    public void notifyUser(@RequestBody BridgeMessageDto bridgeMessageDto) {
        bridgeService.notifyUser(bridgeMessageDto);
    }

    @PostMapping("/notify/lane")
    public void notifyLane(@RequestBody BridgeMessageDto bridgeMessageDto) {
        laneService.notifyLane(bridgeMessageDto);
    }
}
