package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.service.LaneCaseMappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@RestController
@RequestMapping("/api/lanecasemapping")
public class LaneCaseMappingController {
    @Autowired
    private LaneCaseMappingService laneCaseMappingService;

    @DeleteMapping("/{id}")
    public void removeCaseFromLane(@PathVariable UUID id) {
        laneCaseMappingService.removeCaseFromLane(id);
    }

    @GetMapping("/detail/{id}")
    public Map<String, Object> getDetailById(@PathVariable UUID id) {
        return laneCaseMappingService.getDetailById(id);
    }
}
