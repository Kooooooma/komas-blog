package com.kooooooma.qahome.service;

import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.kooooooma.qahome.config.AgentConfig;
import com.kooooooma.qahome.config.SshConfig;
import com.kooooooma.qahome.dto.AttachRequest;
import com.kooooooma.qahome.dto.JvmInfo;
import com.sun.tools.attach.VirtualMachine;
import com.sun.tools.attach.VirtualMachineDescriptor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class AgentService {

    @Autowired
    private SshConfig sshConfig;

    @Autowired
    private AgentConfig agentConfig;

    private static final String AGENT_PROPERTY_KEY = "jms.agent.attached";

    public List<JvmInfo> discoverJvms(String server, String appNameKeyword) {
        List<JvmInfo> jvmList = new ArrayList<>();

        try {
            if ("local".equalsIgnoreCase(server) || "localhost".equalsIgnoreCase(server)) {
                // Local JVM discovery
                jvmList = discoverLocalJvms(appNameKeyword);
            } else {
                // Remote JVM discovery via SSH
                jvmList = discoverRemoteJvms(server, appNameKeyword);
            }
        } catch (Exception e) {
            log.error("Failed to discover JVMs on server: {}", server, e);
        }

        return jvmList;
    }

    private List<JvmInfo> discoverLocalJvms(String appNameKeyword) {
        List<JvmInfo> jvmList = new ArrayList<>();

        try {
            List<VirtualMachineDescriptor> vms = VirtualMachine.list();
            for (VirtualMachineDescriptor vmd : vms) {
                String displayName = vmd.displayName();
                String pid = vmd.id();

                // Filter by app name keyword
                if (appNameKeyword == null || appNameKeyword.isEmpty() ||
                        displayName.toLowerCase().contains(appNameKeyword.toLowerCase())) {

                    boolean agentAttached = checkLocalAgentStatus(pid);
                    jvmList.add(new JvmInfo(pid, displayName, "local", agentAttached));
                }
            }
        } catch (Exception e) {
            log.error("Failed to discover local JVMs", e);
        }

        return jvmList;
    }

    private List<JvmInfo> discoverRemoteJvms(String server, String appNameKeyword) {
        List<JvmInfo> jvmList = new ArrayList<>();
        Session session = null;

        try {
            session = createSshSession(server);
            session.connect();

            // Execute jps command to list JVMs
            String command = "jps -v";
            String output = executeSshCommand(session, command);

            // Parse jps output
            String[] lines = output.split("\n");
            for (String line : lines) {
                if (line.trim().isEmpty())
                    continue;

                String[] parts = line.split("\\s+", 2);
                if (parts.length >= 2) {
                    String pid = parts[0];
                    String displayName = parts[1];

                    // Filter by app name keyword
                    if (appNameKeyword == null || appNameKeyword.isEmpty() ||
                            displayName.toLowerCase().contains(appNameKeyword.toLowerCase())) {

                        boolean agentAttached = checkRemoteAgentStatus(session, pid);
                        jvmList.add(new JvmInfo(pid, displayName, server, agentAttached));
                    }
                }
            }
        } catch (Exception e) {
            log.error("Failed to discover remote JVMs on server: {}", server, e);
        } finally {
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
        }

        return jvmList;
    }

    public Map<String, Map<String, Boolean>> batchAttachAgent(AttachRequest request) {
        Map<String, Map<String, Boolean>> results = new HashMap<>();

        for (AttachRequest.ServerRequest serverReq : request.getRequests()) {
            String server = serverReq.getServer();
            Map<String, Boolean> serverResults = new HashMap<>();

            for (String pid : serverReq.getPids()) {
                boolean success = false;
                try {
                    if ("local".equalsIgnoreCase(server) || "localhost".equalsIgnoreCase(server)) {
                        success = attachLocalAgent(pid);
                    } else {
                        success = attachRemoteAgent(server, pid);
                    }
                } catch (Exception e) {
                    log.error("Failed to attach agent to PID {} on server {}", pid, server, e);
                }
                serverResults.put(pid, success);
            }

            results.put(server, serverResults);
        }

        return results;
    }

    public Map<String, Map<String, Boolean>> checkAgentStatus(AttachRequest request) {
        Map<String, Map<String, Boolean>> results = new HashMap<>();

        for (AttachRequest.ServerRequest serverReq : request.getRequests()) {
            String server = serverReq.getServer();
            Map<String, Boolean> serverResults = new HashMap<>();

            Session session = null;
            try {
                if (!"local".equalsIgnoreCase(server) && !"localhost".equalsIgnoreCase(server)) {
                    session = createSshSession(server);
                    session.connect();
                }

                for (String pid : serverReq.getPids()) {
                    boolean attached = false;
                    try {
                        if ("local".equalsIgnoreCase(server) || "localhost".equalsIgnoreCase(server)) {
                            attached = checkLocalAgentStatus(pid);
                        } else {
                            attached = checkRemoteAgentStatus(session, pid);
                        }
                    } catch (Exception e) {
                        log.error("Failed to check agent status for PID {} on server {}", pid, server, e);
                    }
                    serverResults.put(pid, attached);
                }
            } catch (Exception e) {
                log.error("Failed to connect to server: {}", server, e);
            } finally {
                if (session != null && session.isConnected()) {
                    session.disconnect();
                }
            }

            results.put(server, serverResults);
        }

        return results;
    }

    private boolean attachLocalAgent(String pid) {
        try {
            VirtualMachine vm = VirtualMachine.attach(pid);
            String agentPath = agentConfig.getAgentBoot().getJarPath();
            vm.loadAgent(agentPath);
            vm.detach();
            log.info("Successfully attached agent to local PID: {}", pid);
            return true;
        } catch (Exception e) {
            log.error("Failed to attach agent to local PID: {}", pid, e);
            return false;
        }
    }

    private boolean attachRemoteAgent(String server, String pid) {
        Session session = null;
        try {
            session = createSshSession(server);
            session.connect();

            // agent-boot jar in share folder
            String agentPath = agentConfig.getAgentBoot().getJarPath();

            // Execute attach command remotely
            String command = String.format(
                    "java -cp $JAVA_HOME/lib/tools.jar:. AttachAgent %s %s",
                    pid, agentPath);

            String output = executeSshCommand(session, command);
            log.info("Remote attach output for PID {}: {}", pid, output);

            return true;
        } catch (Exception e) {
            log.error("Failed to attach agent to remote PID {} on server {}", pid, server, e);
            return false;
        } finally {
            if (session != null && session.isConnected()) {
                session.disconnect();
            }
        }
    }

    private boolean checkLocalAgentStatus(String pid) {
        try {
            VirtualMachine vm = VirtualMachine.attach(pid);
            String property = vm.getSystemProperties().getProperty(AGENT_PROPERTY_KEY);
            vm.detach();
            return "true".equals(property);
        } catch (Exception e) {
            log.debug("Could not check agent status for local PID: {}", pid);
            return false;
        }
    }

    private boolean checkRemoteAgentStatus(Session session, String pid) {
        try {
            // Use jcmd to check system properties
            String command = String.format("jcmd %s VM.system_properties | grep %s", pid, AGENT_PROPERTY_KEY);
            String output = executeSshCommand(session, command);
            return output.contains(AGENT_PROPERTY_KEY + "=true");
        } catch (Exception e) {
            log.debug("Could not check agent status for remote PID: {}", pid);
            return false;
        }
    }

    private Session createSshSession(String server) throws Exception {
        JSch jsch = new JSch();
        jsch.addIdentity(sshConfig.getKeyFilePath());

        Session session = jsch.getSession(sshConfig.getUsername(), server, 22);
        session.setConfig("StrictHostKeyChecking", "no");
        session.setTimeout(sshConfig.getTimeout());

        return session;
    }

    private String executeSshCommand(Session session, String command) throws Exception {
        ChannelExec channel = (ChannelExec) session.openChannel("exec");
        channel.setCommand(command);
        channel.setInputStream(null);
        channel.setErrStream(System.err);

        BufferedReader reader = new BufferedReader(new InputStreamReader(channel.getInputStream()));
        channel.connect();

        StringBuilder output = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            output.append(line).append("\n");
        }

        channel.disconnect();
        return output.toString();
    }
}
