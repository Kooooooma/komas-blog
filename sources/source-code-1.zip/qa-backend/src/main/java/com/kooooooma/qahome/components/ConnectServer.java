package com.kooooooma.qahome.components;

import com.kooooooma.qahome.dagengine.BranchExecutionContext;
import com.kooooooma.qahome.dagengine.GlobalExecutionContext;
import com.kooooooma.qahome.dagengine.GraphTaskNode;
import com.kooooooma.qahome.dto.NodeDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Component
public class ConnectServer implements GraphTaskNode {

    @Override
    public String category() {
        return "SSH";
    }

    @Override
    public void execute(NodeDto node, BranchExecutionContext branchContext, GlobalExecutionContext globalContext) {
        branchContext.put("nodeData", node.getData());
        globalContext.put("nodeData", node.getData());

        log.info("Connecting to SSH... {}, branchData: {}, globalData: {}", node.getId(), branchContext.get("nodeData"), globalContext.get("nodeData"));
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {

        }
    }
}
