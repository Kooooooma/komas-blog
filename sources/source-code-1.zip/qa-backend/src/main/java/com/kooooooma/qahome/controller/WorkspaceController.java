package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.entity.Workspace;
import com.kooooooma.qahome.service.LaneService;
import com.kooooooma.qahome.service.WorkspaceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@RestController
@RequestMapping("/api/workspace")
public class WorkspaceController {
    @Autowired
    private WorkspaceService workspaceService;

    @Autowired
    private LaneService laneService;

    @GetMapping("/employee/{employeeId}")
    public List<Workspace> getWorkspacesByEmployee(@PathVariable String employeeId) {
        return workspaceService.getWorkspacesByEmployee(employeeId);
    }

    @PostMapping
    public Workspace createWorkspace(@RequestBody Workspace workspace) {
        return workspaceService.createWorkspace(workspace);
    }

    @PutMapping("/{id}/name")
    public Workspace updateWorkspaceName(@PathVariable UUID id, @RequestBody Map<String, String> body) {
        return workspaceService.updateWorkspaceName(id, body.get("name"));
    }

    @DeleteMapping("/{id}")
    public void deleteWorkspace(@PathVariable UUID id, @RequestHeader("employeeId") String employeeId) {
        if (employeeId == null) {
            throw new RuntimeException("Employee ID is required");
        }
        workspaceService.deleteWorkspace(id, employeeId);
    }

    @GetMapping("/{workspaceId}/lanes")
    public List<Map<String, Object>> getLanesByWorkspace(@PathVariable UUID workspaceId) {
        return laneService.getLanesByWorkspace(workspaceId);
    }
}
