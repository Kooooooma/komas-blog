package com.kooooooma.qahome.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class JvmInfo {
    private String pid;
    private String appName;
    private String server;
    private boolean agentAttached;
}
