package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.dto.AttachRequest;
import com.kooooooma.qahome.dto.JmsMessage;
import com.kooooooma.qahome.dto.JmsMessageQuery;
import com.kooooooma.qahome.dto.JvmInfo;
import com.kooooooma.qahome.service.AgentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@RestController
@RequestMapping("/api/agent")
public class AgentController {

    @Autowired
    private AgentService agentService;

    @GetMapping("/jvm/discover")
    public List<JvmInfo> discoverJvms(
            @RequestParam String server,
            @RequestParam(required = false, defaultValue = "") String appName) {
        return agentService.discoverJvms(server, appName);
    }

    @PostMapping("/jvm/attach")
    public Map<String, Map<String, Boolean>> attachAgent(@RequestBody AttachRequest request) {
        return agentService.batchAttachAgent(request);
    }

    @PostMapping("/jvm/status")
    public Map<String, Map<String, Boolean>> checkAgentStatus(@RequestBody AttachRequest request) {
        return agentService.checkAgentStatus(request);
    }

    @PostMapping("/jms/messages")
    public Page<JmsMessage> queryJmsMessages(@RequestBody JmsMessageQuery query) {
        List<JmsMessage> mockData = generateMockJmsMessages(query);
        PageRequest pageRequest = PageRequest.of(query.getPage(), query.getSize());

        int start = (int) pageRequest.getOffset();
        int end = Math.min((start + pageRequest.getPageSize()), mockData.size());

        List<JmsMessage> pageContent = mockData.subList(start, end);
        return new PageImpl<>(pageContent, pageRequest, mockData.size());
    }

    private List<JmsMessage> generateMockJmsMessages(JmsMessageQuery query) {
        List<JmsMessage> messages = new ArrayList<>();

        // Generate 50 mock messages
        for (int i = 1; i <= 50; i++) {
            JmsMessage msg = new JmsMessage();
            msg.setVpn("VPN" + String.format("%03d", (i % 5) + 1));
            msg.setType(i % 2 == 0 ? "TOPIC" : "QUEUE");
            msg.setDestination((msg.getType().equals("TOPIC") ? "topic." : "queue.") + "test." + i);
            msg.setServer("server" + ((i % 3) + 1));
            msg.setAppName("app-" + ((i % 4) + 1));
            msg.setTime(LocalDateTime.now().minusMinutes(i * 5));
            msg.setTrackingId("tracking-" + String.format("%05d", i));
            msg.setMessageContent(
                    "{\"id\": " + i + ", \"data\": \"Sample message content for testing\", \"timestamp\": \"" +
                            LocalDateTime.now().minusMinutes(i * 5) + "\"}");

            // Apply filters
            if (matchesFilter(msg, query)) {
                messages.add(msg);
            }
        }

        return messages;
    }

    private boolean matchesFilter(JmsMessage msg, JmsMessageQuery query) {
        if (query.getVpn() != null && !query.getVpn().isEmpty() &&
                !msg.getVpn().toLowerCase().contains(query.getVpn().toLowerCase())) {
            return false;
        }
        if (query.getType() != null && !query.getType().isEmpty() &&
                !msg.getType().equalsIgnoreCase(query.getType())) {
            return false;
        }
        if (query.getDestination() != null && !query.getDestination().isEmpty() &&
                !msg.getDestination().toLowerCase().contains(query.getDestination().toLowerCase())) {
            return false;
        }
        if (query.getServer() != null && !query.getServer().isEmpty() &&
                !msg.getServer().toLowerCase().contains(query.getServer().toLowerCase())) {
            return false;
        }
        if (query.getAppName() != null && !query.getAppName().isEmpty() &&
                !msg.getAppName().toLowerCase().contains(query.getAppName().toLowerCase())) {
            return false;
        }
        if (query.getTrackingId() != null && !query.getTrackingId().isEmpty() &&
                !msg.getTrackingId().toLowerCase().contains(query.getTrackingId().toLowerCase())) {
            return false;
        }
        return true;
    }
}
