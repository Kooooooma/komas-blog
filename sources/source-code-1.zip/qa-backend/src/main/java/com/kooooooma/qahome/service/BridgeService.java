package com.kooooooma.qahome.service;

import com.kooooooma.qahome.dto.BridgeMessageDto;
import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.entity.TestExecution;
import com.kooooooma.qahome.enums.BridgeMessageType;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class BridgeService {
    // User SSE connections: userId -> emitter
    private final ConcurrentHashMap<String, SseEmitter> employeeEmitterMapping = new ConcurrentHashMap<>();
    // Bridge SSE connections: bridgeUuid -> emitter
    private final ConcurrentHashMap<String, SseEmitter> bridgeEmitterMapping = new ConcurrentHashMap<>();
    // User to Bridge binding: userId -> bridgeUuid
    private final ConcurrentHashMap<String, String> employeeBridgeBinding = new ConcurrentHashMap<>();

    @Autowired
    private ExecutionService executionService;

    public SseEmitter register(String source, String employeeId, String bridgeUuid) {
        if ("user".equals(source)) {
            return registerUser(employeeId);
        } else if ("bridge".equals(source)) {
            return registerBridge(bridgeUuid);
        }
        throw new RuntimeException("Unknown source " + source);
    }

    public SseEmitter registerUser(String employeeId) {
        if (StringUtils.isEmpty(employeeId)) {
            throw new RuntimeException("employeeId is empty");
        }

        SseEmitter existingEmitter = employeeEmitterMapping.get(employeeId);
        if (existingEmitter != null) {
            try {
                existingEmitter.complete();
            } catch (Exception e) {
                log.warn("Error when completing existing user emitter", e);
            } finally {
                employeeEmitterMapping.remove(employeeId, existingEmitter);
            }
        }

        SseEmitter emitter = new SseEmitter(Long.MAX_VALUE);

        emitter.onCompletion(() -> {
            log.info("Emitter completed. employeeId: {}, emitter: {}", employeeId, emitter);
            employeeEmitterMapping.remove(employeeId, emitter);
        });
        emitter.onTimeout(() -> {
            log.info("Emitter timout. employeeId: {}, emitter: {}", employeeId, emitter);
            employeeEmitterMapping.remove(employeeId, emitter);
        });
        emitter.onError((e) -> {
            log.info("Emitter error. employeeId: {}, emitter: {}", employeeId, emitter);
            employeeEmitterMapping.remove(employeeId, emitter);
        });

        employeeEmitterMapping.put(employeeId, emitter);
        log.info("User registered: {}", employeeId);
        return emitter;
    }

    public SseEmitter registerBridge(String bridgeUuid) {
        if (StringUtils.isEmpty(bridgeUuid)) {
            throw new RuntimeException("BridgeUuid is empty");
        }

        SseEmitter existingEmitter = bridgeEmitterMapping.get(bridgeUuid);
        if (existingEmitter != null) {
            try {
                existingEmitter.complete();
            } catch (Exception e) {
                log.warn("Error completing existing bridge emitter", e);
            } finally {
                bridgeEmitterMapping.remove(bridgeUuid, existingEmitter);
            }
        }

        SseEmitter emitter = new SseEmitter(Long.MAX_VALUE);

        emitter.onCompletion(() -> {
            log.info("Emitter completed. bridgeUuid: {}, emitter: {}", bridgeUuid, emitter);
            bridgeEmitterMapping.remove(bridgeUuid, emitter);
        });
        emitter.onTimeout(() -> {
            log.info("Emitter timout. bridgeUuid: {}, emitter: {}", bridgeUuid, emitter);
            bridgeEmitterMapping.remove(bridgeUuid, emitter);
        });
        emitter.onError((e) -> {
            log.info("Emitter error. bridgeUuid: {}, emitter: {}", bridgeUuid, emitter);
            bridgeEmitterMapping.remove(bridgeUuid, emitter);
        });

        bridgeEmitterMapping.put(bridgeUuid, emitter);
        log.info("Bridge registered: {}", bridgeUuid);
        return emitter;
    }

    public boolean bindUserToBridge(String employeeId, String bridgeUuid) {
        if (StringUtils.isEmpty(employeeId) || StringUtils.isEmpty(bridgeUuid)) {
            throw new RuntimeException("EmployeeId and BridgeUuid are required");
        }

        if (!bridgeEmitterMapping.containsKey(bridgeUuid)) {
            throw new RuntimeException("Bridge not found: " + bridgeUuid);
        }
        employeeBridgeBinding.put(employeeId, bridgeUuid);
        log.info("User {} bound to bridge {}", employeeId, bridgeUuid);

        log.error("bindUserToBridge - after - bridgeEmitterMapping: {}, employeeEmitterMapping: {}", bridgeEmitterMapping, employeeEmitterMapping);
        return true;
    }

    public boolean isUserBridgeConnected(String employeeId) {
        String bridgeUuid = employeeBridgeBinding.get(employeeId);
        return StringUtils.isNotEmpty(bridgeUuid) && bridgeEmitterMapping.containsKey(bridgeUuid);
    }

    public void pingBridge(String employeeId) {
        String bridgeUuid = employeeBridgeBinding.get(employeeId);
        if (StringUtils.isEmpty(bridgeUuid)) {
            throw new RuntimeException("User not bound to any bridge");
        }

        SseEmitter emitter = bridgeEmitterMapping.get(bridgeUuid);
        if (Objects.isNull(emitter)) {
            throw new RuntimeException("Bridge not connected: " + bridgeUuid);
        }

        try {
            emitter.send(SseEmitter.event().data(BridgeMessageDto.builder()
                    .eventType(BridgeMessageType.PING)
                    .build()));
            log.info("Ping sent to bridge {} from user {}", bridgeUuid, employeeId);
        } catch (Exception e) {
            log.error("Failed to send ping to bridge {}", bridgeUuid, e);
            throw new RuntimeException("Failed to send ping to bridge", e);
        }
    }

    public void pongUser(SseEmitter emitter, String employeeId, String bridgeUuid) {
        try {
            emitter.send(SseEmitter.event().data(BridgeMessageDto.builder()
                    .eventType(BridgeMessageType.PONG)
                    .bridgeUuid(bridgeUuid)
                    .build()));
            log.info("Pong sent to user {} from bridge {}", employeeId, bridgeUuid);
        } catch (Exception e) {
            log.error("Failed to send pong to user {}", employeeId, e);
            throw new RuntimeException("Failed to send pong to user " + employeeId, e);
        }
    }

    public void record(BridgeMessageDto bridgeMessageDto, String employeeId) {
        log.info("Received record request for URL: {}, from employeeId: {}", bridgeMessageDto.getEventPayload(), employeeId);

        String bridgeUuid = employeeBridgeBinding.get(employeeId);
        if (StringUtils.isEmpty(bridgeUuid)) {
            throw new RuntimeException("User not bound to any bridge");
        }

        SseEmitter emitter = bridgeEmitterMapping.get(bridgeUuid);
        if (Objects.isNull(emitter)) {
            throw new RuntimeException("Bridge not connected: " + bridgeUuid);
        }

        try {
            emitter.send(SseEmitter.event().data(BridgeMessageDto.builder()
                    .eventType(BridgeMessageType.RECORD)
                    .eventPayload(bridgeMessageDto.getEventPayload())
                    .build()));
            log.info("Record command sent to bridge {} for employeeId {}", bridgeUuid, employeeId);
        } catch (Exception e) {
            log.error("Send record event to bridge error: {}", bridgeUuid, e);
            emitter.completeWithError(e);//complete with error to trigger reconnect
            throw new RuntimeException("Send record event to bridge error: " + bridgeUuid, e);
        }
    }

    public void runCase(TestCase testCase, TestExecution testExecution, String employeeId, BridgeMessageType messageType, boolean headless) {
        log.info("Received run case request for caseId: {}, from employeeId: {}, headless: {}, messageType: {}", testCase.getId(), employeeId, headless, messageType);

        String bridgeUuid = employeeBridgeBinding.get(employeeId);
        if (StringUtils.isEmpty(bridgeUuid)) {
            log.error("User not bound to any bridge, employeeId {}", employeeId);
            throw new RuntimeException("User not bound to any bridge");
        }

        SseEmitter emitter = bridgeEmitterMapping.get(bridgeUuid);
        if (Objects.isNull(emitter)) {
            log.error("Bridge not connected, bridgeUuid: {} ", bridgeUuid);
            throw new RuntimeException("Bridge not connected: " + bridgeUuid);
        }

        try {
            Map<String, String> eventPayload = new HashMap<>();
            eventPayload.put("testCaseId", testCase.getId().toString());
            eventPayload.put("executionId", testExecution.getId().toString());
            eventPayload.put("script", testCase.getScript());
            eventPayload.put("headless", String.valueOf(headless));
            emitter.send(SseEmitter.event().data(BridgeMessageDto.builder()
                    .eventType(messageType)
                    .eventPayload(eventPayload)
                    .build()));
            log.info("Run command sent to bridge {} for test case {}", bridgeUuid, testCase.getId());
        } catch (Exception e) {
            log.error("Send run event to bridge error: {}", bridgeUuid, e);
            emitter.completeWithError(e);//complete with error to trigger reconnect
            throw new RuntimeException("Send run event to bridge error: " + bridgeUuid, e);
        }
    }

    public void notifyUser(BridgeMessageDto bridgeMessageDto) {
        String bridgeUuid = bridgeMessageDto.getBridgeUuid();
        log.info("Received notification from bridge: {}, message type: {}", bridgeUuid, bridgeMessageDto.getEventType());

        log.error("bindUserToBridge - bridgeEmitterMapping: {}, employeeEmitterMapping: {}", bridgeEmitterMapping, employeeEmitterMapping);

        String employeeId = "";
        for (var entry : employeeBridgeBinding.entrySet()) {
            if (bridgeMessageDto.getBridgeUuid().equals(entry.getValue())) {
                employeeId = entry.getKey();
                break;
            }
        }
        if (StringUtils.isEmpty(employeeId)) {
            log.error("No user bound to bridge: {}", bridgeUuid);
            throw new RuntimeException("No user bound to bridge: " + bridgeUuid);
        }

        SseEmitter emitter = employeeEmitterMapping.get(employeeId);
        if (Objects.isNull(emitter)) {
            log.error("User {} emitter not found", employeeId);
            throw new RuntimeException("Not found use registered emitter");
        }

        if (BridgeMessageType.PONG.equals(bridgeMessageDto.getEventType())) {
            pongUser(emitter, employeeId, bridgeUuid);
            return;
        }

        try {
            if (BridgeMessageType.RECORD_FINISHED.equals(bridgeMessageDto.getEventType())) {
                log.info("RECORD_FINISHED event from bridge {} bridgeMessageDto: {}", bridgeUuid, bridgeMessageDto);
            }

            if (BridgeMessageType.EXECUTION_FINISHED.equals(bridgeMessageDto.getEventType())) {
                log.info("EXECUTION_FINISHED event from bridge {} bridgeMessageDto: {}", bridgeUuid, bridgeMessageDto);
                executionService.updateExecutionFromBridgeEvent(bridgeMessageDto);
                bridgeMessageDto.setEventPayload(null);
            }

            emitter.send(SseEmitter.event().data(bridgeMessageDto));
            log.info("Notification sent to user {} from bridge {}", employeeId, bridgeUuid);
        } catch (Exception e) {
            log.error("Send notify event to user error: {}", employeeId, e);
            emitter.completeWithError(e);
            throw new RuntimeException("Send notify event to user error: " + employeeId, e);
        }
    }

    public String getUserBridgeUuid(String employeeId) {
        return employeeBridgeBinding.get(employeeId);
    }
}
