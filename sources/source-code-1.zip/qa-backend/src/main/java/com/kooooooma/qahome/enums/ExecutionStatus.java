package com.kooooooma.qahome.enums;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public enum ExecutionStatus {
    PENDING,
    FAST_FAILED,
    RUNNING,
    SUCCESS,
    FAILED
}
