package com.kooooooma.qahome.dagengine;

import com.kooooooma.qahome.dto.ContractDto;
import com.kooooooma.qahome.dto.NodeDto;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class GraphAnalyzer {
    private final static Logger logger = LoggerFactory.getLogger(GraphAnalyzer.class);

    public static List<GraphStage> analyzeGraph(ContractDto contractDTO) {
        List<GraphStage> graphStageList = new ArrayList<>();

        Map<String, NodeDto> nodeMap = new HashMap<>();
        contractDTO.getNodes().forEach(node -> nodeMap.put(node.getId(), node));

        Map<String, Integer> inDegreeMap = new HashMap<>();
        Map<String, List<String>> adjacencyTable = new HashMap<>();
        contractDTO.getNodes().forEach(node -> {
            inDegreeMap.put(node.getId(), 0);
            adjacencyTable.put(node.getId(), new ArrayList<>());
        });

        contractDTO.getEdges().forEach(edge -> {
            adjacencyTable.get(edge.getSource()).add(edge.getTarget());
            inDegreeMap.put(edge.getTarget(), inDegreeMap.get(edge.getTarget()) + 1);
        });

        // Use Kahn's alg to process graph
        List<String> currentLevelNodeIdList = new ArrayList<>();
        int level = 0;
        do {
            currentLevelNodeIdList.clear();

            // get current level node id
            Iterator<Map.Entry<String, Integer>> it = inDegreeMap.entrySet().iterator();
            while (it.hasNext()) {
                Map.Entry<String, Integer> entry = it.next();
                if (entry.getValue() == 0) {
                    currentLevelNodeIdList.add(entry.getKey());
                    it.remove();
                }
            }

            if (currentLevelNodeIdList.isEmpty()) {
                break; // process done
            }

            // process current level
            List<NodeDto> stageNodeList = new ArrayList<>();
            currentLevelNodeIdList.forEach(nodeId -> {
                stageNodeList.add(nodeMap.get(nodeId)); // get current level node
                // update current node's adjacency node's indegree(core of the Kahn's alg)
                adjacencyTable.get(nodeId).forEach(adjId -> inDegreeMap.put(adjId, inDegreeMap.get(adjId) - 1));
            });

            graphStageList.add(GraphStage.builder()
                    .nodes(stageNodeList)
                    .level(level++)
                    .build());
        } while (true);

        if (!inDegreeMap.isEmpty()) {
            throw new RuntimeException("Graph has cycle");
        }

        // make sure the order is correct
        graphStageList.sort(Comparator.comparingInt(GraphStage::getLevel));
        return graphStageList;
    }
}
