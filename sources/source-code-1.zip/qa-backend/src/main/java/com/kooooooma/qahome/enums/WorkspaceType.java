package com.kooooooma.qahome.enums;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public enum WorkspaceType {
    STANDARD,
    ORCHESTRATION
}
