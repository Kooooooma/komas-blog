package com.kooooooma.qahome.repository;

import com.kooooooma.qahome.entity.TestExecution;
import com.kooooooma.qahome.enums.ExecutionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public interface TestExecutionRepository extends JpaRepository<TestExecution, UUID> {
    List<TestExecution> findAllById(UUID id);

    @Transactional
    @Modifying
    @Query("UPDATE TestExecution te SET te.status = :status, te.endTime = :endTime WHERE te.id IN :ids")
    int updateStatusAndEndTimeByIds(@Param("ids") List<UUID> ids, @Param("status") ExecutionStatus status, @Param("endTime") LocalDateTime endTime);
}
