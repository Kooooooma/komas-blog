package com.kooooooma.qahome.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class AttachRequest {
    private List<ServerRequest> requests;

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ServerRequest {
        private String server;
        private List<String> pids;
    }
}
