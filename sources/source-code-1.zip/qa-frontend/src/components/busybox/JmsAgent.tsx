"use client";

import { useState, useEffect } from 'react';
import {
    Select, Input, Button, Checkbox, Space, Divider, Table, Modal,
    message, Card, Typography, Tag, Row, Col
} from 'antd';
import type { TableProps, TableColumnsType } from 'antd';
import {
    useConnectserverList,
    JvmInfo,
    JmsMessage,
    JmsMessageQuery,
    discoverJvms,
    attachAgent,
    queryJmsMessages
} from '@/libs/component';

const { Title, Text } = Typography;
const { TextArea } = Input;

interface SelectedJvm extends JvmInfo {
    selected: boolean;
}

interface GroupedJvms {
    [server: string]: SelectedJvm[];
}

export default function JmsAgent() {
    // Area 1: JVM Discovery
    const { connectserverList } = useConnectserverList();
    const [selectedServer, setSelectedServer] = useState<string>('');
    const [appNameKeyword, setAppNameKeyword] = useState<string>('');
    const [discoveredJvms, setDiscoveredJvms] = useState<JvmInfo[]>([]);
    const [searchLoading, setSearchLoading] = useState(false);

    // Area 2: Selected JVMs
    const [selectedJvms, setSelectedJvms] = useState<GroupedJvms>({});
    const [attachLoading, setAttachLoading] = useState(false);

    // Area 3: JMS Messages
    const [jmsMessages, setJmsMessages] = useState<JmsMessage[]>([]);
    const [totalMessages, setTotalMessages] = useState(0);
    const [messageQuery, setMessageQuery] = useState<JmsMessageQuery>({
        page: 0,
        size: 20,
    });
    const [messageLoading, setMessageLoading] = useState(false);
    const [detailModalVisible, setDetailModalVisible] = useState(false);
    const [selectedMessage, setSelectedMessage] = useState<JmsMessage | null>(null);

    // Area 1: Handle JVM discovery
    const handleSearch = async () => {
        if (!selectedServer) {
            message.warning('Please select a server');
            return;
        }

        setSearchLoading(true);
        try {
            const jvms = await discoverJvms(selectedServer, appNameKeyword);
            setDiscoveredJvms(jvms);
            message.success(`Found ${jvms.length} JVMs`);
        } catch (error) {
            message.error('Failed to discover JVMs');
            console.error(error);
        } finally {
            setSearchLoading(false);
        }
    };

    // Area 1: Handle JVM selection from discovery
    const handleJvmSelect = (jvm: JvmInfo, checked: boolean) => {
        if (checked) {
            setSelectedJvms(prev => {
                const serverJvms = prev[jvm.server] || [];
                const exists = serverJvms.find(j => j.pid === jvm.pid);
                if (exists) return prev;

                return {
                    ...prev,
                    [jvm.server]: [...serverJvms, { ...jvm, selected: true }]
                };
            });
        }
    };

    // Area 2: Toggle JVM selection in selected area
    const toggleJvmSelection = (server: string, pid: string) => {
        setSelectedJvms(prev => ({
            ...prev,
            [server]: prev[server].map(jvm =>
                jvm.pid === pid ? { ...jvm, selected: !jvm.selected } : jvm
            )
        }));
    };

    // Area 2: Select/Deselect all in a server group
    const toggleServerGroup = (server: string, selectAll: boolean) => {
        setSelectedJvms(prev => ({
            ...prev,
            [server]: prev[server].map(jvm => ({ ...jvm, selected: selectAll }))
        }));
    };

    // Area 2: Global select/deselect all
    const toggleGlobalSelection = (selectAll: boolean) => {
        setSelectedJvms(prev => {
            const updated: GroupedJvms = {};
            Object.keys(prev).forEach(server => {
                updated[server] = prev[server].map(jvm => ({ ...jvm, selected: selectAll }));
            });
            return updated;
        });
    };

    // Area 2: Attach JMS Agent
    const handleAttachAgent = async () => {
        const requests = Object.entries(selectedJvms)
            .map(([server, jvms]) => ({
                server,
                pids: jvms.filter(jvm => jvm.selected && !jvm.agentAttached).map(jvm => jvm.pid)
            }))
            .filter(req => req.pids.length > 0);

        if (requests.length === 0) {
            message.warning('No JVMs selected for attachment');
            return;
        }

        setAttachLoading(true);
        try {
            const result = await attachAgent({ requests });

            // Update agent attached status
            setSelectedJvms(prev => {
                const updated: GroupedJvms = {};
                Object.keys(prev).forEach(server => {
                    updated[server] = prev[server].map(jvm => ({
                        ...jvm,
                        agentAttached: result[server]?.[jvm.pid] ? true : jvm.agentAttached
                    }));
                });
                return updated;
            });

            message.success('Agent attachment completed');
        } catch (error) {
            message.error('Failed to attach agent');
            console.error(error);
        } finally {
            setAttachLoading(false);
        }
    };

    // Area 3: Load initial JMS messages on component mount
    useEffect(() => {
        loadJmsMessages(messageQuery);
    }, []);

    // Area 3: Load JMS messages
    const loadJmsMessages = async (query: JmsMessageQuery) => {
        setMessageLoading(true);
        try {
            const result = await queryJmsMessages(query);
            setJmsMessages(result.content);
            setTotalMessages(result.totalElements);
        } catch (error) {
            message.error('Failed to load JMS messages');
            console.error(error);
        } finally {
            setMessageLoading(false);
        }
    };

    // Area 3: Handle message table changes
    const handleTableChange: TableProps<JmsMessage>['onChange'] = (pagination) => {
        const newQuery = {
            ...messageQuery,
            page: (pagination.current || 1) - 1,
            size: pagination.pageSize || 20,
        };
        setMessageQuery(newQuery);
        loadJmsMessages(newQuery);
    };

    // Area 3: Handle filter changes
    const handleFilterChange = (field: keyof JmsMessageQuery, value: string) => {
        const newQuery = {
            ...messageQuery,
            [field]: value || undefined,
            page: 0, // Reset to first page when filtering
        };
        setMessageQuery(newQuery);
        loadJmsMessages(newQuery);
    };

    // Area 3: Show message detail modal
    const showMessageDetail = (message: JmsMessage) => {
        setSelectedMessage(message);
        setDetailModalVisible(true);
    };

    // Area 3: Table columns definition
    const messageColumns: TableColumnsType<JmsMessage> = [
        {
            title: 'VPN',
            dataIndex: 'vpn',
            key: 'vpn',
            width: 80,
            ellipsis: true,
            filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => (
                <div style={{ padding: 8 }}>
                    <Input
                        placeholder="Search VPN"
                        value={selectedKeys[0]}
                        onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                        onPressEnter={() => {
                            confirm();
                            handleFilterChange('vpn', selectedKeys[0] as string);
                        }}
                        style={{ width: 188, marginBottom: 8, display: 'block' }}
                    />
                    <Button
                        type="primary"
                        size="small"
                        onClick={() => {
                            confirm();
                            handleFilterChange('vpn', selectedKeys[0] as string);
                        }}
                    >
                        Search
                    </Button>
                </div>
            ),
        },
        {
            title: 'Type',
            dataIndex: 'type',
            key: 'type',
            width: 70,
            render: (type: string) => (
                <Tag color={type === 'TOPIC' ? 'blue' : 'green'}>{type}</Tag>
            ),
            filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => (
                <div style={{ padding: 8 }}>
                    <Select
                        placeholder="Select Type"
                        value={selectedKeys[0]}
                        onChange={value => {
                            setSelectedKeys(value ? [value] : []);
                            confirm();
                            handleFilterChange('type', value as string);
                        }}
                        style={{ width: 188 }}
                        options={[
                            { label: 'TOPIC', value: 'TOPIC' },
                            { label: 'QUEUE', value: 'QUEUE' },
                        ]}
                    />
                </div>
            ),
        },
        {
            title: 'Destination',
            dataIndex: 'destination',
            key: 'destination',
            width: 120,
            ellipsis: true,
            filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => (
                <div style={{ padding: 8 }}>
                    <Input
                        placeholder="Search Destination"
                        value={selectedKeys[0]}
                        onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                        onPressEnter={() => {
                            confirm();
                            handleFilterChange('destination', selectedKeys[0] as string);
                        }}
                        style={{ width: 188, marginBottom: 8, display: 'block' }}
                    />
                    <Button
                        type="primary"
                        size="small"
                        onClick={() => {
                            confirm();
                            handleFilterChange('destination', selectedKeys[0] as string);
                        }}
                    >
                        Search
                    </Button>
                </div>
            ),
        },
        {
            title: 'Server',
            dataIndex: 'server',
            key: 'server',
            width: 80,
            ellipsis: true,
            filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => (
                <div style={{ padding: 8 }}>
                    <Input
                        placeholder="Search Server"
                        value={selectedKeys[0]}
                        onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                        onPressEnter={() => {
                            confirm();
                            handleFilterChange('server', selectedKeys[0] as string);
                        }}
                        style={{ width: 188, marginBottom: 8, display: 'block' }}
                    />
                    <Button
                        type="primary"
                        size="small"
                        onClick={() => {
                            confirm();
                            handleFilterChange('server', selectedKeys[0] as string);
                        }}
                    >
                        Search
                    </Button>
                </div>
            ),
        },
        {
            title: 'App Name',
            dataIndex: 'appName',
            key: 'appName',
            width: 100,
            ellipsis: true,
            filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => (
                <div style={{ padding: 8 }}>
                    <Input
                        placeholder="Search App Name"
                        value={selectedKeys[0]}
                        onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                        onPressEnter={() => {
                            confirm();
                            handleFilterChange('appName', selectedKeys[0] as string);
                        }}
                        style={{ width: 188, marginBottom: 8, display: 'block' }}
                    />
                    <Button
                        type="primary"
                        size="small"
                        onClick={() => {
                            confirm();
                            handleFilterChange('appName', selectedKeys[0] as string);
                        }}
                    >
                        Search
                    </Button>
                </div>
            ),
        },
        {
            title: 'Time',
            dataIndex: 'time',
            key: 'time',
            width: 140,
            ellipsis: true,
            render: (time: string) => new Date(time).toLocaleString(),
        },
        {
            title: 'Tracking ID',
            dataIndex: 'trackingId',
            key: 'trackingId',
            width: 110,
            ellipsis: true,
            filterDropdown: ({ setSelectedKeys, selectedKeys, confirm }) => (
                <div style={{ padding: 8 }}>
                    <Input
                        placeholder="Search Tracking ID"
                        value={selectedKeys[0]}
                        onChange={e => setSelectedKeys(e.target.value ? [e.target.value] : [])}
                        onPressEnter={() => {
                            confirm();
                            handleFilterChange('trackingId', selectedKeys[0] as string);
                        }}
                        style={{ width: 188, marginBottom: 8, display: 'block' }}
                    />
                    <Button
                        type="primary"
                        size="small"
                        onClick={() => {
                            confirm();
                            handleFilterChange('trackingId', selectedKeys[0] as string);
                        }}
                    >
                        Search
                    </Button>
                </div>
            ),
        },
        {
            title: 'Message',
            dataIndex: 'messageContent',
            key: 'messageContent',
            width: 100,
            ellipsis: true,
        },
        {
            title: 'Action',
            key: 'action',
            width: 70,
            fixed: 'right',
            render: (_, record) => (
                <Button type="link" size="small" onClick={() => showMessageDetail(record)}>
                    Detail
                </Button>
            ),
        },
    ];

    return (
        <div style={{ padding: '0px', height: '100%', overflow: 'auto' }}>
            {/* Area 1: JVM Discovery */}
            <Card title="JVM Discovery" style={{ marginBottom: 24 }}>
                <Space direction="vertical" style={{ width: '100%' }} size="middle">
                    <Row gutter={16}>
                        <Col span={6}>
                            <Select
                                placeholder="Select Server"
                                style={{ width: '100%' }}
                                value={selectedServer}
                                onChange={setSelectedServer}
                                options={connectserverList?.map(server => ({
                                    label: server,
                                    value: server,
                                }))}
                            />
                        </Col>
                        <Col span={8}>
                            <Input
                                placeholder="App Name Keyword"
                                value={appNameKeyword}
                                onChange={e => setAppNameKeyword(e.target.value)}
                                onPressEnter={handleSearch}
                            />
                        </Col>
                        <Col span={4}>
                            <Button type="primary" onClick={handleSearch} loading={searchLoading}>
                                Search
                            </Button>
                        </Col>
                    </Row>

                    {discoveredJvms.length > 0 && (
                        <Card size="small" title={`Found ${discoveredJvms.length} JVMs`}>
                            <Space direction="vertical" style={{ width: '100%' }}>
                                {discoveredJvms.map(jvm => (
                                    <div key={`${jvm.server}-${jvm.pid}`} style={{ marginBottom: 8 }}>
                                        <Checkbox
                                            onChange={e => handleJvmSelect(jvm, e.target.checked)}
                                            disabled={jvm.agentAttached}
                                        >
                                            <Text strong>PID: {jvm.pid}</Text>
                                            <Text style={{ marginLeft: 16 }}>{jvm.appName}</Text>
                                            {jvm.agentAttached && (
                                                <Tag color="green" style={{ marginLeft: 8 }}>Agent Attached</Tag>
                                            )}
                                        </Checkbox>
                                    </div>
                                ))}
                            </Space>
                        </Card>
                    )}
                </Space>
            </Card>

            {/* Area 2: Selected JVMs Management */}
            <Card title="Selected JVMs" style={{ marginBottom: 24 }}>
                <Space direction="vertical" style={{ width: '100%' }} size="middle">
                    <Space>
                        <Button onClick={() => toggleGlobalSelection(true)}>
                            Select All
                        </Button>
                        <Button onClick={() => toggleGlobalSelection(false)}>
                            Deselect All
                        </Button>
                        <Button
                            type="primary"
                            onClick={handleAttachAgent}
                            loading={attachLoading}
                            disabled={Object.values(selectedJvms).every(jvms =>
                                jvms.every(jvm => !jvm.selected || jvm.agentAttached)
                            )}
                        >
                            Attach JMS Agent
                        </Button>
                    </Space>

                    {Object.entries(selectedJvms).map(([server, jvms]) => (
                        <Card
                            size="small"
                            key={server}
                            title={<Text strong>Server: {server}</Text>}
                            extra={
                                <Space>
                                    <Button size="small" onClick={() => toggleServerGroup(server, true)}>
                                        Select All
                                    </Button>
                                    <Button size="small" onClick={() => toggleServerGroup(server, false)}>
                                        Deselect All
                                    </Button>
                                </Space>
                            }
                        >
                            <Space direction="vertical" style={{ width: '100%' }}>
                                {jvms.map(jvm => (
                                    <div
                                        key={jvm.pid}
                                        style={{
                                            padding: 8,
                                            backgroundColor: jvm.agentAttached ? '#f6ffed' : 'transparent',
                                            borderRadius: 4,
                                        }}
                                    >
                                        <Checkbox
                                            checked={jvm.selected}
                                            onChange={() => toggleJvmSelection(server, jvm.pid)}
                                            disabled={jvm.agentAttached}
                                        >
                                            <Text strong>PID: {jvm.pid}</Text>
                                            <Text style={{ marginLeft: 16 }}>{jvm.appName}</Text>
                                            {jvm.agentAttached && (
                                                <Tag color="green" style={{ marginLeft: 8 }}>Agent Attached</Tag>
                                            )}
                                        </Checkbox>
                                    </div>
                                ))}
                            </Space>
                        </Card>
                    ))}
                </Space>
            </Card>

            <Divider />

            {/* Area 3: JMS Message Table */}
            <Card title="JMS Messages">
                <Table<JmsMessage>
                    columns={messageColumns}
                    dataSource={jmsMessages}
                    rowKey={(record) => `${record.server}-${record.trackingId}`}
                    loading={messageLoading}
                    pagination={{
                        current: messageQuery.page + 1,
                        pageSize: messageQuery.size,
                        total: totalMessages,
                        showSizeChanger: true,
                        showTotal: (total) => `Total ${total} messages`,
                    }}
                    onChange={handleTableChange}
                />
            </Card>

            {/* Message Detail Modal */}
            <Modal
                title="Message Details"
                open={detailModalVisible}
                onCancel={() => setDetailModalVisible(false)}
                footer={[
                    <Button key="close" onClick={() => setDetailModalVisible(false)}>
                        Close
                    </Button>
                ]}
                width={800}
            >
                {selectedMessage && (
                    <Space direction="vertical" style={{ width: '100%' }} size="middle">
                        <div>
                            <Text strong>VPN: </Text>
                            <Text>{selectedMessage.vpn}</Text>
                        </div>
                        <div>
                            <Text strong>Type: </Text>
                            <Tag color={selectedMessage.type === 'TOPIC' ? 'blue' : 'green'}>
                                {selectedMessage.type}
                            </Tag>
                        </div>
                        <div>
                            <Text strong>Destination: </Text>
                            <Text>{selectedMessage.destination}</Text>
                        </div>
                        <div>
                            <Text strong>Server: </Text>
                            <Text>{selectedMessage.server}</Text>
                        </div>
                        <div>
                            <Text strong>App Name: </Text>
                            <Text>{selectedMessage.appName}</Text>
                        </div>
                        <div>
                            <Text strong>Time: </Text>
                            <Text>{new Date(selectedMessage.time).toLocaleString()}</Text>
                        </div>
                        <div>
                            <Text strong>Tracking ID: </Text>
                            <Text>{selectedMessage.trackingId}</Text>
                        </div>
                        <div>
                            <Text strong>Message Content: </Text>
                            <TextArea
                                value={selectedMessage.messageContent}
                                autoSize={{ minRows: 10, maxRows: 20 }}
                                readOnly
                                style={{ marginTop: 8 }}
                            />
                        </div>
                    </Space>
                )}
            </Modal>
        </div>
    );
}
