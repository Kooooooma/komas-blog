"use client";

import { Card, Typography, Button, Spin } from "antd";
import { HighlightOutlined } from '@ant-design/icons';
import { X, GripVertical } from 'lucide-react';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { capitalize } from 'lodash';

const { Text } = Typography;

interface DraggableCaseCardProps {
    laneId: string;
    laneCaseMappingId: string;
    caseId: string;
    caseName: string;
    caseType: string;
    lastExecutionStatus?: string;
    lastExecutionTime?: string;
    getStatusColor: (status?: string) => string;
    formatDateTime: (dateStr?: string) => string;
    onEdit: () => void;
    onRemove: () => void;
    getRunningStatus: (laneId: string, caseId: string) => boolean;
}

export default function DraggableCaseCard({
    laneId,
    laneCaseMappingId,
    caseId,
    caseName,
    caseType,
    lastExecutionStatus,
    lastExecutionTime,
    getStatusColor,
    getRunningStatus,
    formatDateTime,
    onEdit,
    onRemove,
}: DraggableCaseCardProps) {
    const {
        attributes,
        listeners,
        setNodeRef,
        transform,
        transition,
        isDragging,
    } = useSortable({ id: laneCaseMappingId });

    const style: React.CSSProperties = {
        transform: CSS.Transform.toString(transform),
        transition,
        opacity: isDragging ? 0.5 : 1,
        flexShrink: 0,
    };

    return (
        <div ref={setNodeRef} style={style}>
            <Spin tip={capitalize(lastExecutionStatus).concat('...')} spinning={getRunningStatus(laneId, caseId)}>
                <Card
                    style={{ width: 280, borderColor: getStatusColor(lastExecutionStatus) }}
                    title={<Text ellipsis={{ tooltip: caseName }}>{caseName}</Text>}
                    hoverable={true}
                    extra={
                        <>
                            <Button
                                type="text"
                                icon={<GripVertical size={16} />}
                                style={{ cursor: 'grab', color: '#999' }}
                                {...attributes}
                                {...listeners}
                            />
                            <Button
                                type="text"
                                icon={<HighlightOutlined />}
                                style={{ color: 'green' }}
                                onClick={onEdit}
                            />
                            <Button
                                type="text"
                                danger
                                icon={<X size={16} />}
                                onClick={onRemove}
                            />
                        </>
                    }
                >
                    <p>Last Run Status: <Text style={{ color: getStatusColor(lastExecutionStatus) }}>{lastExecutionStatus || 'N/A'}</Text></p>
                    <p>Last Run Time: <Text>{formatDateTime(lastExecutionTime)}</Text></p>
                    <p style={{ marginTop: '10px' }}>Case Type: <Text strong>{caseType}</Text></p>
                </Card>
            </Spin>
        </div>
    );
}
