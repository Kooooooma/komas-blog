"use client";

import { Flex, Typography, Progress, Button, message, Empty, Spin, Modal, Select, Input, Popconfirm } from "antd";
import { green, red, gray } from "@ant-design/colors";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import { PackagePlus, SquarePlay, Grid2x2Plus, Siren } from 'lucide-react';
import {
    createLane, addCaseToLane, runLane,
    getWorkspacesByEmployee, deleteLane, removeCaseFromLane, updateLaneName, updateLaneOrder
} from "@/libs/lane";
import { useWorkspaceLanes, LaneData, LaneCase } from "@/libs/workspace";
import { getTestCasesByWorkspace, bindBridge, formatDateTime } from "@/libs/edit";
import { useCommonStore } from '@/store/commonStore';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { useEffect, useState } from "react";
import { useRouter } from 'next/navigation';
import SortableLaneCases from './SortableLaneCases';

interface WorkspaceOption {
    id: string;
    name: string;
    type: string;
}

interface CaseOption {
    case: {
        id: string;
        name: string;
        type: string;
    };
}

export default function OrchestrationWorkspace() {
    const { Title, Text } = Typography;
    const { workspaceId } = useCommonStore();
    const { employeeId } = useCurrentUser();
    const router = useRouter();
    const [messageApi, messageContextHolder] = message.useMessage();

    // Use SWR hook with 5-second auto-refresh
    const { lanes, isLoading, mutate: refreshLanes } = useWorkspaceLanes(workspaceId, 5000);

    // Add Case Modal states
    const [showAddCaseModal, setShowAddCaseModal] = useState(false);
    const [selectedLaneId, setSelectedLaneId] = useState<string | null>(null);
    const [workspaces, setWorkspaces] = useState<WorkspaceOption[]>([]);
    const [selectedWorkspaceId, setSelectedWorkspaceId] = useState<string | null>(null);
    const [cases, setCases] = useState<CaseOption[]>([]);
    const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
    const [isLoadingWorkspaces, setIsLoadingWorkspaces] = useState(false);
    const [isLoadingCases, setIsLoadingCases] = useState(false);

    // Update Lane Name Modal states
    const [showUpdateLaneNameModal, setShowUpdateLaneNameModal] = useState(false);
    const [updateLaneTarget, setUpdateLaneTarget] = useState<{ id: string; name: string } | null>(null);

    const handleAddLane = async () => {
        if (!workspaceId) return;
        try {
            const now = new Date();
            const name = `Lane ${now.toISOString().replace('T', ' ').substring(0, 19)}`;
            await createLane(workspaceId, name);
            messageApi.success('Lane created successfully');
            refreshLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to create lane');
        }
    };

    const handleOpenAddCaseModal = async (laneId: string) => {
        setSelectedLaneId(laneId);
        setSelectedWorkspaceId(null);
        setSelectedCaseId(null);
        setCases([]);
        setShowAddCaseModal(true);

        // Load workspaces
        if (employeeId) {
            setIsLoadingWorkspaces(true);
            try {
                const data = await getWorkspacesByEmployee(employeeId);
                setWorkspaces(data || []);
            } catch (err) {
                messageApi.error('Failed to load workspaces');
            } finally {
                setIsLoadingWorkspaces(false);
            }
        }
    };

    const handleWorkspaceChange = async (wsId: string) => {
        setSelectedWorkspaceId(wsId);
        setSelectedCaseId(null);
        setCases([]);

        // Load cases for selected workspace
        setIsLoadingCases(true);
        try {
            const data = await getTestCasesByWorkspace(wsId);
            setCases(data || []);
        } catch (err) {
            messageApi.error('Failed to load cases');
        } finally {
            setIsLoadingCases(false);
        }
    };

    const handleAddCaseConfirm = async () => {
        if (!selectedLaneId || !selectedCaseId) {
            messageApi.warning('Please select a case');
            return;
        }
        try {
            await addCaseToLane(selectedLaneId, selectedCaseId);
            messageApi.success('Case added to lane successfully');
            setShowAddCaseModal(false);
            refreshLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to add case');
        }
    };

    // Delete Lane Modal states
    const [showDeleteLaneModal, setShowDeleteLaneModal] = useState(false);
    const [deleteLaneTarget, setDeleteLaneTarget] = useState<{ id: string; name: string } | null>(null);

    const handleDeleteLane = (laneId: string, laneName: string) => {
        setDeleteLaneTarget({ id: laneId, name: laneName });
        setShowDeleteLaneModal(true);
    };

    const handleDeleteLaneConfirm = async () => {
        if (!deleteLaneTarget) return;
        try {
            await deleteLane(deleteLaneTarget.id);
            messageApi.success('Lane deleted successfully');
            setShowDeleteLaneModal(false);
            setDeleteLaneTarget(null);
            refreshLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to delete lane');
        }
    };

    const handleRemoveCase = async (id: string) => {
        try {
            await removeCaseFromLane(id);
            messageApi.success('Case removed from lane successfully');
            refreshLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to remove case');
        }
    };

    const handleOpenUpdateLaneNameModal = (laneId: string, laneName: string) => {
        setUpdateLaneTarget({ id: laneId, name: laneName });
        setShowUpdateLaneNameModal(true);
    };

    const handleUpdateLaneName = async () => {
        if (!updateLaneTarget) return;
        try {
            await updateLaneName(updateLaneTarget.id, updateLaneTarget.name);
            messageApi.success('Lane name updated');
            setShowUpdateLaneNameModal(false);
            setUpdateLaneTarget(null);
            refreshLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to update lane name');
        }
    };

    const handleReorderCases = async (laneId: string, newLaneCaseMappingIds: string[]) => {
        // Just call API in background, UI is already updated by SortableLaneCases local state
        try {
            await updateLaneOrder(laneId, newLaneCaseMappingIds);
        } catch (error) {
            console.error('Failed to update lane order:', error);
            // On error, refresh to get correct order from server
            refreshLanes();
        }
    };

    const getStatusColor = (status?: string) => {
        if (!status) return gray[5];
        switch (status.toUpperCase()) {
            case 'SUCCESS': return green[6];
            case 'FAILED': return red[5];
            case 'RUNNING': return '#1890ff';
            default: return gray[5];
        }
    };

    const getProgressSteps = (laneData: LaneData) => {
        const cases = laneData.cases || [];
        if (cases.length === 0) return { steps: 0, colors: [] };

        const colors = cases.map(c => getStatusColor(c.lastExecution?.status));
        return { steps: cases.length, colors };
    };

    const handleEditCase = (caseType: string, laneCaseMappingId: string) => {
        if (caseType === 'FRONTEND') {
            router.push(`/e2e?laneCaseMappingId=${laneCaseMappingId}`);
        } else {
            router.push(`/backend?laneCaseMappingId=${laneCaseMappingId}`);
        }
    };

    const getRunningStatus = (laneId: string, caseId: string): boolean => {
        if (!Array.isArray(lanes)) return false;
        const status = lanes.find(l => l.lane.id === laneId)
            ?.cases.find(c => c.case.id === caseId)
            ?.lastExecution?.status;
        return ['RUNNING', 'PENDING'].includes(status as string);
    };

    const getLaneRunningStatus = (laneId: string): boolean => {
        if (!Array.isArray(lanes)) return false;
        return lanes.find(l => l.lane.id === laneId)?.cases.some(c => ['RUNNING', 'PENDING'].includes(c.lastExecution?.status as string)) || false;
    };

    const getAllLanesRunningStatus = (): boolean => {
        if (!Array.isArray(lanes) || lanes.length === 0) return false;
        return lanes.every(lane => lane.cases.some(c => ['RUNNING', 'PENDING'].includes(c.lastExecution?.status as string)));
    };

    const handleRunLane = async (laneId: string) => {
        try {
            await runLane(laneId);
            refreshLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to run lane');
        }
    };

    const [connectionStatus, setConnectionStatus] = useState<'connected' | 'disconnected'>('disconnected');
    const [showBindModal, setShowBindModal] = useState(false);
    const [bridgeUuidInput, setBridgeUuidInput] = useState('');

    const handleBindBridge = () => {
        setShowBindModal(false);
        localStorage.setItem('bridgeUuid', bridgeUuidInput);
        handleSirenClick()
    }

    const handleSirenClick = async () => {
        const storedUuid = localStorage.getItem('bridgeUuid');
        if (storedUuid) {
            setBridgeUuidInput(storedUuid);
            try {
                messageApi.loading({ content: "Connecting to bridge [" + storedUuid + "]", key: "rebind", duration: 0 });
                await bindBridge(storedUuid);
                messageApi.success({ content: "Bridge connected [" + storedUuid + "]", key: "rebind" });
                setConnectionStatus('connected');
            } catch (err) {
                setConnectionStatus('disconnected');
                messageApi.destroy("rebind");
                messageApi.error(err instanceof Error ? "Failed to connect to bridge [" + storedUuid + "]" : 'Failed to connect to bridge');
            }
            return;
        }
        setShowBindModal(true);
    };

    useEffect(() => {
        handleSirenClick();
    }, []);

    const getConnectButtonStyle = () => {
        if (connectionStatus === 'disconnected') {
            return { color: '#ff4d4f', margin: '0 5px', padding: 0, cursor: 'pointer' };
        }
        return { color: '#52c41a', margin: '0 5px', padding: 0, cursor: 'pointer' };
    };

    return (
        <Flex vertical>
            <Flex align="center" justify="flex-end" gap="small" style={{ marginBottom: '15px', borderBottom: '1px solid #ccc', padding: '10px 0' }}>
                <Button type="primary" icon={<Grid2x2Plus size={14} />} onClick={handleAddLane}>
                    Add Lane
                </Button>
                <Siren size={22} style={getConnectButtonStyle()} onClick={handleSirenClick} />
                <Popconfirm title="Are you sure you want to run all lanes?">
                    <Button type="primary" icon={<SquarePlay size={14} />} disabled={getAllLanesRunningStatus()}>
                        {getAllLanesRunningStatus() ? 'Running' : 'Run All Lanes'}
                    </Button>
                </Popconfirm>
            </Flex>
            {isLoading ? (
                <Flex justify="center" style={{ padding: '50px' }}><Spin size="large" /></Flex>
            ) : !Array.isArray(lanes) || lanes.length === 0 ? (
                <Empty description="No lanes" style={{ marginTop: '50px' }} />
            ) : (
                lanes.map((laneData) => {
                    const { steps, colors } = getProgressSteps(laneData);
                    return (
                        <Flex key={laneData.lane.id} vertical style={{ marginBottom: '15px', borderBottom: '1px solid #ccc' }}>
                            <Flex align="center" justify="space-between">
                                <Flex align="center" justify="flex-start">
                                    <Title level={4} style={{ margin: 0 }}>{laneData.lane.name}</Title>
                                    <Button type="text" size="small" icon={<EditOutlined />} style={{ marginLeft: '5px' }} onClick={() => handleOpenUpdateLaneNameModal(laneData.lane.id, laneData.lane.name)} />
                                </Flex>
                                {steps > 0 && (
                                    <Progress
                                        showInfo={false}
                                        size={12}
                                        percent={100}
                                        steps={steps}
                                        strokeColor={colors}
                                    />
                                )}
                                <Flex align="center" gap="small" justify="flex-end">
                                    <Button type="default" icon={<PackagePlus size={14} />} onClick={() => handleOpenAddCaseModal(laneData.lane.id)} disabled={getLaneRunningStatus(laneData.lane.id)}>
                                        Add Case
                                    </Button>
                                    <Popconfirm title="Are you sure you want to run this lane?" onConfirm={() => handleRunLane(laneData.lane.id)}>
                                        <Button type="default" icon={<SquarePlay size={14} />} disabled={getLaneRunningStatus(laneData.lane.id)}>
                                            {getLaneRunningStatus(laneData.lane.id) ? 'Running' : 'Run Lane'}
                                        </Button>
                                    </Popconfirm>
                                    <Button type="default" danger icon={<DeleteOutlined />} onClick={() => handleDeleteLane(laneData.lane.id, laneData.lane.name)} disabled={getLaneRunningStatus(laneData.lane.id)}>
                                        Delete Lane
                                    </Button>
                                </Flex>
                            </Flex>
                            <SortableLaneCases
                                laneId={laneData.lane.id}
                                cases={laneData.cases}
                                getStatusColor={getStatusColor}
                                getRunningStatus={getRunningStatus}
                                formatDateTime={formatDateTime}
                                onEditCase={handleEditCase}
                                onRemoveCase={handleRemoveCase}
                                onReorder={handleReorderCases}
                            />
                        </Flex>
                    );
                })
            )}

            {/* Add Case Modal */}
            <Modal
                title="Add Case to Lane"
                open={showAddCaseModal}
                onOk={handleAddCaseConfirm}
                onCancel={() => setShowAddCaseModal(false)}
                okText="Add"
                okButtonProps={{ disabled: !selectedCaseId }}
            >
                <Flex vertical gap="middle" style={{ marginTop: '20px' }}>
                    <div>
                        <Text strong>Select Workspace:</Text>
                        <Select
                            style={{ width: '100%', marginTop: '8px' }}
                            placeholder="Select a workspace"
                            loading={isLoadingWorkspaces}
                            value={selectedWorkspaceId}
                            onChange={handleWorkspaceChange}
                            options={workspaces.map(ws => ({
                                value: ws.id,
                                label: `${ws.name} (${ws.type})`
                            }))}
                        />
                    </div>
                    <div>
                        <Text strong>Select Case:</Text>
                        <Select
                            style={{ width: '100%', marginTop: '8px' }}
                            placeholder={selectedWorkspaceId ? "Select a case" : "Please select a workspace first"}
                            loading={isLoadingCases}
                            disabled={!selectedWorkspaceId}
                            value={selectedCaseId}
                            onChange={(value) => setSelectedCaseId(value)}
                            options={cases.map(c => ({
                                value: c.case.id,
                                label: `${c.case.name} (${c.case.type})`
                            }))}
                        />
                    </div>
                </Flex>
            </Modal>

            {/* Delete Lane Confirmation Modal */}
            <Modal
                title="Delete Lane"
                open={showDeleteLaneModal}
                onOk={handleDeleteLaneConfirm}
                onCancel={() => {
                    setShowDeleteLaneModal(false);
                    setDeleteLaneTarget(null);
                }}
                okText="Delete"
                okType="danger"
                cancelText="Cancel"
            >
                <p>Are you sure you want to delete lane "{deleteLaneTarget?.name}"?</p>
                <p>This action cannot be undone.</p>
            </Modal>

            {/* Update Lane Name Modal */}
            <Modal
                title="Update Lane Name"
                open={showUpdateLaneNameModal}
                onOk={handleUpdateLaneName}
                onCancel={() => {
                    setShowUpdateLaneNameModal(false);
                    setUpdateLaneTarget(null);
                }}
            >
                <Input
                    style={{ margin: '15px 0' }}
                    value={updateLaneTarget?.name || ''}
                    onChange={(e) => setUpdateLaneTarget(prev => prev ? { ...prev, name: e.target.value } : null)}
                />
            </Modal>
            {/* Bind Bridge Modal */}
            <Modal open={showBindModal}
                title="Connect to Bridge"
                onOk={handleBindBridge}
                onCancel={() => setShowBindModal(false)}
                okText="Connect"
            >
                <Input
                    style={{ margin: '15px 0' }}
                    value={bridgeUuidInput}
                    onChange={(e) => setBridgeUuidInput(e.target.value)}
                    placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                />
            </Modal>
            {messageContextHolder}
        </Flex>
    );
}