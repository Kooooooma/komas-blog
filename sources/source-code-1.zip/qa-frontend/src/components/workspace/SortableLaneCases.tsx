"use client";

import { Flex, Typography } from "antd";
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, horizontalListSortingStrategy } from '@dnd-kit/sortable';
import DraggableCaseCard from './DraggableCaseCard';
import { useState, useEffect } from 'react';

const { Text } = Typography;

interface LaneCase {
    case: {
        id: string;
        name: string;
        type: string;
    };
    lanecasemapping: {
        id: string;
        laneId: string;
        testCaseId: string;
    };
    lastExecution?: {
        status: string;
        startTime: string;
    };
}

interface SortableLaneCasesProps {
    laneId: string;
    cases: LaneCase[];
    getStatusColor: (status?: string) => string;
    getRunningStatus: (laneId: string, caseId: string) => boolean;
    formatDateTime: (dateStr?: string) => string;
    onEditCase: (caseType: string, laneCaseMappingId: string) => void;
    onRemoveCase: (id: string) => void;
    onReorder: (laneId: string, newCaseIds: string[]) => void;
}

export default function SortableLaneCases({
    laneId,
    cases,
    getStatusColor,
    getRunningStatus,
    formatDateTime,
    onEditCase,
    onRemoveCase,
    onReorder,
}: SortableLaneCasesProps) {
    // Local state to manage order during drag
    const [localCases, setLocalCases] = useState<LaneCase[]>(cases);

    // Sync with props when cases change from outside
    useEffect(() => {
        setLocalCases(cases);
    }, [cases]);

    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                distance: 5,
            },
        }),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;
        if (over && active.id !== over.id) {
            console.log(`Drag end, active: ${active.id}, over: ${over.id}`);
            const oldIndex = localCases.findIndex(c => c.lanecasemapping.id === active.id);
            const newIndex = localCases.findIndex(c => c.lanecasemapping.id === over.id);

            // Update local state immediately for smooth transition
            const newCases = arrayMove(localCases, oldIndex, newIndex);
            setLocalCases(newCases);

            // Call API in background
            const newLaneCaseMappingIds = newCases.map(c => c.lanecasemapping.id);
            onReorder(laneId, newLaneCaseMappingIds);
        }
    };

    if (localCases.length === 0) {
        return <Text type="secondary">No cases in this lane</Text>;
    }

    return (
        <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
        >
            <SortableContext
                items={localCases.map(c => c.lanecasemapping.id)}
                strategy={horizontalListSortingStrategy}
            >
                <Flex wrap={false} style={{ overflowX: 'auto', padding: '10px' }} gap="middle">
                    {localCases.map((caseItem) => (
                        <DraggableCaseCard
                            key={caseItem.lanecasemapping.id}
                            laneCaseMappingId={caseItem.lanecasemapping.id}
                            caseId={caseItem.case.id}
                            laneId={laneId}
                            caseName={caseItem.case.name}
                            caseType={caseItem.case.type}
                            lastExecutionStatus={caseItem.lastExecution?.status}
                            lastExecutionTime={caseItem.lastExecution?.startTime}
                            getStatusColor={getStatusColor}
                            getRunningStatus={getRunningStatus}
                            formatDateTime={formatDateTime}
                            onEdit={() => onEditCase(caseItem.case.type, caseItem.lanecasemapping.id)}
                            onRemove={() => onRemoveCase(caseItem.lanecasemapping.id)}
                        />
                    ))}
                </Flex>
            </SortableContext>
        </DndContext>
    );
}
