"use client";

import { useCallback } from 'react';
import {
    Background,
    Controls,
    MiniMap,
    ReactFlow,
    addEdge,
    applyEdgeChanges,
    applyNodeChanges,
    ReactFlowProvider,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import { nodeTypes } from '@/components/nodes/NodeTypesDefine';
import { useEditorStore } from '@/store/editorStore';
import { useCommonStore } from '@/store/commonStore';

export default function EditorCanvas() {
    const { nodes, edges, setNodes, setEdges } = useEditorStore();
    const { setIsSelectEvent } = useCommonStore();

    const onNodesChange = useCallback(
        (changes: any) => setNodes((nds) => {
            const significantChanges = changes.filter((c: any) => c.type !== 'select' && c.type !== 'dimensions');
            if (significantChanges.length == 0) {
                setIsSelectEvent(true);
            }
            return applyNodeChanges(changes, nds);
        }),
        [setNodes],
    );
    const onEdgesChange = useCallback(
        (changes: any) => setEdges((eds) => {
            const significantChanges = changes.filter((c: any) => c.type !== 'select' && c.type !== 'dimensions');
            if (significantChanges.length == 0) {
                setIsSelectEvent(true);
            }
            return applyEdgeChanges(changes, eds);
        }),
        [setEdges],
    );
    const onConnect = useCallback(
        (params: any) => setEdges((eds) => addEdge({ ...params, animated: true }, eds)),
        [setEdges],
    );

    return (
        <ReactFlowProvider>
            <ReactFlow
                nodes={nodes}
                edges={edges}
                nodeTypes={nodeTypes}
                onNodesChange={onNodesChange}
                onEdgesChange={onEdgesChange}
                onConnect={onConnect}
                deleteKeyCode={['Delete', 'Backspace']}
                fitView
            >
                <Controls />
                <MiniMap />
                <Background gap={12} size={1} />
            </ReactFlow>
        </ReactFlowProvider>
    );
}
