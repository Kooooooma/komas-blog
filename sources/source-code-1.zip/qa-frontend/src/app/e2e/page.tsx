"use client";

import {
    Layout, Flex, Button, Tooltip, Drawer,
    Modal, Input, Spin, message, Empty, Typography
} from "antd";
import { ArrowLeftFromLine, Siren, ShieldCheck, ShieldX, ShieldAlert, Save } from 'lucide-react';
import {
    EditOutlined, VideoCameraOutlined, PlayCircleOutlined, FileTextOutlined,
} from '@ant-design/icons';
import { useState, useEffect, useRef, Suspense, useCallback } from "react";
import { motion } from "motion/react";
import { useAuthRedirect } from '@/hooks/useAuthRedirect'
import { useRouter, useSearchParams } from 'next/navigation';
import {
    updateTestCaseName, getTestCase, recordTestCase,
    runTestCase, useBridgeEvents, getUserAndBridgeBindStatus, bindBridge, pingBridge,
    getReportContent, createFrontendTestCase, updateFrontendTestCase,
    formatDateTime

} from "@/libs/edit";
import { getTestCaseDetailByLaneCaseMappingId } from "@/libs/lane";
import Ansi from 'react-ansi';

type ExecutionStatus = 'RUNNING' | 'FAILED' | 'SUCCESS';
type ConnectionStatus = 'disconnected' | 'connected' | 'busy';

interface TestCaseExecution {
    id: string;
    startTime: string;
    endTime: string;
    status: ExecutionStatus;
    logs: string;
}

export default function E2EPageWrapper() {
    return (
        <Suspense fallback={<div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}><Spin size="large" /></div>}>
            <E2EPage />
        </Suspense>
    );
}

function E2EPage() {
    useAuthRedirect();
    const { Header, Content } = Layout;
    const { Text } = Typography;
    const [messageApi, messageContextHolder] = message.useMessage();
    const router = useRouter();
    const searchParams = useSearchParams();
    const initialTestCaseId = searchParams.get('id');
    const workspaceId = searchParams.get('workspaceId');
    const laneCaseMappingId = searchParams.get('laneCaseMappingId');

    const [testCaseId, setTestCaseId] = useState<string | null>(initialTestCaseId);
    const [caseName, setCaseName] = useState("");

    const [targetUrl, setTargetUrl] = useState("");
    const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
    const [isRecording, setIsRecording] = useState(false);
    const [isRunning, setIsRunning] = useState(false);
    const [lastExecution, setLastExecution] = useState<TestCaseExecution | null>(null);
    const [showViewLogsModal, setShowViewLogsModal] = useState(false);
    const [showRecordModal, setShowRecordModal] = useState(false);
    const [showBindModal, setShowBindModal] = useState(false);
    const [bridgeUuidInput, setBridgeUuidInput] = useState("");
    const [recordedScript, setRecordedScript] = useState<string>("");
    const [showUpdateCaseNameModal, setShowUpdateCaseNameModal] = useState(false);
    const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

    const pongReceivedRef = useRef(false);
    const pingTimeout = 1000;
    const pingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

    const onRecordFinishedRef = useRef<(data: any) => void>();
    const onExecutionFinishedRef = useRef<(data: any) => void>();
    const onPongRef = useRef<() => void>();
    const abortControllerRef = useRef<AbortController>();
    const reconnectTimeoutRef = useRef<NodeJS.Timeout>();

    const refreshTestCase = async () => {
        if (testCaseId) {
            console.log("Refreshing test case, testCaseId: " + testCaseId);

            try {
                const data = await getTestCase(testCaseId);
                initTestCaseData(data);
            } catch (err) {
                messageApi.error(err instanceof Error ? err.message : 'Failed to refresh test case');
            }
        }
    }

    const refreshTestCaseByLane = async () => {
        if (laneCaseMappingId) {
            console.log(`Refreshing test case, laneCaseMappingId: ${laneCaseMappingId}`);

            try {
                const data = await getTestCaseDetailByLaneCaseMappingId(laneCaseMappingId);
                initTestCaseData(data);
            } catch (err) {
                messageApi.error(err instanceof Error ? err.message : 'Failed to refresh test case');
            }
        }
    }

    const initTestCaseData = useCallback((data: any) => {
        setCaseName(data.case.name || "");
        setTargetUrl(data.case.targetUrl || "");
        if (data.lastExecution) {
            setLastExecution(data.lastExecution);
            if (lastExecution?.status === 'RUNNING') {
                setIsRunning(true);
            }
        }
        if (data.case.script) {
            setRecordedScript(data.case.script || "");
        }
    }, []);

    useEffect(() => {
        if (testCaseId) {
            refreshTestCase();
        } else if (laneCaseMappingId) {
            refreshTestCaseByLane();
        } else {
            const now = new Date();
            const iso = now.toISOString();
            setCaseName(`New Case ${iso.replace('T', ' ').substring(0, 19)}`);
        }

        // Load stored bridge uuid
        const storedUuid = localStorage.getItem('bridgeUuid');
        if (storedUuid) {
            setBridgeUuidInput(storedUuid);
        }
    }, [testCaseId, laneCaseMappingId]);

    const handleRecordFinished = useCallback((data: any) => {
        console.log("Record finished, data:", data);
        setIsRecording(false);
        if (data.eventStatus === 'failed' || data.eventPayload.script === null) {
            messageApi.error("Test recording failed[" + data.message + "]");
            return;
        }
        setRecordedScript(data.eventPayload.script);
        setHasUnsavedChanges(true);
    }, [messageApi]);

    const handleExecutionFinished = useCallback((data: any) => {
        console.log("Execution finished, data:", data);
        setIsRunning(false);
        if (data.eventStatus === 'success') {
            messageApi.success("Test execution completed successfully!");
        } else {
            messageApi.error("Test execution failed[" + data.message + "]");
        }
        refreshTestCase();
    }, [messageApi]);

    const handlePong = useCallback(() => {
        console.log("Pong received!");
        pongReceivedRef.current = true;
    }, []);

    useEffect(() => {
        onRecordFinishedRef.current = handleRecordFinished;
        onExecutionFinishedRef.current = handleExecutionFinished;
        onPongRef.current = handlePong;
    }, [handleRecordFinished, handleExecutionFinished, handlePong]);

    const connectToBackend = useCallback(() => {
        if (abortControllerRef.current) {
            abortControllerRef.current.abort();
        }

        if (reconnectTimeoutRef.current) {
            clearTimeout(reconnectTimeoutRef.current);
        }

        console.log("🔌Connecting to backend...");

        abortControllerRef.current = useBridgeEvents(
            // onopen
            (response) => {
                console.log("🔌Connected to backend");
            },
            // onclose
            () => {
                setConnectionStatus('disconnected');
                messageApi.error('SSE Disconnected');
            },
            // onerror
            (error) => {
                console.log("🔌Error connecting to backend: ", error);
                setConnectionStatus('disconnected');

                if (error.name === 'AbortError') {
                    console.log('Connection intentionally aborted');
                    return;
                }

                messageApi.error('Failed to open SSE connection, will be reconnected in 3 seconds');

                if (reconnectTimeoutRef.current) {
                    clearTimeout(reconnectTimeoutRef.current);
                }
                reconnectTimeoutRef.current = setTimeout(() => {
                    connectToBackend();
                }, 3000);
            },
            // onmessage
            (event) => {
                console.log("onmessage", event);
                try {
                    const data = JSON.parse(event.data);
                    if (data.eventType === 'RECORD_FINISHED') {
                        messageApi.success("Recording finished");
                        handleRecordFinished(data);
                    } else if (data.eventType === 'EXECUTION_FINISHED') {
                        messageApi.success("Execution finished");
                        handleExecutionFinished(data);
                    } else if (data.eventType === 'PONG') {
                        console.log("Received pong from bridge: ", data.bridgeUuid);
                        handlePong();
                    }
                } catch (e) {
                    console.error('Parse error:', e);
                }
            }
        );
    }, [messageApi]);

    // init SSE connection
    useEffect(() => {
        connectToBackend();
        checkUserAndBridgeBindStatus();

        // health check
        const healthCheckInterval = setInterval(() => {
            if (connectionStatus === 'connected') {
                checkConnectionHealth();
            }
        }, 3000);

        return () => { // cleanup before re-run
            console.log('🧹 Cleaning up SSE connection...');
            if (abortControllerRef.current) {
                abortControllerRef.current.abort();
            }

            if (reconnectTimeoutRef.current) {
                clearTimeout(reconnectTimeoutRef.current);
            }

            if (pingTimeoutRef.current) {
                clearTimeout(pingTimeoutRef.current);
            }

            clearInterval(healthCheckInterval);
        };
    }, []);

    const checkUserAndBridgeBindStatus = async () => {
        try {
            const status = await getUserAndBridgeBindStatus();
            if (status.connected) {
                setConnectionStatus('connected');
            } else {
                setConnectionStatus('disconnected');
            }
        } catch (err) {
            console.error("Failed to check user and bridge bind status:", err);
            setConnectionStatus('disconnected');
        }
    };

    const checkConnectionHealth = async () => {
        try {
            console.log("Checking connection health...");
            pongReceivedRef.current = false;

            if (pingTimeoutRef.current) {
                clearTimeout(pingTimeoutRef.current);
            }

            await pingBridge();

            // Wait for pong response
            pingTimeoutRef.current = setTimeout(() => {
                if (!pongReceivedRef.current) {
                    console.log("Ping timeout - connection lost");
                    setConnectionStatus('disconnected');
                }
            }, pingTimeout);
        } catch (err) {
            console.error("Health check failed:", err);
            setConnectionStatus('disconnected');
        }
    };

    const handleBindBridge = async () => {
        if (!bridgeUuidInput.trim()) {
            messageApi.error("Please enter the Bridge UUID");
            return;
        }
        try {
            await bindBridge(bridgeUuidInput.trim());
            messageApi.success("Bridge bound successfully!");
            localStorage.setItem('bridgeUuid', bridgeUuidInput.trim());
            setShowBindModal(false);
            await testConnection();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to bind bridge');
        }
    };

    const testConnection = async () => {
        try {
            pongReceivedRef.current = false;
            await pingBridge();
            messageApi.loading({ content: "Testing connection...", duration: 0, key: "connection-test" });

            // Wait for pong
            pingTimeoutRef.current = setTimeout(() => {
                messageApi.destroy("connection-test");
                if (pongReceivedRef.current) {
                    messageApi.success("Connection established!");
                    setConnectionStatus('connected');
                } else {
                    messageApi.error("Connection test failed - no response from bridge");
                    setConnectionStatus('disconnected');
                }
            }, pingTimeout);
        } catch (err) {
            messageApi.destroy("connection-test");
            messageApi.error(err instanceof Error ? err.message : 'Connection test failed');
            setConnectionStatus('disconnected');
        }
    };

    const handleSirenClick = async () => {
        const storedUuid = localStorage.getItem('bridgeUuid');
        if (storedUuid) {
            try {
                messageApi.loading({ content: "Re-connecting to bridge [" + storedUuid + "]", key: "rebind", duration: 0 });
                await bindBridge(storedUuid);
                messageApi.success({ content: "Bridge re-connected [" + storedUuid + "]", key: "rebind" });
                setConnectionStatus('connected');
                await testConnection();
            } catch (err) {
                setConnectionStatus('disconnected');
                messageApi.destroy("rebind");
                messageApi.error(err instanceof Error ? err.message : 'Failed to re-connect to bridge');
            }
            return;
        }
        setShowBindModal(true);
    };

    const handleUpdateName = async () => {
        if (testCaseId) {
            try {
                await updateTestCaseName(testCaseId, caseName);
                messageApi.success("Name updated");
                setShowUpdateCaseNameModal(false);
            } catch (err) {
                messageApi.error(err instanceof Error ? err.message : 'Failed to update test case name');
            }
        } else {
            setShowUpdateCaseNameModal(false);
        }
    };

    const handleSave = async () => {
        try {
            if (testCaseId) {
                await updateFrontendTestCase(testCaseId, caseName, targetUrl, recordedScript);
                messageApi.success("Test case updated successfully");
            } else {
                const wid = workspaceId;
                if (!wid) {
                    messageApi.error("Missing workspace ID to create test case");
                    return;
                }
                const newCase = await createFrontendTestCase(wid, "FRONTEND", caseName, targetUrl, recordedScript);
                setTestCaseId(newCase.id);
                router.replace(`/e2e?id=${newCase.id}&workspaceId=${wid}`);
                messageApi.success("Test case created successfully");
            }
            setHasUnsavedChanges(false);
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to save test case');
        }
    };

    const handleRecordClick = async () => {
        if (connectionStatus === 'disconnected') {
            setShowBindModal(true);
            return;
        }
        setShowRecordModal(true);
    };

    const handleStartRecording = async () => {
        if (!targetUrl.trim()) {
            messageApi.error("Please enter a URL to record");
            return;
        }
        try {
            await recordTestCase(targetUrl);
            setIsRecording(true);
            setShowRecordModal(false);
            messageApi.success("Start recording... Close the browser when done.");
        } catch (err) {
            setIsRecording(false);
            messageApi.error(err instanceof Error ? err.message : 'Failed to start recording');
        }
    };

    const handleRun = async () => {
        if (!testCaseId) {
            messageApi.error("Please save test first");
            return;
        }
        if (connectionStatus === 'disconnected') {
            setShowBindModal(true);
            return;
        }
        try {
            setIsRunning(true);
            await runTestCase(testCaseId);
            messageApi.loading("Running test case...");
        } catch (err) {
            setIsRunning(false);
            messageApi.error(err instanceof Error ? err.message : 'Failed to start run');
        }
    }

    const handleViewReport = async () => {
        const executionId = lastExecution?.id;
        if (!executionId) {
            messageApi.warning("No execution found for this test case");
            return;
        }
        try {
            const reportHtml = await getReportContent(executionId);

            const newWindow = window.open('', '_blank');
            if (newWindow) {
                newWindow.document.title = caseName;
                newWindow.document.write(reportHtml);
                newWindow.document.close();
                newWindow.addEventListener('DOMContentLoaded', () => {
                    newWindow.document.title = caseName;
                });
                setTimeout(() => {
                    if (newWindow && !newWindow.closed) {
                        newWindow.document.title = caseName;
                    }
                }, 300);
            } else {
                messageApi.error("Failed to open new tab - please allow popups");
            }
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to load report');
        }
    };

    const getRecordButtonStyle = () => {
        if (isRecording) {
            return { backgroundColor: '#ff4d4f', borderColor: '#ff4d4f', color: 'white' };
        }
        if (connectionStatus === 'connected') {
            return { backgroundColor: '#52c41a', borderColor: '#52c41a', color: 'white' };
        }
        return { backgroundColor: '#d9d9d9', borderColor: '#d9d9d9', color: '#999' };
    };

    const getConnectButtonStyle = () => {
        if (connectionStatus === 'disconnected') {
            return { color: '#ff4d4f', margin: '5px 0 0 0', padding: 0, cursor: 'pointer' };
        }
        return { color: '#52c41a', margin: '5px 0 0 0', padding: 0, cursor: 'pointer' };
    };

    const getExecutionStatusColor = () => {
        if (lastExecution?.status === 'SUCCESS') {
            return '#52c41a';
        }
        if (lastExecution?.status === 'FAILED') {
            return '#ff4d4f';
        }
        return '#1890ff';
    }

    return (
        <Layout>
            <Header style={{ backgroundColor: 'white', padding: '0 10px', height: '50px', borderBottom: '1px solid #f0f0f0' }}>
                <Flex align="center" justify="space-between">
                    <Flex justify="flex-start" style={{ marginTop: '10px' }}>
                        <Tooltip title="Back to Home">
                            <motion.div
                                whileHover={{ scale: 1.2, x: -3 }}
                                transition={{ type: "spring", stiffness: 400, damping: 17 }}
                                style={{ display: 'inline-flex', cursor: 'pointer' }}
                            >
                                <ArrowLeftFromLine style={{ marginRight: '10px', marginLeft: '5px', color: '#ff4d4f' }} onClick={() => router.back()} />
                            </motion.div>
                        </Tooltip>
                        <Text>{caseName}</Text>
                        <Button type="text" size="small" icon={<EditOutlined />} onClick={() => setShowUpdateCaseNameModal(true)} style={{ marginLeft: '5px' }} />
                    </Flex>
                    <Flex>
                        {lastExecution?.status === 'SUCCESS' && (
                            <Flex align="center" justify="center" gap={5} style={{ marginTop: '10px' }}>
                                <Text style={{ color: getExecutionStatusColor() }}>{formatDateTime(lastExecution.startTime)} {lastExecution.status}</Text>
                                <ShieldCheck color={getExecutionStatusColor()} />
                            </Flex>
                        )}
                        {lastExecution?.status === 'FAILED' && (
                            <Flex align="center" justify="center" gap={5} style={{ marginTop: '10px' }}>
                                <Text style={{ color: getExecutionStatusColor() }}>{formatDateTime(lastExecution.startTime)} {lastExecution.status}</Text>
                                <ShieldX color={getExecutionStatusColor()} />
                            </Flex>
                        )}
                        {lastExecution?.status === 'RUNNING' && (
                            <Flex align="center" justify="center" gap={5} style={{ marginTop: '10px' }}>
                                <Text style={{ color: getExecutionStatusColor() }}>{formatDateTime(lastExecution.startTime)} {lastExecution.status}</Text>
                                <ShieldAlert color={getExecutionStatusColor()} />
                            </Flex>
                        )}
                    </Flex>
                    <Flex justify="flex-end" gap={8} style={{ marginTop: '10px', marginRight: '15px' }}>
                        <Button icon={<FileTextOutlined />} onClick={handleViewReport}>View Report</Button>
                        <Button icon={<FileTextOutlined />} onClick={() => setShowViewLogsModal(true)}>View Logs</Button>
                        <Button
                            icon={<VideoCameraOutlined />}
                            disabled={isRecording || isRunning}
                            style={getRecordButtonStyle()}
                            onClick={handleRecordClick}
                        >
                            {isRecording ? "Recording..." : "Record"}
                        </Button>
                        <Siren size={20} style={getConnectButtonStyle()} onClick={handleSirenClick} />
                        <Button
                            icon={<PlayCircleOutlined />}
                            onClick={handleRun}
                            loading={isRunning}
                            disabled={isRunning || isRecording}
                        >
                            {isRunning ? "Running..." : "Run"}
                        </Button>
                        <Button
                            icon={<Save size={14} />}
                            type='primary'
                            onClick={handleSave}
                            danger={hasUnsavedChanges}
                        >
                            Save
                        </Button>
                    </Flex>
                </Flex>
            </Header>
            <Content style={{ padding: '15px', overflowY: 'auto' }}>
                <div style={{ minHeight: 360, height: 'calc(100vh - 80px)', overflow: 'auto' }}>
                    {recordedScript && recordedScript.length > 0 ? (
                        <pre>{recordedScript}</pre>
                    ) : (
                        <Empty description="No recorded steps yet. Click Record to start.">
                            <Button type="primary" onClick={handleRecordClick} icon={<VideoCameraOutlined />}>
                                Start Recording
                            </Button>
                        </Empty>
                    )}
                </div>
            </Content>

            {/* Update Name Modal */}
            <Modal open={showUpdateCaseNameModal}
                title="Update Case Name"
                onOk={handleUpdateName}
                onCancel={() => setShowUpdateCaseNameModal(false)}
            >
                <Input style={{ margin: '15px 0' }} value={caseName} onChange={(e) => setCaseName(e.target.value)} />
            </Modal>

            {/* View Logs Modal */}
            <Drawer title="Execution Logs" placement="right" onClose={() => setShowViewLogsModal(false)} open={showViewLogsModal} width={800}>
                {lastExecution ? (
                    <div>
                        <Text strong>Status: </Text><Text strong style={{ color: getExecutionStatusColor() }}>{lastExecution?.status}</Text><br />
                        <Text strong>Start Time: </Text><Text>{formatDateTime(lastExecution?.startTime)}</Text><br />
                        <Text strong>End Time: </Text><Text>{formatDateTime(lastExecution?.endTime)}</Text><br />
                        <div style={{
                            marginTop: '10px',
                            padding: 0
                        }}>
                            <Ansi log={lastExecution?.logs || "No logs available."} />
                        </div>
                    </div>
                ) : <Empty description="No execution data" />}
            </Drawer>

            {/* Bind Bridge Modal */}
            <Modal open={showBindModal}
                title="Connect to Bridge"
                onOk={handleBindBridge}
                onCancel={() => setShowBindModal(false)}
                okText="Connect"
            >
                <Input
                    style={{ margin: '15px 0' }}
                    value={bridgeUuidInput}
                    onChange={(e) => setBridgeUuidInput(e.target.value)}
                    placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                />
            </Modal>

            {/* Record Modal */}
            <Modal open={showRecordModal}
                title={
                    <Flex align="center" justify="center" gap={5}>
                        <VideoCameraOutlined size={14} />
                        <Text>Start Recording</Text>
                    </Flex>
                }
                onOk={handleStartRecording}
                onCancel={() => setShowRecordModal(false)}
                okText="Start Recording"
            >
                <Typography.Text>Enter the URL to record:</Typography.Text>
                <Input
                    style={{ margin: '15px 0' }}
                    value={targetUrl}
                    onChange={(e) => setTargetUrl(e.target.value)}
                    placeholder="https://example.com"
                />
            </Modal>
            {messageContextHolder}
        </Layout>
    );
}