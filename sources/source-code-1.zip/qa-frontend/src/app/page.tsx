"use client";

import { useState, useEffect } from 'react';
import { useAuthRedirect } from '@/hooks/useAuthRedirect'
import { redirect } from "next/navigation";

export default function Home() {
  const [isLogin, setIsLogin] = useState(true);

  useAuthRedirect();

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLogin(false);
    }, 100);
    return () => clearTimeout(timer);
  }, []);

  if (isLogin) {
    redirect('/workspace');
    return null;
  }
}