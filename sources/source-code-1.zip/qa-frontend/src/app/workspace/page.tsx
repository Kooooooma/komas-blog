"use client";

import StandardWorkspace from "@/components/workspace/StandardWorkspace";
import OrchestrationWorkspace from "@/components/workspace/OrchestrationWorkspace";
import JmsAgent from "@/components/busybox/JmsAgent";
import { useCommonStore } from "@/store/commonStore";

export default function Workspace() {
    const { workspaceType, activeView } = useCommonStore();

    // 根据 activeView 渲染不同的组件
    switch (activeView) {
        case 'workspace':
            return workspaceType === "STANDARD" ? <StandardWorkspace /> : <OrchestrationWorkspace />;
        case 'jmsagent':
            return <JmsAgent />;
        default:
            return workspaceType === "STANDARD" ? <StandardWorkspace /> : <OrchestrationWorkspace />;
    }
}
