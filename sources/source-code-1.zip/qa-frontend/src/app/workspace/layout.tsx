"use client";

import { Button, Flex, Layout, Typography, Menu, Dropdown, Modal, Breadcrumb, Input, Spin, message, Splitter } from "antd";
import { PlusOutlined, LogoutOutlined, UserOutlined, HomeOutlined, EditOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import { Folder, FolderKanban, X, Drill, BotMessageSquare } from 'lucide-react';
import { useEffect, useState, useMemo } from 'react';
import { useCommonStore } from "@/store/commonStore";
import { useAuthRedirect } from '@/hooks/useAuthRedirect'
import { useWorkspaceList, deleteWorkspace, createWorkspace, updateWorkspaceName } from "@/libs/workspace";
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { logout } from '@/libs/auth';
import { useRouter } from 'next/navigation';

export default function WorkspaceLayout({ children }: { children: React.ReactNode }) {
    useAuthRedirect();
    const router = useRouter();
    const { Header, Content, Sider } = Layout;
    const { Title, Text } = Typography;

    const { employeeId } = useCurrentUser();
    const { workspaces, isLoading, mutate } = useWorkspaceList(employeeId);

    const [modal, modalContextHolder] = Modal.useModal();
    const [messageApi, messageContextHolder] = message.useMessage();

    const handleCreateWorkspace = async (type: 'STANDARD' | 'ORCHESTRATION') => {
        try {
            await createWorkspace({
                name: 'New Workspace',
                employeeId: employeeId || '',
                type: type,
            });
            mutate();
            messageApi.success('Workspace created successfully');
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Create failed');
        }
    };

    const workspaceTypeList = {
        items: [
            { key: 'STANDARD', label: 'Standard Workspace', icon: <Folder size={16} />, onClick: () => handleCreateWorkspace('STANDARD') },
            { key: 'ORCHESTRATION', label: 'Orchestration Workspace', icon: <FolderKanban size={16} />, onClick: () => handleCreateWorkspace('ORCHESTRATION') },
        ]
    };

    const WorkspaceList = useMemo(() => workspaces?.map(w => ({
        key: w.id,
        workspacetype: w.type,
        label: (
            <Flex align="center" justify="space-between" gap="small" style={{ width: '100%', overflow: 'hidden' }}>
                <Text ellipsis={true}>{w.name}</Text>
                <Button key="delete" type="text" danger icon={<X size={14} />} onClick={(e) => {
                    e.stopPropagation(); // Prevent row selection
                    handleDeleteWorkspace(w.id);
                }} />
            </Flex>
        ),
        title: w.name,
        icon: w.type === 'STANDARD' ? <Folder size={18} /> : <FolderKanban size={18} />
    })) || [], [workspaces]);

    const handleDeleteWorkspace = (workspaceId: string) => {
        modal.confirm({
            title: 'Delete Workspace',
            icon: <ExclamationCircleOutlined />,
            content: 'Are you sure you want to delete this workspace(Will delete all the entities in this workspace)?',
            okText: 'Confirm',
            cancelText: 'Cancel',
            onOk: async () => {
                try {
                    await deleteWorkspace(workspaceId, employeeId);
                    mutate(); //refresh the WorkspaceList
                    messageApi.success('Workspace deleted successfully');
                } catch (err) {
                    messageApi.error(err instanceof Error ? err.message : 'Delete failed');
                }
            }
        });
    };

    const [selectedKey, setSelectedKey] = useState<string>('');
    const { workspaceType, setWorkspaceType, workspaceId, setWorkspaceId, setActiveView, activeView } = useCommonStore();
    const [workspaceName, setWorkspaceName] = useState("");
    const [showUpdateWorkspaceNameModal, setShowUpdateWorkspaceNameModal] = useState(false);

    const handleUpdateWorkspaceName = async () => {
        if (!selectedKey) return;
        try {
            await updateWorkspaceName(selectedKey, workspaceName);
            mutate();
            messageApi.success('Workspace name updated');
            setShowUpdateWorkspaceNameModal(false);
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Update failed');
        }
    };

    const handleLogout = () => {
        logout();
        router.push('/login');
    };

    useEffect(() => {
        if (WorkspaceList.length > 0) {
            const existingWorkspace = WorkspaceList.find(w => w.key === workspaceId);
            if (existingWorkspace) {
                setSelectedKey(workspaceId);
            } else {
                setSelectedKey(WorkspaceList[0].key);
            }
        }
    }, [WorkspaceList]);

    useEffect(() => {
        const selectedWorkspace = WorkspaceList.find(w => w.key === selectedKey);
        if (selectedWorkspace) {
            if (selectedWorkspace.workspacetype !== workspaceType) {
                setWorkspaceType(selectedWorkspace.workspacetype || 'STANDARD');
            }
            if (selectedWorkspace.title !== workspaceName) {
                setWorkspaceName(selectedWorkspace.title || 'Default Workspace');
            }
            setWorkspaceId(selectedWorkspace.key);
            setActiveView('workspace');
        }
    }, [selectedKey]);

    const breadcrumbItems = activeView === 'workspace' ? [
        {
            title: <HomeOutlined />,
        },
        {
            title: (
                <Flex align="center" justify="flex-start">
                    {workspaceType === 'STANDARD' ? <Folder size={14} style={{ marginRight: '5px' }} /> : <FolderKanban size={14} style={{ marginRight: '5px' }} />}
                    <Text>{workspaceName}</Text>
                    <Button type="text" size="small" icon={<EditOutlined />} onClick={() => setShowUpdateWorkspaceNameModal(true)} style={{ marginLeft: '5px' }} />
                </Flex>
            )
        }
    ] : [
        {
            title: <HomeOutlined />,
        },
        {
            title: (
                <Flex align="center" justify="flex-start">
                    <Drill size={14} style={{ marginRight: '5px' }} />
                    <Text>BusyBox</Text>
                </Flex>
            )
        },
        {
            title: activeView === 'jmsagent' ? (
                <Flex align="center" justify="flex-start">
                    <BotMessageSquare size={14} style={{ marginRight: '5px' }} />
                    <Text>JMS Agent</Text>
                </Flex>
            ) : <Text>{activeView}</Text>
        }
    ]

    const busyBoxItems = [
        {
            key: '1',
            label: 'BusyBox',
            icon: <Drill size={16} />,
            children: [
                {
                    key: '1-1',
                    label: 'Jms Agent',
                    icon: <BotMessageSquare size={16} />,
                    onClick: () => setActiveView('jmsagent'),
                },
            ],
        }
    ];

    return (
        <Layout>
            <Header style={{ backgroundColor: 'white', padding: '0 10px', height: '80px', borderBottom: '1px solid #f0f0f0' }}>
                <Flex align="center" justify="space-between" style={{ padding: '0 15px' }}>
                    <Flex align="center" gap="small">
                        <img src="/logo.png" style={{ width: '50px', marginTop: '12px' }} />
                        <Title level={4} style={{ marginTop: '30px' }}>Home</Title>
                    </Flex>
                    <Flex justify="flex-end" align="center" gap="large" style={{ marginTop: '15px' }} >
                        <Text strong><UserOutlined style={{ marginRight: '5px' }} />{employeeId}</Text>
                        <Button color="danger" variant="filled" icon={<LogoutOutlined />} onClick={handleLogout}>Logout</Button>
                    </Flex>
                </Flex>
            </Header>
            <Layout>
                <Splitter>
                    <Splitter.Panel defaultSize="15%" min="13%" max="25%">
                        <Sider style={{ backgroundColor: 'white' }} width="100%">
                            <Flex align="center" justify="center" style={{ margin: '8px 0' }}>
                                <Text strong>Create Workspace</Text>
                                <Dropdown menu={workspaceTypeList} trigger={['click']}>
                                    <Button type="text" size="middle" icon={<PlusOutlined />} />
                                </Dropdown>
                            </Flex>
                            <Flex vertical>
                                {isLoading ? (
                                    <Flex justify="center" style={{ padding: '20px' }}><Spin /></Flex>
                                ) : (
                                    <Menu
                                        mode="inline"
                                        inlineIndent={10}
                                        selectedKeys={[selectedKey]}
                                        onSelect={({ key }) => setSelectedKey(key)}
                                        style={{ borderRight: 0 }}
                                        items={WorkspaceList}
                                    />
                                )}
                                <Menu
                                    mode="inline"
                                    inlineIndent={10}
                                    style={{ borderRight: 0 }}
                                    items={busyBoxItems}
                                />
                            </Flex>
                        </Sider>
                    </Splitter.Panel>
                    <Splitter.Panel>
                        <Content style={{ height: 'calc(100vh - 80px)', overflow: 'auto' }}>
                            <Flex style={{ padding: '15px' }} vertical>
                                <Flex align="center" justify="flex-start" style={{ marginBottom: '15px' }}>
                                    <Breadcrumb items={breadcrumbItems} />
                                </Flex>
                                {children}
                            </Flex>
                        </Content>
                    </Splitter.Panel>
                </Splitter>
                <Modal open={showUpdateWorkspaceNameModal}
                    title="Update Workspace Name"
                    onOk={handleUpdateWorkspaceName}
                    onCancel={() => setShowUpdateWorkspaceNameModal(false)}
                >
                    <Input style={{ margin: '15px 0' }} value={workspaceName} onChange={(e) => setWorkspaceName(e.target.value)} />
                </Modal>
                {modalContextHolder}{messageContextHolder}
            </Layout>
        </Layout>
    )
}
