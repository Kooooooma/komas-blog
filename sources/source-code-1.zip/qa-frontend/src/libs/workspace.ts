"use client";

import useSWR from 'swr';
import { NEXT_PUBLIC_API_BASE_URL, NEXT_PUBLIC_API_PREFIX } from './config';

export interface Workspace {
    id: string;
    name: string;
    employeeId: string;
    type: 'STANDARD' | 'ORCHESTRATION';
    createTime: string;
}

export interface LaneCase {
    case: {
        id: string;
        name: string;
        type: string;
    };
    lanecasemapping: {
        id: string;
        laneId: string;
        testCaseId: string;
    };
    lastExecution?: {
        status: string;
        startTime: string;
        endTime: string;
    };
}

export interface LaneData {
    lane: {
        id: string;
        name: string;
        workspaceId: string;
        createTime: string;
    };
    cases: LaneCase[];
}

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export const useWorkspaceList = (employeeId: string | null) => {
    const { data, error, isLoading, mutate } = useSWR<Workspace[]>(
        employeeId ? `${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/workspace/employee/${employeeId}` : null,
        fetcher
    );

    return {
        workspaces: data,
        isLoading,
        isError: error,
        mutate,
    };
};

export const deleteWorkspace = async (id: string, employeeId: string | null) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/workspace/${id}`, {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
            'employeeId': employeeId || '',
        },
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to delete workspace[' + errorMessage + ']');
    }
};

export const createWorkspace = async (workspace: Partial<Workspace>) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/workspace`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(workspace),
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to delete workspace[' + errorMessage + ']');
    }

    return response.json();
};

export const updateWorkspaceName = async (id: string, name: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/workspace/${id}/name`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name }),
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to delete workspace[' + errorMessage + ']');
    }

    return response.json();
};

export const getWorkspaceLanes = async (workspaceId: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/workspace/${workspaceId}/lanes`);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to load lanes[' + errorMessage + ']');
    }
    return response.json();
};

export const useWorkspaceLanes = (workspaceId: string | null, refreshInterval: number = 5000) => {
    const { data, error, isLoading, mutate } = useSWR<LaneData[]>(
        workspaceId ? `${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/workspace/${workspaceId}/lanes` : null,
        fetcher,
        {
            refreshInterval,
            revalidateOnFocus: false,
        }
    );

    return {
        lanes: Array.isArray(data) ? data : [],
        isLoading,
        isError: error,
        mutate,
    };
};

