"use client";

import { NEXT_PUBLIC_API_BASE_URL, NEXT_PUBLIC_API_PREFIX } from './config';
import { getCurrentUser } from './auth';

export const createLane = async (workspaceId: string, name: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/lane`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ workspaceId, name }),
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to create lane[' + errorMessage + ']');
    }
    return response.json();
};

export const addCaseToLane = async (laneId: string, caseId: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/lane/${laneId}/case/${caseId}`, {
        method: 'POST',
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to add case to lane[' + errorMessage + ']');
    }
};

export const getWorkspacesByEmployee = async (employeeId: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/workspace/employee/${employeeId}`);
    if (!response.ok) {
        throw new Error('Failed to load workspaces');
    }
    return response.json();
};

export const deleteLane = async (laneId: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/lane/${laneId}`, {
        method: 'DELETE',
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to delete lane[' + errorMessage + ']');
    }
};

export const removeCaseFromLane = async (id: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/lanecasemapping/${id}`, {
        method: 'DELETE',
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to remove case from lane[' + errorMessage + ']');
    }
};

export const updateLaneName = async (laneId: string, name: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/lane/${laneId}/name`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name }),
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to update lane name[' + errorMessage + ']');
    }
};

export const updateLaneOrder = async (laneId: string, laneCaseMappingIds: string[]) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/lane/order`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ laneId, laneCaseMappingIds }),
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to update lane order[' + errorMessage + ']');
    }
};

export const runLane = async (laneId: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/lane/run/${laneId}`, {
        method: 'GET',
        headers: {
            'x-employee-id': getCurrentUser() || ''
        }
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to run lane[' + errorMessage + ']');
    }
};

export const getTestCaseDetailByLaneCaseMappingId = async (laneCaseMappingId: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/lanecasemapping/detail/${laneCaseMappingId}`);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to load test case[' + errorMessage + ']');
    }
    return response.json();
};
