"use client";

import useSWR from 'swr';
import { NEXT_PUBLIC_API_BASE_URL, NEXT_PUBLIC_API_PREFIX } from './config';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export const useConnectserverList = () => {
    const { data, error, isLoading } = useSWR<string[]>(
        `${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/component/connectserver/list`,
        fetcher
    );
    return {
        connectserverList: data,
        connectserverLoading: isLoading,
        connectserverLoadError: error,
    };
};

// Agent management APIs
export interface JvmInfo {
    pid: string;
    appName: string;
    server: string;
    agentAttached: boolean;
}

export interface AttachRequest {
    requests: {
        server: string;
        pids: string[];
    }[];
}

export interface JmsMessage {
    vpn: string;
    type: string;
    destination: string;
    server: string;
    appName: string;
    time: string;
    trackingId: string;
    messageContent: string;
}

export interface JmsMessageQuery {
    page: number;
    size: number;
    vpn?: string;
    type?: string;
    destination?: string;
    server?: string;
    appName?: string;
    trackingId?: string;
}

export const discoverJvms = async (server: string, appName: string): Promise<JvmInfo[]> => {
    const params = new URLSearchParams({ server, appName });
    const response = await fetch(
        `${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/agent/jvm/discover?${params}`
    );
    return response.json();
};

export const attachAgent = async (request: AttachRequest): Promise<Record<string, Record<string, boolean>>> => {
    const response = await fetch(
        `${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/agent/jvm/attach`,
        {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(request),
        }
    );
    return response.json();
};

export const checkAgentStatus = async (request: AttachRequest): Promise<Record<string, Record<string, boolean>>> => {
    const response = await fetch(
        `${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/agent/jvm/status`,
        {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(request),
        }
    );
    return response.json();
};

export const queryJmsMessages = async (query: JmsMessageQuery): Promise<{ content: JmsMessage[]; totalElements: number }> => {
    const response = await fetch(
        `${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/agent/jms/messages`,
        {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(query),
        }
    );
    return response.json();
};