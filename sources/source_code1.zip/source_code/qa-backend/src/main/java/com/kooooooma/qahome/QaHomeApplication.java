package com.kooooooma.qahome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@SpringBootApplication
public class QaHomeApplication {

	public static void main(String[] args) {
		SpringApplication.run(QaHomeApplication.class, args);
	}

}
