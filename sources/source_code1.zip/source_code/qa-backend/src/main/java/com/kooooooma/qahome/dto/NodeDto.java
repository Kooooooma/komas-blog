package com.kooooooma.qahome.dto;

import lombok.Data;

import java.util.Map;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Data
public class NodeDto {
    private String id;
    private String type;
    private Map<String, String> data;
}
