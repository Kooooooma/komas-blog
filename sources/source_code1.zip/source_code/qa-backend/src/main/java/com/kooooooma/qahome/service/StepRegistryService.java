package com.kooooooma.qahome.service;

import org.springframework.stereotype.Service;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Service
public class StepRegistryService {
}
