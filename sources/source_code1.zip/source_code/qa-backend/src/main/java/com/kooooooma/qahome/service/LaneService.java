package com.kooooooma.qahome.service;

import com.kooooooma.qahome.entity.Lane;
import com.kooooooma.qahome.entity.LaneCaseMapping;
import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.entity.TestExecution;
import com.kooooooma.qahome.enums.ExecutionStatus;
import com.kooooooma.qahome.repository.LaneCaseMappingRepository;
import com.kooooooma.qahome.repository.LaneRepository;
import com.kooooooma.qahome.repository.TestCaseRepository;
import com.kooooooma.qahome.repository.TestExecutionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Service
public class LaneService {

    @Autowired
    private LaneRepository laneRepository;

    @Autowired
    private LaneCaseMappingRepository laneCaseMappingRepository;

    @Autowired
    private TestCaseRepository testCaseRepository;

    @Autowired
    private TestExecutionRepository testExecutionRepository;

    @Transactional
    public Lane createLane(Lane lane) {
        lane.setCreateTime(LocalDateTime.now());
        return laneRepository.save(lane);
    }

    @Transactional
    public Lane updateLaneName(UUID id, String name) {
        Lane lane = laneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Lane not found: " + id));
        lane.setName(name);
        return laneRepository.save(lane);
    }

    @Transactional
    public void updateLaneOrder(UUID laneId, List<UUID> caseIds) {
        List<LaneCaseMapping> mappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndex(laneId);

        Map<UUID, LaneCaseMapping> map = new HashMap<>();
        for (LaneCaseMapping m : mappings) {
            map.put(m.getTestCaseId(), m);
        }

        for (int i = 0; i < caseIds.size(); i++) {
            UUID caseId = caseIds.get(i);
            LaneCaseMapping mapping = map.get(caseId);
            if (mapping == null) {
                continue;
            }
            mapping.setOrderIndex(i+1);
            laneCaseMappingRepository.save(mapping);
        }
    }

    @Transactional
    public void deleteLane(UUID id) {
        Lane lane = laneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Lane not found: " + id));

        laneCaseMappingRepository.deleteByLaneId(id);

        if (lane.getLastExecutionId() != null) {
            testExecutionRepository.deleteById(lane.getLastExecutionId());
        }

        laneRepository.delete(lane);
    }

    public List<Map<String, Object>> getLanesByWorkspace(UUID workspaceId) {
        List<Lane> lanes = laneRepository.findByWorkspaceIdOrderByCreateTimeDesc(workspaceId);
        return lanes.stream().map(this::enrichLaneWithStats).collect(Collectors.toList());
    }

    private Map<String, Object> enrichLaneWithStats(Lane lane) {
        Map<String, Object> result = new HashMap<>();
        result.put("lane", lane);

        List<LaneCaseMapping> mappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndex(lane.getId());

        // Get Case IDs
        List<UUID> caseIds = mappings.stream().map(LaneCaseMapping::getTestCaseId).collect(Collectors.toList());
        List<TestCase> cases = testCaseRepository.findAllById(caseIds);
        Map<UUID, TestCase> caseMap = cases.stream().collect(Collectors.toMap(TestCase::getId, c -> c));

        List<Map<String, Object>> caseInfos = new ArrayList<>();
        Map<ExecutionStatus, Long> stats = new HashMap<>();

        for (LaneCaseMapping m : mappings) {
            TestCase tc = caseMap.get(m.getTestCaseId());
            if (tc != null) {
                Map<String, Object> caseInfo = new HashMap<>();
                caseInfo.put("case", tc);

                ExecutionStatus status = ExecutionStatus.NA;
                if (tc.getLastExecutionId() != null) {
                    Optional<TestExecution> exec = testExecutionRepository.findById(tc.getLastExecutionId());
                    exec.ifPresent(testExecution -> caseInfo.put("lastExecution", testExecution));
                }
                caseInfos.add(caseInfo);

                // Count stats
                stats.put(status, stats.getOrDefault(status, 0L) + 1);
            }
        }

        result.put("cases", caseInfos);
        result.put("stats", stats);

        // Derive Lane Status
        ExecutionStatus laneStatus = deriveLaneStatus(stats);
        result.put("status", laneStatus);

        return result;
    }

    private ExecutionStatus deriveLaneStatus(Map<ExecutionStatus, Long> stats) {
        if (stats.containsKey(ExecutionStatus.PENDING) && stats.containsKey(ExecutionStatus.NA))
            return ExecutionStatus.PENDING;
        if (stats.containsKey(ExecutionStatus.RUNNING) && stats.containsKey(ExecutionStatus.NA))
            return ExecutionStatus.RUNNING;
        if (stats.containsKey(ExecutionStatus.FAILURE) && stats.containsKey(ExecutionStatus.NA))
            return ExecutionStatus.FAILURE;
        if (stats.containsKey(ExecutionStatus.SUCCESS)) {
            long total = stats.values().stream().mapToLong(Long::longValue).sum();
            long passed = stats.getOrDefault(ExecutionStatus.SUCCESS, 0L);
            if (passed == total && total > 0)
                return ExecutionStatus.SUCCESS;
        }
        return ExecutionStatus.NA;
    }

    @Transactional
    public void addCaseToLane(UUID laneId, UUID caseId) {
        laneRepository.findById(laneId)
                .orElseThrow(() -> new RuntimeException("Lane not found: " + laneId));

        List<LaneCaseMapping> existing = laneCaseMappingRepository.findByLaneIdOrderByOrderIndex(laneId);
        int nextOrder = existing.isEmpty() ? 1 : existing.get(existing.size() - 1).getOrderIndex() + 1;

        LaneCaseMapping mapping = LaneCaseMapping.builder()
                .laneId(laneId)
                .testCaseId(caseId)
                .orderIndex(nextOrder)
                .build();
        laneCaseMappingRepository.save(mapping);
    }

    @Transactional
    public void removeCaseFromLane(UUID laneId, UUID caseId) {
        laneRepository.findById(laneId)
                .orElseThrow(() -> new RuntimeException("Lane not found: " + laneId));
        laneCaseMappingRepository.deleteLaneCaseMappingByLaneIdAndTestCaseId(laneId, caseId);
    }
}
