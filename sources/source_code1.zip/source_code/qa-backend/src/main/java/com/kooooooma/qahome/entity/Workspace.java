package com.kooooooma.qahome.entity;

import com.kooooooma.qahome.enums.WorkspaceType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Builder
@Entity
@Table(name = "workspace")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Workspace {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String employeeId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = true) // Allow null for existing data, default handled in Java
    private WorkspaceType type = WorkspaceType.STANDARD;

    @Column(nullable = false)
    private LocalDateTime createTime;
}
