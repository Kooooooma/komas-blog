package com.kooooooma.qahome.components;

import com.kooooooma.qahome.dagengine.GraphExecutionContext;
import com.kooooooma.qahome.dagengine.GraphTaskNode;
import com.kooooooma.qahome.dto.NodeDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Component
public class ConnectServer implements GraphTaskNode {

    @Override
    public String category() {
        return "SSH";
    }

    @Override
    public void execute(NodeDto node, GraphExecutionContext context) {
        context.put("nodeData", node.getData());
        log.info("Connecting to SSH... {}, data: {}", node.getId(), context.get("nodeData"));
    }
}
