package com.kooooooma.qahome.dagengine;

import com.kooooooma.qahome.dto.ContractDto;
import com.kooooooma.qahome.dto.NodeDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.*;
import java.util.concurrent.CompletableFuture;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class GraphExecutor {
    @Autowired
    private List<GraphTaskNode> graphTaskNodeList;

    public void execute(ContractDto contractDTO) {
        GraphExecutionContext executionContext = new GraphExecutionContext();
        List<GraphStage> graphStages = GraphAnalyzer.analyzeGraph(contractDTO);

        if (graphStages.isEmpty()) {
            log.warn("Graph is empty");
            throw new RuntimeException("Graph is empty");
        }

        Map<String, Set<String>> childToParentMapping = new HashMap<>();
        contractDTO.getEdges().forEach(edge -> {
            Set<String> parentIds = new HashSet<>();
            if (childToParentMapping.containsKey(edge.getTarget())) {
                parentIds = childToParentMapping.get(edge.getTarget());
            }
            parentIds.add(edge.getSource());
            childToParentMapping.put(edge.getTarget(), parentIds);
        });

        Map<String, CompletableFuture<Void>> taskNodeFutures = new HashMap<>();

        for (GraphStage graphStage : graphStages) {
            for (NodeDto node : graphStage.getNodes()) {
                Set<String> parentIds = childToParentMapping.get(node.getId());
                List<CompletableFuture<Void>> parentFutures = new ArrayList<>();

                if (!CollectionUtils.isEmpty(parentIds)) {
                    parentIds.forEach(parentId -> parentFutures.add(taskNodeFutures.get(parentId)));
                }

                CompletableFuture<Void> future;
                if (!CollectionUtils.isEmpty(parentFutures)) {
                    future = CompletableFuture.allOf(parentFutures.toArray(new CompletableFuture[0]));
                    // wait all parents complete and then start
                    future = future.thenAcceptAsync(v -> executeNodeTask(node, executionContext));
                } else {
                    // entry node, start immediately
                    future = CompletableFuture.runAsync(() -> executeNodeTask(node, executionContext));
                }

                taskNodeFutures.put(node.getId(), future);
            }
        }

        try {
            // wait all nodes complete
            CompletableFuture.allOf(taskNodeFutures.values().toArray(new CompletableFuture[0])).join();
            log.info("Graph Execution Completed Successfully.");
        } catch (Exception e) {
            log.error("Graph Execution Failed.", e);
            throw e;
        }
    }

    public void executeNodeTask(NodeDto node, GraphExecutionContext executionContext) {
        graphTaskNodeList.stream().filter(graphTaskNode -> graphTaskNode.accept(node.getData().get("key"))).findFirst().ifPresent(graphTaskNode -> {
            graphTaskNode.execute(node, executionContext);
        });
    }
}
