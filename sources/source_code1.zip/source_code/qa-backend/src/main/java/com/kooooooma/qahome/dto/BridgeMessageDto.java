package com.kooooooma.qahome.dto;

import com.kooooooma.qahome.enums.BridgeMessageType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Builder
@Data
@NoArgsConstructor
@AllArgsConstructor
public class BridgeMessageDto {
    private BridgeMessageType type;

    private String bridgeUuid;
    private String url;

    // for run event
    private String contract;
    private String testCaseId;
    private String executionId;

    // for notify event
    private String executionStatus;
    private String reportContent;
    private String recordedEvents;
}
