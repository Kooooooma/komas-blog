package com.kooooooma.qahome.repository;

import com.kooooooma.qahome.entity.Lane;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Repository
public interface LaneRepository extends JpaRepository<Lane, UUID> {
    List<Lane> findByWorkspaceId(UUID workspaceId);

    List<Lane> findByWorkspaceIdOrderByCreateTimeDesc(UUID workspaceId);
}
