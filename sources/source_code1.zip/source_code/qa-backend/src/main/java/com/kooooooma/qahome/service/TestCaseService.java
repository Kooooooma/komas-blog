package com.kooooooma.qahome.service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.repository.LaneCaseMappingRepository;
import com.kooooooma.qahome.repository.TestCaseRepository;
import com.kooooooma.qahome.repository.TestExecutionRepository;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class TestCaseService {

    @Autowired
    private TestCaseRepository testCaseRepository;

    @Autowired
    private TestExecutionRepository testExecutionRepository;

    @Autowired
    private LaneCaseMappingRepository laneCaseMappingRepository;

    @Autowired
    private ObjectMapper objectMapper;

    public List<Map<String, Object>> getTestCasesByWorkspace(UUID workspaceId) {
        List<TestCase> testCases = testCaseRepository.findByWorkspaceId(workspaceId);
        return testCases.stream().map(this::enrichTestCaseWithExecution).collect(Collectors.toList());
    }

    public Map<String, Object> getTestCaseDetail(UUID id) {
        TestCase testCase = testCaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("TestCase not found: " + id));
        return enrichTestCaseWithExecution(testCase);
    }

    private Map<String, Object> enrichTestCaseWithExecution(TestCase testCase) {
        Map<String, Object> result = new HashMap<>();
        result.put("case", testCase);
        if (testCase.getLastExecutionId() != null) {
            testExecutionRepository.findById(testCase.getLastExecutionId())
                    .ifPresent(execution -> result.put("lastExecution", execution));
        }
        return result;
    }

    @Transactional
    public TestCase createTestCase(TestCase testCase) {
        testCase.setLastUpdateTime(LocalDateTime.now());
        return testCaseRepository.save(testCase);
    }

    @Transactional
    public TestCase updateTestCaseName(UUID id, String name) {
        TestCase testCase = testCaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("TestCase not found: " + id));
        testCase.setName(name);
        testCase.setLastUpdateTime(LocalDateTime.now());
        return testCaseRepository.save(testCase);
    }

    @Transactional
    public TestCase updateTestCase(TestCase testCaseUpdate) {
        TestCase testCase = testCaseRepository.findById(testCaseUpdate.getId())
                .orElseThrow(() -> new RuntimeException("TestCase not found: " + testCaseUpdate.getId()));

        testCase.setName(testCaseUpdate.getName());
        testCase.setContract(testCaseUpdate.getContract());
        testCase.setLastUpdateTime(LocalDateTime.now());
        return testCaseRepository.save(testCase);
    }

    @Transactional
    public void deleteTestCase(UUID id) {
        TestCase testCase = testCaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("TestCase not found: " + id));

        laneCaseMappingRepository.deleteByTestCaseId(id);

        if (testCase.getLastExecutionId() != null) {
            testExecutionRepository.deleteById(testCase.getLastExecutionId());
        }

        testCaseRepository.delete(testCase);
    }

    public String generatePlaywrightCode(TestCase testCase) {
        if (StringUtils.isBlank(testCase.getContract())) {
            log.error("Test case {} contract is empty", testCase.getId());
            throw new RuntimeException("TestCase has no contract");
        }

        try {
            List<Map<String, String>> steps = objectMapper.readValue(testCase.getContract(), new TypeReference<>() {
            });
            return generatePlaywrightScript(testCase.getName(), steps);
        } catch (Exception e) {
            log.error("Failed to parse contract for test case {}", testCase.getId(), e);
            throw new RuntimeException("Failed to parse test case contract", e);
        }
    }

    private String generatePlaywrightScript(String testName, List<Map<String, String>> steps) {
        StringBuilder script = new StringBuilder();
        script.append("import { test, expect } from '@playwright/test';\n\n");
        script.append("test('").append(testName != null ? testName : "Recorded Test")
                .append("', async ({ page }) => {\n");

        for (Map<String, String> step : steps) {
            String type = step.get("type");
            String selector = step.get("selector");
            String value = step.get("value");

            if (StringUtils.isBlank(type)) {
                continue;
            }

            switch (type.toLowerCase()) {
                case "visit":
                case "goto":
                    script.append("  await page.goto('").append(value).append("');\n");
                    break;
                case "click":
                    script.append("  await page.click('").append(selector).append("');\n");
                    break;
                case "fill":
                case "type":
                    script.append("  await page.fill('").append(selector).append("', '")
                            .append(value).append("');\n");
                    break;
                case "wait":
                    script.append("  await page.waitForTimeout(")
                            .append(StringUtils.isNotBlank(value) ? value : "1000").append(");\n");
                    break;
                case "check":
                    if ("true".equalsIgnoreCase(value)) {
                        script.append("  await page.check('").append(selector).append("');\n");
                    } else {
                        script.append("  await page.uncheck('").append(selector).append("');\n");
                    }
                    break;
                case "select":
                    script.append("  await page.selectOption('").append(selector).append("', '")
                            .append(value).append("');\n");
                    break;
                default:
                    script.append("  // Unknown step type: ").append(type).append("\n");
            }
        }

        script.append("});\n");
        return script.toString();
    }

    public String getPlaywrightCodeById(UUID testCaseId) {
        TestCase testCase = testCaseRepository.findById(testCaseId)
                .orElseThrow(() -> new RuntimeException("TestCase not found: " + testCaseId));
        return generatePlaywrightCode(testCase);
    }
}
