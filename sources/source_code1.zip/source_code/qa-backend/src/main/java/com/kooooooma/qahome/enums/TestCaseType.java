package com.kooooooma.qahome.enums;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public enum TestCaseType {
    BACKEND,
    FRONTEND
}
