package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.service.TestCaseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@RestController
@RequestMapping("/api/testcase")
public class TestCaseController {

    @Autowired
    private TestCaseService testCaseService;

    @GetMapping("/workspace/{workspaceId}")
    public List<Map<String, Object>> getTestCasesByWorkspace(@PathVariable UUID workspaceId) {
        return testCaseService.getTestCasesByWorkspace(workspaceId);
    }

    @GetMapping("/{id}")
    public Map<String, Object> getTestCaseDetail(@PathVariable UUID id) {
        return testCaseService.getTestCaseDetail(id);
    }

    @PostMapping
    public TestCase createTestCase(@RequestBody TestCase testCase) {
        return testCaseService.createTestCase(testCase);
    }

    @PutMapping("/{id}")
    public TestCase updateTestCase(@PathVariable UUID id, @RequestBody TestCase testCase) {
        testCase.setId(id);
        return testCaseService.updateTestCase(testCase);
    }

    @PutMapping("/{id}/name")
    public TestCase updateTestCaseName(@PathVariable UUID id, @RequestBody Map<String, String> body) {
        return testCaseService.updateTestCaseName(id, body.get("name"));
    }

    @DeleteMapping("/{id}")
    public void deleteTestCase(@PathVariable UUID id) {
        testCaseService.deleteTestCase(id);
    }

    @GetMapping("/{id}/code")
    public Map<String, String> getPlaywrightCode(@PathVariable UUID id) {
        String code = testCaseService.getPlaywrightCodeById(id);
        return Map.of("code", code);
    }
}
