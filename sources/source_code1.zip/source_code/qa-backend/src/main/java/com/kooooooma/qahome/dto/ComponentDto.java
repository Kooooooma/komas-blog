package com.kooooooma.qahome.dto;

import lombok.Builder;
import lombok.Data;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Builder
@Data
public class ComponentDto {
    private String key;
    private String name;
}
