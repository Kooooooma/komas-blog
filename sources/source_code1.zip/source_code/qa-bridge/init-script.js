function getSelector(element) {
    return finder(element);
}

// Click event
document.addEventListener('click', (e) => {
    const el = e.target;
    const tagName = el.tagName.toLowerCase();

    // Checkbox
    if (tagName === 'input' && el.type === 'checkbox') {
        window.bridgeRecordEvent('check', getSelector(el), el.checked);
        return;
    }

    // Radio
    if (tagName === 'input' && el.type === 'radio') {
        window.bridgeRecordEvent('check', getSelector(el), el.checked);
        return;
    }

    // Click event
    window.bridgeRecordEvent('click', getSelector(el));
}, true);

// Change event - handle select, date, input
document.addEventListener('change', (e) => {
    const el = e.target;
    const tagName = el.tagName.toLowerCase();

    // Select dropdown
    if (tagName === 'select') {
        const selectedOption = el.options[el.selectedIndex];
        window.bridgeRecordEvent('select', getSelector(el), selectedOption ? selectedOption.value : '');
        return;
    }

    // Checkbox/Radio by click
    if (el.type === 'checkbox' || el.type === 'radio') {
        return;
    }

    // Date/DateTime/other input
    window.bridgeRecordEvent('fill', getSelector(el), el.value);
}, false);
