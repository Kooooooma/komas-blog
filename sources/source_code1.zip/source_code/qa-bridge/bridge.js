import express from 'express';
import axios from 'axios';
import { chromium } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { spawn } from 'child_process';
import { randomUUID } from 'crypto';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import config from './config.js';
import dotenv from 'dotenv';

// Global exception capture
process.on('uncaughtException', (error) => {
    console.error('❌ Uncaught Exception:', error);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ Unhandled Rejection at:', promise, 'reason:', reason);
});

// Initialize paths
const projectRoot = dirname(fileURLToPath(import.meta.url));
const testSpecDir = path.join(projectRoot, 'tests');
const reportsDir = path.join(projectRoot, 'reports');

if (!fs.existsSync(testSpecDir)) {
    fs.mkdirSync(testSpecDir);
}

if (!fs.existsSync(reportsDir)) {
    fs.mkdirSync(reportsDir);
}

dotenv.config({ path: path.resolve(projectRoot, '.env') });

const app = express();

// Persist BRIDGE_UUID in .env
let BRIDGE_UUID = process.env.BRIDGE_UUID;
if (!BRIDGE_UUID) {
    BRIDGE_UUID = randomUUID();
    console.log(`✨ Generating new Bridge UUID: ${BRIDGE_UUID}`);
    const envPath = path.resolve(projectRoot, '.env');
    const envContent = `\nBRIDGE_UUID=${BRIDGE_UUID}\n`;
    fs.appendFileSync(envPath, envContent);
}

let finderScript = fs.readFileSync(path.join(projectRoot, 'node_modules', '@medv', 'finder', 'finder.js'), 'utf-8');
finderScript = finderScript.replace(/export\s+/g, '');

const initScript = fs.readFileSync(path.join(projectRoot, 'init-script.js'), 'utf-8');

async function startBridge() {
    console.log('='.repeat(60));
    console.log(`🔑 Bridge UUID: ${BRIDGE_UUID}`);
    console.log('='.repeat(60));
    console.log('📢 Please enter this UUID in the E2E page to connect.');
    console.log(`📢 Config: Browser=${config.BROWSER_EXECUTABLE_PATH || 'default'}, Timeout=${config.RUN_TIMEOUT_MS}ms`);
    console.log('='.repeat(60));

    app.listen(config.PORT, () => {
        console.log(`🚀 Bridge server running on port ${config.PORT}`);
        connectToBackend();
    });
}

function connectToBackend() {
    console.log('📢 Connecting to backend with UUID:', BRIDGE_UUID);
    axios({
        method: 'get',
        url: `${config.BACKEND_URL}/api/bridge/register?source=bridge&bridgeUuid=${BRIDGE_UUID}`,
        responseType: 'stream'
    }).then(response => {
        console.log('📢 Connected to backend');
        const stream = response.data;

        stream.on('data', (chunk) => {
            const dataStr = chunk.toString();
            console.log('📢 Received data:', dataStr);
            try {
                const lines = dataStr.split('\n').filter(line => line.trim() !== '');
                lines.forEach(line => {
                    try {
                        let jsonStr = line;
                        if (line.startsWith('data:')) {
                            jsonStr = line.substring(5).trim();
                        }
                        if (!jsonStr) return;

                        const event = JSON.parse(jsonStr);
                        console.log('📢 Parsed event:', event);

                        if (event.type === config.EVENT_TYPE.PING) {
                            handlePingEvent();
                        } else if (event.type === config.EVENT_TYPE.RECORD) {
                            handleRecordEvent(event).catch(err => {
                                console.error('❌ Record error:', err);
                            });
                        } else if (event.type === config.EVENT_TYPE.RUN) {
                            handleRunEvent(event).catch(err => {
                                console.error('❌ Run error:', err);
                            });
                        }
                    } catch (e) {
                        // ignore parse errors for non-JSON lines
                    }
                });
            } catch (error) {
                console.error('❌ Error parsing event data:', error);
            }
        });

        stream.on('end', () => {
            console.log('❌ Connection ended, reconnecting in 5 seconds...');
            setTimeout(connectToBackend, 5000);
        });

        stream.on('error', (err) => {
            console.error('❌ Stream error:', err);
            setTimeout(connectToBackend, 5000);
        });

    }).catch(err => {
        console.error('❌ Connection failed:', err.message);
        setTimeout(connectToBackend, 5000);
    });
}

async function handleRecordEvent(event) {
    const { url, mode = 'auto' } = event;
    console.log(`📢 Starting record for URL: ${url}, mode: ${mode}`);

    // Manual mode: start Playwright Codegen
    if (mode === 'manual') {
        const codegenEnv = {
            ...process.env,
            ...(config.BROWSER_EXECUTABLE_PATH ?
                { PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH: config.BROWSER_EXECUTABLE_PATH } : {})
        };

        const codegenProcess = spawn('npx', ['playwright', 'codegen', url], {
            cwd: projectRoot,
            shell: true,
            env: codegenEnv,
            stdio: 'inherit'
        });

        codegenProcess.on('error', (err) => {
            console.error('❌ Codegen spawn error:', err);
        });

        codegenProcess.on('close', (code) => {
            console.log(`📢 Codegen closed with code: ${code}`);
            notifyBackend({
                type: config.EVENT_TYPE.CODEGEN_CLOSED,
                bridgeUuid: BRIDGE_UUID,
                message: 'Playwright Codegen closed. Please paste the generated code.'
            });
        });

        return;
    }

    // Auto mode: auto recording
    const launchOptions = {
        headless: false,
        viewport: null,
        args: ['--start-maximized'],
        slowMo: config.SLOW_MO_MS,
        ...(config.BROWSER_EXECUTABLE_PATH ?
            { executablePath: config.BROWSER_EXECUTABLE_PATH } : {})
    };

    const browser = await chromium.launchPersistentContext('', launchOptions);
    const page = browser.pages()[0] || await browser.newPage();
    const recordedEvents = [];

    // Watch for browser console errors
    page.on('console', msg => console.log(`🌐 Browser console [${msg.type()}]:`, msg.text()));
    page.on('pageerror', error => console.error('🌐 Browser error:', error.message));

    recordedEvents.push({ id: randomUUID(), type: 'visit', selector: '', value: url });

    // Expose functions to browser
    await page.exposeFunction('bridgeRecordEvent', (type, selector, value) => {
        console.log('📢 Recorded:', type, 'on', selector, value ? 'with ' + value : '');
        recordedEvents.push({
            id: randomUUID(),
            type: type.toLowerCase(),
            selector: selector.toLowerCase(),
            value: value !== undefined ? String(value) : ''
        });
    });

    // Inject selector generator and event listener
    await browser.addInitScript(finderScript + "\n" + initScript);

    await page.goto(url);

    // Send recorded events when browser closed
    browser.on('close', async () => {
        console.log('📢 Browser closed. Sending recorded events...');
        await sendLargeData(config.EVENT_TYPE.RECORD_FINISHED, JSON.stringify(recordedEvents), {
            bridgeUuid: BRIDGE_UUID
        }, 'recordedEvents');
    });
}

async function handleRunEvent(event) {
    const { testCaseId, executionId, contract, timeout } = event;
    const timeoutMs = timeout || config.RUN_TIMEOUT_MS;

    console.log(`📢 Received run request for execution ${executionId}, timeout: ${timeoutMs}ms`);

    const testFilePath = path.join(testSpecDir, `${executionId}.spec.js`);
    fs.writeFileSync(testFilePath, contract);

    const executionReportDir = path.join(reportsDir, executionId);
    if (!fs.existsSync(executionReportDir)) {
        fs.mkdirSync(executionReportDir, { recursive: true });
    }

    const runEnv = {
        ...process.env,
        PLAYWRIGHT_HTML_REPORT: executionReportDir,
        SLOW_MO: config.SLOW_MO_MS.toString(),
        ...(config.BROWSER_EXECUTABLE_PATH ?
            { PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH: config.BROWSER_EXECUTABLE_PATH } : {})
    };

    console.log(`📢 Executing test: ${testFilePath}`);
    console.log(`📢 Report will be saved to: ${executionReportDir}`);

    const child = spawn('npx', [
        'playwright', 'test', `${executionId}.spec.js`,
        '--headed', '--reporter=html'
    ], {
        cwd: projectRoot,
        env: runEnv,
        shell: true
    });

    let stdout = '';
    let stderr = '';
    let killed = false;

    // Timeout control
    const timeoutTimer = setTimeout(() => {
        killed = true;
        child.kill('SIGTERM');
        console.warn(`⚠️ Test execution timed out after ${timeoutMs}ms`);
    }, timeoutMs);

    child.stdout.on('data', (data) => {
        stdout += data.toString();
        console.log('📢 stdout:', data.toString());
    });

    child.stderr.on('data', (data) => {
        stderr += data.toString();
        console.error('❌ stderr:', data.toString());
    });

    child.on('error', (error) => {
        clearTimeout(timeoutTimer);
        console.error('❌ Spawn error:', error);
    });

    child.on('close', async (code) => {
        clearTimeout(timeoutTimer);
        console.log(`📢 Test finished with code: ${code}, killed: ${killed}`);

        const reportIndexPath = path.join(executionReportDir, 'index.html');
        let reportContent = '';
        if (fs.existsSync(reportIndexPath)) {
            reportContent = fs.readFileSync(reportIndexPath, 'utf-8');
        }

        let executionStatus = 'SUCCESS';
        if (killed) {
            executionStatus = 'TIMEOUT';
        } else if (code !== 0) {
            executionStatus = 'FAILURE';
        }

        await sendLargeData(config.EVENT_TYPE.EXECUTION_FINISHED, reportContent, {
            executionId,
            testCaseId,
            bridgeUuid: BRIDGE_UUID,
            executionStatus,
            logs: stdout + '\n' + stderr
        }, 'reportContent');
    });
}

function handlePingEvent() {
    console.log('📢 Received ping, sending pong...');
    notifyBackend({
        type: config.EVENT_TYPE.PONG,
        bridgeUuid: BRIDGE_UUID,
    });
}

async function sendLargeData(type, data, metadata, dataFieldName = 'data') {
    if (data.length <= config.CHUNK_SIZE) {
        return notifyBackend({
            type,
            ...metadata,
            [dataFieldName]: data
        });
    }

    console.log(`📤 Large data detected (${data.length} bytes), using chunked upload...`);

    try {
        const initResponse = await axios.post(
            `${config.BACKEND_URL}/api/bridge/upload/init`,
            {
                bridgeUuid: BRIDGE_UUID,
                type,
                totalSize: data.length,
                chunkSize: config.CHUNK_SIZE,
                dataFieldName,
                ...metadata
            }
        );
        const { uploadId } = initResponse.data;
        console.log(`📤 Upload initialized: ${uploadId}`);

        const totalChunks = Math.ceil(data.length / config.CHUNK_SIZE);
        for (let i = 0; i < totalChunks; i++) {
            const start = i * config.CHUNK_SIZE;
            const end = Math.min(start + config.CHUNK_SIZE, data.length);
            const chunk = data.substring(start, end);

            await axios.post(`${config.BACKEND_URL}/api/bridge/upload/chunk`, {
                uploadId,
                chunkIndex: i,
                data: chunk
            });
            console.log(`📤 Chunk ${i + 1}/${totalChunks} uploaded`);
        }

        await axios.post(`${config.BACKEND_URL}/api/bridge/upload/complete`, { uploadId });
        console.log('✅ Chunked upload complete');

    } catch (err) {
        console.error('❌ Chunked upload failed...');
        logError(err);
    }
}

async function notifyBackend(payload, retries = 3) {
    for (let i = 0; i < retries; i++) {
        try {
            await axios.post(`${config.BACKEND_URL}/api/bridge/notify/user`, payload, {
                maxContentLength: 10 * 1024 * 1024,
                maxBodyLength: 10 * 1024 * 1024
            });
            console.log('📢 Notification sent:', payload.type);
            return;
        } catch (err) {
            console.error(`❌ Attempt ${i + 1}/${retries} failed for ${payload.type}`);
            logError(err);

            if (i === retries - 1) {
                console.error('❌ All retries exhausted');
                return;
            }

            // Exponential backoff
            await new Promise(r => setTimeout(r, 1000 * (i + 1)));
        }
    }
}

function logError(err) {
    console.error('❌   URL:', err.config?.url);
    console.error('❌   Method:', err.config?.method?.toUpperCase());
    console.error('❌   Status:', err.response?.status);
    console.error('❌   StatusText:', err.response?.statusText);
    if (err.response?.data) {
        console.error('❌   Response Data:', JSON.stringify(err.response.data, null, 2));
    }
    console.error('❌   Message:', err.message);
}

startBridge();
