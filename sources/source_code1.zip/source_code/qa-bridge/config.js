export default {
    BROWSER_EXECUTABLE_PATH: process.env.BROWSER_PATH || '',
    RUN_TIMEOUT_MS: parseInt(process.env.RUN_TIMEOUT_MS) || 300000,
    SLOW_MO_MS: parseInt(process.env.SLOW_MO_MS) || 1000,
    CHUNK_SIZE: 3 * 1024 * 1024, // 3MB
    BACKEND_URL: process.env.BACKEND_URL || 'http://localhost:3300',
    PORT: parseInt(process.env.PORT) || 3302,
    EVENT_TYPE: {
        PING: 'PING',
        PONG: 'PONG',
        RECORD: 'RECORD',
        RUN: 'RUN',
        CODEGEN_CLOSED: 'CODEGEN_CLOSED',
        RECORD_FINISHED: 'RECORD_FINISHED',
        EXECUTION_FINISHED: 'EXECUTION_FINISHED'
    }
};
