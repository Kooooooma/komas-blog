"use client";

import useSWR from 'swr';
import { NEXT_PUBLIC_API_BASE_URL, NEXT_PUBLIC_API_PREFIX } from './config';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export const useConnectserverList = () => {
    const { data, error, isLoading } = useSWR<string[]>(
        `${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/component/connectserver/list`,
        fetcher
    );
    return {
        connectserverList: data,
        connectserverLoading: isLoading,
        connectserverLoadError: error,
    };
};