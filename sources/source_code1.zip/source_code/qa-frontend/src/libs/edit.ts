"use client";

import useSWR from 'swr';
import { NEXT_PUBLIC_API_BASE_URL, NEXT_PUBLIC_API_PREFIX } from './config';
import { getCurrentUser } from './auth';
import { fetchEventSource } from '@microsoft/fetch-event-source';

export interface ComponentMetadata {
    key: string;
    name: string;
    category: string;
}

export interface BridgeConnectionState {
    isConnected: boolean;
    bridgeUuid: string | null;
    lastPong: number | null;
}

const fetcher = (url: string) => fetch(url, {
    headers: {
        'x-employee-id': getCurrentUser() || ''
    }
}).then((res) => res.json());

export const useComponentList = () => {
    const { data, error, isLoading } = useSWR<Record<string, ComponentMetadata[]>>(
        `${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/component`,
        fetcher
    );

    return {
        components: data,
        isLoading,
        isError: error,
    };
};

export const updateTestCase = async (id: string, name: string, contract: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/testcase/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, contract }),
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to update test case[' + errorMessage + ']');
    }
    return response.json();
};

export const createTestCase = async (workspaceId: string, type: string, name: string, contract: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/testcase`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ workspaceId, type, name, contract }),
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to create test case[' + errorMessage + ']');
    }
    return response.json();
};

export const runTestCase = async (id: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/execution/run/${id}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-employee-id': getCurrentUser() || '',
        }
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to run test case[' + errorMessage + ']');
    }
    return response.json();
};

export const getTestCase = async (id: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/testcase/${id}`);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to load test case[' + errorMessage + ']');
    }
    return response.json();
};

export const recordTestCase = async (url: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/bridge/record`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-employee-id': getCurrentUser() || '',
        },
        body: JSON.stringify({ url })
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to start recording[' + errorMessage + ']');
    }
};

export const updateTestCaseName = async (id: string, name: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/testcase/${id}/name`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name }),
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to update test case name[' + errorMessage + ']');
    }
    return response.json();
};

export const getReportContent = async (executionId: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/execution/report/${executionId}`);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to load report[' + errorMessage + ']');
    }
    return response.text();
};

export const getTestCasesByWorkspace = async (workspaceId: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/testcase/workspace/${workspaceId}`);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to load test cases[' + errorMessage + ']');
    }
    return response.json();
};

export const deleteTestCase = async (id: string) => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/testcase/${id}`, {
        method: 'DELETE',
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to delete test case[' + errorMessage + ']');
    }
};

export const getUserAndBridgeBindStatus = async (): Promise<{ connected: boolean; bridgeUuid: string }> => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/bridge/status`, {
        headers: {
            'x-employee-id': getCurrentUser() || '',
        }
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to get user and bridge bind status[' + errorMessage + ']');
    }
    return response.json();
};

export const bindBridge = async (bridgeUuid: string): Promise<{ success: boolean }> => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/bridge/bind`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'x-employee-id': getCurrentUser() || '',
        },
        body: JSON.stringify({ bridgeUuid })
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to bind bridge[' + errorMessage + ']');
    }
    return response.json();
};

export const pingBridge = async (): Promise<{ sent: boolean }> => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/bridge/ping`, {
        method: 'POST',
        headers: {
            'x-employee-id': getCurrentUser() || '',
        }
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to ping bridge[' + errorMessage + ']');
    }
    return response.json();
};

export const getPlaywrightCode = async (testCaseId: string): Promise<string> => {
    const response = await fetch(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/testcase/${testCaseId}/code`);
    if (!response.ok) {
        let errorMessage = 'Failed to get playwright code';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to get playwright code[' + errorMessage + ']');
    }
    const data = await response.json();
    return data.code;
};

export const useBridgeEvents = (
    messageApi: any,
    onRecordFinished?: (data: any) => void,
    onExecutionFinished?: (data: any) => void,
    onPong?: () => void
) => {
    const abortController = new AbortController();

    fetchEventSource(`${NEXT_PUBLIC_API_BASE_URL}${NEXT_PUBLIC_API_PREFIX}/bridge/register?source=user`, {
        method: 'GET',
        headers: {
            'Content-Type': 'text/event-stream',
            'x-employee-id': getCurrentUser() || '',
        },
        signal: abortController.signal,
        // prevent reconnection on tab switch
        openWhenHidden: true,
        onmessage(event) {
            try {
                console.log("onmessage", event);
                const data = JSON.parse(event.data);
                if (data.type === 'RECORD_FINISHED') {
                    messageApi.success("Recording finished");
                    if (onRecordFinished) {
                        onRecordFinished(data);
                    }
                } else if (data.type === 'EXECUTION_FINISHED') {
                    messageApi.success("Execution finished");
                    if (onExecutionFinished) {
                        onExecutionFinished(data);
                    }
                } else if (data.type === 'PONG') {
                    console.log("Received pong from bridge: ", data.bridgeUuid);
                    if (onPong) {
                        onPong();
                    }
                }
            } catch (e) {
                console.error('Parse error:', e);
            }
        },
        async onopen(response) {
            console.log("SSE onopen", response);
            if (!response.ok) {
                messageApi.error('Failed to open SSE connection');
            }
        },
        onerror(err) {
            console.log("SSE onerror", err);
            messageApi.error('Failed to open SSE connection');
        },
    });

    return {
        abort: () => {
            abortController.abort();
        }
    };
}
