export const NEXT_PUBLIC_API_BASE_URL = process.env.NEXT_PUBLIC_API_HOST || 'http://localhost:3300';

export const NEXT_PUBLIC_API_PREFIX = '/api';
