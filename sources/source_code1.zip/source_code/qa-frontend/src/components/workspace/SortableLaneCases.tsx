"use client";

import { Flex, Typography } from "antd";
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, horizontalListSortingStrategy } from '@dnd-kit/sortable';
import DraggableCaseCard from './DraggableCaseCard';

const { Text } = Typography;

interface LaneCase {
    case: {
        id: string;
        name: string;
        type: string;
    };
    lastExecution?: {
        status: string;
        startTime: string;
    };
}

interface SortableLaneCasesProps {
    laneId: string;
    cases: LaneCase[];
    getStatusColor: (status?: string) => string;
    formatDateTime: (dateStr?: string) => string;
    onEditCase: (caseId: string) => void;
    onRemoveCase: (laneId: string, caseId: string) => void;
    onReorder: (laneId: string, newCaseIds: string[]) => void;
}

export default function SortableLaneCases({
    laneId,
    cases,
    getStatusColor,
    formatDateTime,
    onEditCase,
    onRemoveCase,
    onReorder,
}: SortableLaneCasesProps) {
    const sensors = useSensors(
        useSensor(PointerSensor, {
            activationConstraint: {
                distance: 5,
            },
        }),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;
        if (over && active.id !== over.id) {
            const oldIndex = cases.findIndex(c => c.case.id === active.id);
            const newIndex = cases.findIndex(c => c.case.id === over.id);
            const newCases = arrayMove(cases, oldIndex, newIndex);
            const newCaseIds = newCases.map(c => c.case.id);
            onReorder(laneId, newCaseIds);
        }
    };

    if (cases.length === 0) {
        return <Text type="secondary">No cases in this lane</Text>;
    }

    return (
        <DndContext
            sensors={sensors}
            collisionDetection={closestCenter}
            onDragEnd={handleDragEnd}
        >
            <SortableContext
                items={cases.map(c => c.case.id)}
                strategy={horizontalListSortingStrategy}
            >
                <Flex wrap={false} style={{ overflowX: 'auto', padding: '10px' }} gap="middle">
                    {cases.map((caseItem) => (
                        <DraggableCaseCard
                            key={caseItem.case.id}
                            caseId={caseItem.case.id}
                            caseName={caseItem.case.name}
                            caseType={caseItem.case.type}
                            lastExecutionStatus={caseItem.lastExecution?.status}
                            lastExecutionTime={caseItem.lastExecution?.startTime}
                            getStatusColor={getStatusColor}
                            formatDateTime={formatDateTime}
                            onEdit={() => onEditCase(caseItem.case.id)}
                            onRemove={() => onRemoveCase(laneId, caseItem.case.id)}
                        />
                    ))}
                </Flex>
            </SortableContext>
        </DndContext>
    );
}
