"use client";

import { useState } from 'react';
import { EditOutlined } from '@ant-design/icons';
import { Typography, Button, Modal, Input } from 'antd';
import { NodeData } from './NodeData';
import { useReactFlow } from '@xyflow/react';
import { useCommonStore } from '@/store/commonStore';

export default function NodeTitle({ id, title, nodeData }: { id: string, title: string, nodeData: NodeData }) {
    const { Title } = Typography;
    const { updateNodeData } = useReactFlow();
    const [showUpdateCaseNameModal, setShowUpdateCaseNameModal] = useState(false);
    const setHasUnsavedChanges = useCommonStore((state) => state.setHasUnsavedChanges);

    const handleUpdateNodeData = (title: string) => {
        updateNodeData(id, { ...nodeData, name: title });
        setHasUnsavedChanges(true);
    };

    return <Title level={5}>
        {title}
        <Button type="text" size="small" icon={<EditOutlined />} onClick={() => setShowUpdateCaseNameModal(true)} style={{ marginLeft: '5px' }} />
        <Modal
            title="Update Name"
            open={showUpdateCaseNameModal}
            onOk={() => setShowUpdateCaseNameModal(false)}
            onCancel={() => setShowUpdateCaseNameModal(false)}
        >
            <Input value={title} onChange={(e) => handleUpdateNodeData(e.target.value)} />
        </Modal>
    </Title>;
}
