"use client";

import { Input } from 'antd';
import { Position, Handle, NodeProps, useReactFlow } from '@xyflow/react';
import { useCommonStore } from '@/store/commonStore';
import NodeTitle from './NodeTitle';
import { NodeData } from './NodeData';


export default function InputNode({ id, selected, data }: NodeProps) {
    const { updateNodeData } = useReactFlow();
    const setHasUnsavedChanges = useCommonStore((state) => state.setHasUnsavedChanges);

    // Cast data to specific type to safely access properties
    const nodeData = data as unknown as NodeData;

    const handleValueChange = (value: string) => {
        // Update node data in ReactFlow state
        updateNodeData(id, { ...nodeData, inputValue: value });
        setHasUnsavedChanges(true);
    };

    return (
        <div style={{
            padding: '5px 10px 13px 10px',
            backgroundColor: '#fff',
            minWidth: '200px',
            minHeight: '70px',
            borderRadius: '6px',
            border: selected ? '2px solid #ff4d4f' : '1px solid #b1b1b7',
            boxShadow: selected ? '0 0 8px rgba(255, 77, 79, 0.3)' : 'none',
        }}>
            <NodeTitle title={nodeData.name} id={id} nodeData={nodeData} />
            <Input onChange={(e) => handleValueChange(e.target.value)} value={nodeData.inputValue} />
            <Handle type="target" position={Position.Top} />
            <Handle type="source" position={Position.Bottom} />
        </div >
    );
}