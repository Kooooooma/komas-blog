export interface NodeData extends Record<string, string | null | undefined> {
    name: string;
    inputValue?: string;
}