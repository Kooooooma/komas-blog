"use client";

import { Select } from 'antd';
import { Position, Handle, NodeProps, useReactFlow } from '@xyflow/react';
import { useCommonStore } from '@/store/commonStore';
import NodeTitle from './NodeTitle';
import { NodeData } from './NodeData';
import { useConnectserverList } from '@/libs/component';
import { useMemo } from 'react';

export default function SelectNode({ id, selected, data }: NodeProps) {
    const { updateNodeData } = useReactFlow();
    const setHasUnsavedChanges = useCommonStore((state) => state.setHasUnsavedChanges);
    const nodeData = data as unknown as NodeData;

    //================ load server list
    const { connectserverList, connectserverLoading, connectserverLoadError } = useConnectserverList();

    const databaseOptions = useMemo(() => {
        if (!connectserverList) return [];
        return connectserverList && connectserverList.map((connectserver) => ({
            value: connectserver,
            label: connectserver
        }));
    }, [connectserverList]);

    const renderSelect = () => {
        if (connectserverLoading) return <Select loading />;
        if (connectserverLoadError) return <Select disabled />;
        return <Select
            style={{ width: '100%' }}
            allowClear
            options={databaseOptions}
            value={nodeData.inputValue}
            onChange={handleChange}
            className='nodrag'
            onClick={(e) => e.stopPropagation()}
            onMouseDown={(e) => e.stopPropagation()}
        />;
    };
    //================ load server list

    const handleChange = (value: string) => {
        // Update node data in ReactFlow state
        updateNodeData(id, { ...data, inputValue: value });
        setHasUnsavedChanges(true);
    };

    return (
        <div style={{
            padding: '13px 10px',
            backgroundColor: '#fff',
            minWidth: '200px',
            minHeight: '70px',
            borderRadius: '6px',
            border: selected ? '2px solid #ff4d4f' : '1px solid #b1b1b7',
            boxShadow: selected ? '0 0 8px rgba(255, 77, 79, 0.3)' : 'none',
        }}>
            <NodeTitle id={id} title={nodeData.name} nodeData={nodeData} />
            {renderSelect()}
            <Handle type="target" position={Position.Top} />
            <Handle type="source" position={Position.Bottom} />
        </div >
    );
}