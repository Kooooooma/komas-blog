"use client";

import { Flex, Layout, Typography, Button, Modal, Input, Tooltip, Spin, Drawer, message, Empty } from "antd";
import { EditOutlined } from '@ant-design/icons';
import { ArrowLeftFromLine } from 'lucide-react';
import { useState, useEffect, useRef, Suspense } from "react";
import { motion } from "motion/react";
import Ansi from 'react-ansi';
import { useEditorStore } from "@/store/editorStore";
import { useAuthRedirect } from '@/hooks/useAuthRedirect'
import { useRouter, useSearchParams } from 'next/navigation';
import {
    useComponentList, updateTestCase, runTestCase, createTestCase,
    getTestCase, updateTestCaseName, getReportContent
} from "@/libs/edit";
import { useCommonStore } from '@/store/commonStore';

export default function EditorLayoutWrapper({ children }: { children: React.ReactNode }) {
    return (
        <Suspense fallback={<div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}><Spin size="large" /></div>}>
            <EditorLayout>{children}</EditorLayout>
        </Suspense>
    );
}

function EditorLayout({ children }: { children: React.ReactNode }) {
    useAuthRedirect();
    const { Header, Content, Sider } = Layout;
    const { Title, Text } = Typography;
    const [messageApi, messageContextHolder] = message.useMessage();
    const router = useRouter();
    const searchParams = useSearchParams();
    const initialTestCaseId = searchParams.get('id');
    const workspaceId = searchParams.get('workspaceId');

    const [testCaseId, setTestCaseId] = useState<string | null>(initialTestCaseId);
    const [caseName, setCaseName] = useState("");

    // New States
    const [execution, setExecution] = useState<any>(null);
    const [showUpdateCaseNameModal, setShowUpdateCaseNameModal] = useState(false);
    const [logsVisible, setLogsVisible] = useState(false);
    const [isRunning, setIsRunning] = useState(false);

    // Unsaved changes
    const { setHasUnsavedChanges, hasUnsavedChanges, isSelectEvent, setIsSelectEvent } = useCommonStore();
    const nodes = useEditorStore((state) => state.nodes);
    const edges = useEditorStore((state) => state.edges);
    const setNodes = useEditorStore((state) => state.setNodes);
    const setEdges = useEditorStore((state) => state.setEdges);

    // Track initial load - use ref to skip the first change detection after load
    const [isLoaded, setIsLoaded] = useState(false);
    const skipNextChangeRef = useRef(false);

    useEffect(() => {
        const loadTestCase = async () => {
            if (testCaseId) {
                try {
                    const data = await getTestCase(testCaseId);
                    if (!data.case) {
                        messageApi.error("Test case not found");
                        return;
                    }
                    setExecution(data?.lastExecution);
                    setCaseName(data.case.name);
                    if (data.case.contract) {
                        const contract = JSON.parse(data.case.contract);
                        if (contract.nodes && contract.edges) {
                            // Mark to skip the next change detection
                            skipNextChangeRef.current = true;
                            setNodes(contract.nodes);
                            setEdges(contract.edges);
                            setIsLoaded(true);
                            // Ensure hasUnsavedChanges is false after load
                            setHasUnsavedChanges(false);
                        }
                    }
                } catch (e) {
                    messageApi.error("Failed to load test case");
                }
            } else {
                // New case - clear previous data
                skipNextChangeRef.current = true;
                setNodes([]);
                setEdges([]);
                const now = new Date();
                const iso = now.toISOString();
                setCaseName(`New Case ${iso.replace('T', ' ').substring(0, 19)}`);
                setExecution(null);
                setHasUnsavedChanges(false);
                setIsLoaded(true);
            }
        };
        loadTestCase();
    }, [testCaseId]);

    useEffect(() => {
        if (skipNextChangeRef.current) {
            skipNextChangeRef.current = false;
            return;
        }
        if (isLoaded && !isSelectEvent) {
            setHasUnsavedChanges(true);
        }
        if (isSelectEvent) {
            setIsSelectEvent(false);
        }
    }, [nodes, edges]);

    const addNode = useEditorStore((state) => state.addNode);

    const { components, isLoading: isStepsLoading } = useComponentList();

    const handleAddNode = (nodeType: string, nodeName: string) => {
        addNode(nodeType, nodeName);
    };

    const handleUpdateName = async () => {
        if (testCaseId) {
            try {
                await updateTestCaseName(testCaseId, caseName);
                messageApi.success("Name updated");
                setShowUpdateCaseNameModal(false);
            } catch (err) {
                messageApi.error(err instanceof Error ? err.message : 'Failed to update test case name');
            }
        } else {
            setShowUpdateCaseNameModal(false);
        }
    };

    const handleSave = async () => {
        const payload = { nodes, edges };
        const contract = JSON.stringify(payload);
        try {
            if (testCaseId) {
                await updateTestCase(testCaseId, caseName, contract);
                messageApi.success("Test case updated successfully");
            } else {
                const wid = workspaceId;
                if (!wid) {
                    messageApi.error("Missing workspace ID to create test case");
                    return;
                }
                const newCase = await createTestCase(wid, 'BACKEND', caseName, contract);
                setTestCaseId(newCase.id);
                router.replace(`/edit?id=${newCase.id}&workspaceId=${wid}`);
                messageApi.success("Test case created successfully");
            }
            setHasUnsavedChanges(false);
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to save test case');
        }
    };

    const handleRun = async () => {
        if (!testCaseId) {
            messageApi.error("Please save test case first");
            return;
        }

        setIsRunning(true);
        try {
            messageApi.loading({ content: 'Running test case...', key: 'run' });
            const executionData = await runTestCase(testCaseId);
            setExecution(executionData);
            messageApi.success({ content: 'Test case executed successfully', key: 'run' });
        } catch (err) {
            messageApi.error({ content: err instanceof Error ? err.message : 'Failed to run test case', key: 'run' });
        } finally {
            setIsRunning(false);
        }
    };

    const handleViewReport = async () => {
        if (!execution || !execution.id) {
            messageApi.warning("No execution available. Please run the test case first.");
            return;
        }

        try {
            const htmlContent = await getReportContent(execution.id);
            const newWindow = window.open('', '_blank');
            if (newWindow) {
                newWindow.document.write(htmlContent);
                newWindow.document.close();
                newWindow.document.title = `Test Report - ${caseName}`;
            } else {
                messageApi.error("Failed to open new window. Please check popup blocker.");
            }
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to load report');
        }
    };

    return (
        <Layout>
            <Header style={{ backgroundColor: 'white', padding: '0 10px', height: '50px', borderBottom: '1px solid #f0f0f0' }}>
                <Flex align="center" justify="space-between">
                    <Flex justify="flex-start" style={{ marginTop: '10px' }}>
                        <Tooltip title="Back to Home">
                            <motion.div
                                whileHover={{ scale: 1.2, x: -3 }}
                                transition={{ type: "spring", stiffness: 400, damping: 17 }}
                                style={{ display: 'inline-flex', cursor: 'pointer' }}
                            >
                                <ArrowLeftFromLine style={{ marginRight: '10px', marginLeft: '5px', color: '#ff4d4f' }} onClick={() => router.back()} />
                            </motion.div>
                        </Tooltip>
                        <Text>{caseName}</Text>
                        <Button type="text" size="small" icon={<EditOutlined />} onClick={() => setShowUpdateCaseNameModal(true)} style={{ marginLeft: '5px' }} />
                    </Flex>
                    <Flex justify="flex-end" gap={8} style={{ marginTop: '10px', marginRight: '15px' }}>
                        {/* <Button onClick={handleViewReport}>View Report</Button> */}
                        <Button onClick={() => setLogsVisible(true)}>Check Logs</Button>
                        <Button onClick={handleRun} loading={isRunning} disabled={isRunning}>Run</Button>
                        <Button type='primary' danger={hasUnsavedChanges} onClick={handleSave}>Save</Button>
                    </Flex>
                </Flex>
            </Header>
            <Layout>
                <Sider style={{ backgroundColor: 'white', height: 'calc(100vh - 50px)', overflow: 'auto' }}>
                    <Flex vertical style={{ padding: '10px' }}>
                        {isStepsLoading ? <Spin /> : Object.entries(components || {}).map(([category, componentsList]) => (
                            <Flex key={category} vertical style={{ marginBottom: '15px' }}>
                                <Title level={5}>{category}</Title>
                                <Flex wrap gap={8}>
                                    {componentsList.map(component => (
                                        <Button key={component.key} onClick={() => handleAddNode(component.key, component.name)}>
                                            {component.name}
                                        </Button>
                                    ))}
                                </Flex>
                            </Flex>
                        ))}
                    </Flex>
                </Sider>
                <Content style={{ height: 'calc(100vh - 50px)', overflow: 'auto' }}>
                    {children}
                </Content>
            </Layout>
            <Modal open={showUpdateCaseNameModal}
                title="Update Case Name"
                onOk={handleUpdateName}
                onCancel={() => setShowUpdateCaseNameModal(false)}
            >
                <Input style={{ margin: '15px 0' }} value={caseName} onChange={(e) => setCaseName(e.target.value)} />
            </Modal>

            <Drawer title="Execution Logs" placement="right" onClose={() => setLogsVisible(false)} open={logsVisible} width={700}>
                {execution ? (
                    <div>
                        <Text strong>Status: </Text><Text>{execution.status}</Text><br />
                        <Text strong>Start Time: </Text><Text>{execution.startTime}</Text><br />
                        <div style={{
                            marginTop: '10px',
                            backgroundColor: '#222',
                            color: '#FFF',
                            padding: '15px',
                            fontFamily: 'monospace',
                            whiteSpace: 'pre-wrap'
                        }}>
                            <Ansi log={execution.logs || "No logs available."} />
                        </div>
                    </div>
                ) : <Empty description="No execution data" />}
            </Drawer>
            {messageContextHolder}
        </Layout >
    )
}
