"use client";

import EditorCanvas from "@/components/editor/EditorCanvas";

export default function Editor() {
    return (
        <div style={{ width: '100%', height: '100%' }}>
            <EditorCanvas />
        </div>
    );
}