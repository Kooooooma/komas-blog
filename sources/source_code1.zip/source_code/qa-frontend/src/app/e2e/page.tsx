"use client";

import {
    Layout, Flex, Button, Tooltip,
    Modal, Input, Spin, Drawer, message, Empty, Typography, List, Select, Badge
} from "antd";
import { ArrowLeftFromLine, Code, Siren } from 'lucide-react';
import {
    EditOutlined, VideoCameraOutlined, PlusOutlined, DeleteOutlined,
    HolderOutlined, PlayCircleOutlined, FileTextOutlined
} from '@ant-design/icons';
import { useState, useEffect, useMemo, createContext, useContext, useRef, Suspense } from "react";
import { motion } from "motion/react";
import { DndContext, DraggableAttributes, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import type { SyntheticListenerMap } from '@dnd-kit/core/dist/hooks/utilities';
import { useAuthRedirect } from '@/hooks/useAuthRedirect'
import { useRouter, useSearchParams } from 'next/navigation';
import {
    updateTestCaseName, getTestCase, recordTestCase,
    runTestCase, useBridgeEvents, getUserAndBridgeBindStatus, bindBridge, pingBridge, getPlaywrightCode,
    updateTestCase, getReportContent, createTestCase

} from "@/libs/edit";
import type { GetProps } from 'antd';
import { restrictToVerticalAxis } from '@dnd-kit/modifiers';

interface RecordedEvent {
    id: string;
    type: string;
    selector: string;
    value: string;
    [key: string]: any
}

interface SortableListItemContextProps {
    setActivatorNodeRef?: (element: HTMLElement | null) => void;
    listeners?: SyntheticListenerMap;
    attributes?: DraggableAttributes;
}

type ConnectionStatus = 'disconnected' | 'connected' | 'busy';

export default function E2EPageWrapper() {
    return (
        <Suspense fallback={<div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}><Spin size="large" /></div>}>
            <E2EPage />
        </Suspense>
    );
}

function E2EPage() {
    useAuthRedirect();
    const { Header, Content } = Layout;
    const { Text } = Typography;
    const { Option } = Select;
    const [messageApi, messageContextHolder] = message.useMessage();
    const router = useRouter();
    const searchParams = useSearchParams();
    const initialTestCaseId = searchParams.get('id');
    const workspaceId = searchParams.get('workspaceId');

    const [testCaseId, setTestCaseId] = useState<string | null>(initialTestCaseId);
    const [caseName, setCaseName] = useState("");

    const [targetUrl, setTargetUrl] = useState("");
    const [connectionStatus, setConnectionStatus] = useState<ConnectionStatus>('disconnected');
    const [isRecording, setIsRecording] = useState(false);
    const [isRunning, setIsRunning] = useState(false);
    const [showRecordModal, setShowRecordModal] = useState(false);
    const [showBindModal, setShowBindModal] = useState(false);
    const [bridgeUuidInput, setBridgeUuidInput] = useState("");
    const [recordedContract, setRecordedContract] = useState<RecordedEvent[]>([]);
    const [showUpdateCaseNameModal, setShowUpdateCaseNameModal] = useState(false);
    const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);

    // Code drawer state
    const [showCodeDrawer, setShowCodeDrawer] = useState(false);
    const [playwrightCode, setPlaywrightCode] = useState("");
    const [loadingCode, setLoadingCode] = useState(false);

    // Pong tracking for connection test
    const pongReceivedRef = useRef(false);
    const pingTimeout = 1000;
    const pingTimeoutRef = useRef<NodeJS.Timeout | null>(null);
    const healthCheckInterval = 5000;
    const healthCheckIntervalRef = useRef<NodeJS.Timeout | null>(null);

    const refreshTestCase = async () => {
        if (testCaseId) {
            try {
                const data = await getTestCase(testCaseId);
                setCaseName(data.case.name || "");
                if (data.case.contract) {
                    setRecordedContract(JSON.parse(data.case.contract) || []);
                }
            } catch (err) {
                messageApi.error(err instanceof Error ? err.message : 'Failed to refresh test case');
            }
        }
    }

    useEffect(() => {
        if (testCaseId) {
            refreshTestCase();
        } else {
            const now = new Date();
            const iso = now.toISOString();
            setCaseName(`New Case ${iso.replace('T', ' ').substring(0, 19)}`);
        }

        // Load stored bridge uuid
        const storedUuid = localStorage.getItem('bridgeUuid');
        if (storedUuid) {
            setBridgeUuidInput(storedUuid);
        }
    }, [testCaseId]);

    // initialize SSE connection
    useEffect(() => {
        const handlers = useBridgeEvents(
            messageApi,
            // onRecordFinished
            (data) => {
                console.log("Record finished, data:", data);
                setIsRecording(false);
                setConnectionStatus('connected');
                if (data.recordedEvents) {
                    try {
                        const events = JSON.parse(data.recordedEvents);
                        setRecordedContract(events);
                        setHasUnsavedChanges(true);
                    } catch (e) {
                        console.error("Failed to parse recorded events:", e);
                    }
                }
            },
            // onExecutionFinished
            (data) => {
                console.log("Execution finished, data:", data);
                setIsRunning(false);
                setConnectionStatus('connected');
                if (data.executionStatus === 'SUCCESS') {
                    messageApi.success("Test execution completed successfully!");
                } else {
                    messageApi.error("Test execution failed!");
                }
            },
            // onPong
            () => {
                console.log("Pong received!");
                pongReceivedRef.current = true;
                setConnectionStatus('connected');
            }
        );

        // double check user and bridge bind status
        checkUserAndBridgeBindStatus();

        // health check
        healthCheckIntervalRef.current = setInterval(() => {
            if (connectionStatus === 'connected') {
                checkConnectionHealth();
            }
        }, healthCheckInterval);

        return () => { // cleanup before re-run
            handlers.abort();
            if (pingTimeoutRef.current) {
                clearTimeout(pingTimeoutRef.current);
            }
            if (healthCheckIntervalRef.current) {
                clearInterval(healthCheckIntervalRef.current);
            }
        };
    }, []);

    const checkUserAndBridgeBindStatus = async () => {
        try {
            const status = await getUserAndBridgeBindStatus();
            if (status.connected) {
                setConnectionStatus('connected');
            } else {
                setConnectionStatus('disconnected');
            }
        } catch (err) {
            console.error("Failed to check user and bridge bind status:", err);
            setConnectionStatus('disconnected');
        }
    };

    const checkConnectionHealth = async () => {
        try {
            console.log("Checking connection health...");
            pongReceivedRef.current = false;
            await pingBridge();

            // Wait for pong response
            pingTimeoutRef.current = setTimeout(() => {
                if (!pongReceivedRef.current) {
                    console.log("Ping timeout - connection lost");
                    setConnectionStatus('disconnected');
                }
            }, pingTimeout);
        } catch (err) {
            console.error("Health check failed:", err);
            setConnectionStatus('disconnected');
        }
    };

    const handleBindBridge = async () => {
        if (!bridgeUuidInput.trim()) {
            messageApi.error("Please enter the Bridge UUID");
            return;
        }
        try {
            await bindBridge(bridgeUuidInput.trim());
            messageApi.success("Bridge bound successfully!");
            localStorage.setItem('bridgeUuid', bridgeUuidInput.trim());
            setShowBindModal(false);
            await testConnection();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to bind bridge');
        }
    };

    const testConnection = async () => {
        try {
            pongReceivedRef.current = false;
            await pingBridge();
            messageApi.loading({ content: "Testing connection...", duration: 0, key: "connection-test" });

            // Wait for pong
            pingTimeoutRef.current = setTimeout(() => {
                messageApi.destroy("connection-test");
                if (pongReceivedRef.current) {
                    messageApi.success("Connection established!");
                    setConnectionStatus('connected');
                } else {
                    messageApi.error("Connection test failed - no response from bridge");
                    setConnectionStatus('disconnected');
                }
            }, pingTimeout);
        } catch (err) {
            messageApi.destroy("connection-test");
            messageApi.error(err instanceof Error ? err.message : 'Connection test failed');
            setConnectionStatus('disconnected');
        }
    };

    const handleSirenClick = async () => {
        const storedUuid = localStorage.getItem('bridgeUuid');
        if (storedUuid) {
            try {
                messageApi.loading({ content: "Re-connecting to bridge [" + storedUuid + "]", key: "rebind", duration: 0 });
                await bindBridge(storedUuid);
                messageApi.success({ content: "Bridge re-connected [" + storedUuid + "]", key: "rebind" });
                setConnectionStatus('connected');
                await testConnection();
                return;
            } catch (err) {
                messageApi.destroy("rebind");
                messageApi.error(err instanceof Error ? err.message : 'Failed to re-connect to bridge');
            }
        }
        setShowBindModal(true);
    };

    const handleUpdateName = async () => {
        if (testCaseId) {
            try {
                await updateTestCaseName(testCaseId, caseName);
                messageApi.success("Name updated");
                setShowUpdateCaseNameModal(false);
            } catch (err) {
                messageApi.error(err instanceof Error ? err.message : 'Failed to update test case name');
            }
        } else {
            setShowUpdateCaseNameModal(false);
        }
    };

    const handleSave = async () => {
        const contract = JSON.stringify(recordedContract);
        try {
            if (testCaseId) {
                await updateTestCase(testCaseId, caseName, contract);
                messageApi.success("Test case updated successfully");
            } else {
                const wid = workspaceId;
                if (!wid) {
                    messageApi.error("Missing workspace ID to create test case");
                    return;
                }
                const newCase = await createTestCase(wid, "FRONTEND", caseName, contract);
                setTestCaseId(newCase.id);
                router.replace(`/e2e?id=${newCase.id}&workspaceId=${wid}`);
                messageApi.success("Test case created successfully");
            }
            setHasUnsavedChanges(false);
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to save test case');
        }
    };

    const handleRecordClick = async () => {
        if (connectionStatus === 'disconnected') {
            setShowBindModal(true);
            return;
        }
        setShowRecordModal(true);
    };

    const handleStartRecording = async () => {
        if (!targetUrl.trim()) {
            messageApi.error("Please enter a URL to record");
            return;
        }
        try {
            await recordTestCase(targetUrl);
            setIsRecording(true);
            setConnectionStatus('busy');
            setShowRecordModal(false);
            messageApi.success("Start recording... Close the browser when done.");
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to start recording');
        }
    };

    const handleRun = async () => {
        if (!testCaseId) {
            messageApi.error("Please save test first");
            return;
        }
        if (connectionStatus === 'disconnected') {
            setShowBindModal(true);
            return;
        }
        try {
            setIsRunning(true);
            setConnectionStatus('busy');
            await runTestCase(testCaseId);
            messageApi.loading("Running test case...");
        } catch (err) {
            setIsRunning(false);
            setConnectionStatus('connected');
            messageApi.error(err instanceof Error ? err.message : 'Failed to start run');
        }
    }

    const handleViewCode = async () => {
        if (!testCaseId) {
            messageApi.error("No test case to view code");
            return;
        }
        try {
            setLoadingCode(true);
            setShowCodeDrawer(true);
            const code = await getPlaywrightCode(testCaseId);
            setPlaywrightCode(code);
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to load code');
        } finally {
            setLoadingCode(false);
        }
    };

    const handleViewReport = async () => {
        if (!testCaseId) {
            messageApi.error("No test case to view report");
            return;
        }
        try {
            const data = await getTestCase(testCaseId);
            if (!data.lastExecution) {
                messageApi.warning("No execution found for this test case");
                return;
            }

            const executionId = data.lastExecution.id;
            const reportHtml = await getReportContent(executionId);

            const newWindow = window.open('', '_blank');
            if (newWindow) {
                newWindow.document.title = data.case.name;
                newWindow.document.write(reportHtml);
                newWindow.document.close();
                newWindow.addEventListener('DOMContentLoaded', () => {
                    newWindow.document.title = data.case.name;
                });
                setTimeout(() => {
                    if (newWindow && !newWindow.closed) {
                        newWindow.document.title = data.case.name;
                    }
                }, 300);
            } else {
                messageApi.error("Failed to open new tab - please allow popups");
            }
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to load report');
        }
    };

    const handleDragEnd = ({ active, over }: DragEndEvent) => {
        if (!active || !over) {
            return;
        }
        if (active.id !== over.id) {
            setRecordedContract((prevState) => {
                const activeIndex = prevState.findIndex((i) => i.id === active.id);
                const overIndex = prevState.findIndex((i) => i.id === over.id);
                setHasUnsavedChanges(true);
                return arrayMove(prevState, activeIndex, overIndex);
            });
        }
    };

    const SortableListItemContext = createContext<SortableListItemContextProps>({});

    const SortableListItem = (props: GetProps<typeof List.Item> & { itemKey: string }) => {
        const { itemKey, style, ...rest } = props;

        const {
            attributes,
            listeners,
            setNodeRef,
            setActivatorNodeRef,
            transform,
            transition,
            isDragging,
        } = useSortable({ id: itemKey });

        const listStyle: React.CSSProperties = {
            ...style,
            transform: CSS.Translate.toString(transform),
            transition,
            ...(isDragging ? { position: 'relative', zIndex: 9999 } : {}),
        };

        const memoizedValue = useMemo<SortableListItemContextProps>(
            () => ({ setActivatorNodeRef, listeners, attributes }),
            [setActivatorNodeRef, listeners, attributes],
        );

        return (
            <SortableListItemContext.Provider value={memoizedValue}>
                <List.Item {...rest} ref={setNodeRef} style={listStyle} />
            </SortableListItemContext.Provider>
        );
    };

    const DragHandle = () => {
        const { setActivatorNodeRef, listeners, attributes } = useContext(SortableListItemContext);
        return (
            <Button
                type="text"
                size="small"
                icon={<HolderOutlined />}
                style={{ cursor: 'move', color: '#999' }}
                ref={setActivatorNodeRef}
                {...attributes}
                {...listeners}
            />
        );
    }

    const handleAddStep = () => {
        const newStep = {
            id: crypto.randomUUID(),
            type: 'click',
            selector: '',
            value: ''
        };
        setRecordedContract([...recordedContract, newStep]);
        setHasUnsavedChanges(true);
    };

    const handleStepChange = (id: string, field: string, value: string) => {
        const newSteps = [...recordedContract];
        const index = newSteps.findIndex((i) => i.id === id);
        newSteps[index][field] = value;
        setRecordedContract(newSteps);
        setHasUnsavedChanges(true);
    };

    const handleDeleteStep = (id: string) => {
        const newSteps = [...recordedContract];
        const index = newSteps.findIndex((i) => i.id === id);
        newSteps.splice(index, 1);
        setRecordedContract(newSteps);
        setHasUnsavedChanges(true);
    };

    const getRecordButtonStyle = () => {
        if (isRecording) {
            return { backgroundColor: '#ff4d4f', borderColor: '#ff4d4f', color: 'white' };
        }
        if (connectionStatus === 'connected') {
            return { backgroundColor: '#52c41a', borderColor: '#52c41a', color: 'white' };
        }
        return { backgroundColor: '#d9d9d9', borderColor: '#d9d9d9', color: '#999' };
    };

    const getConnectButtonStyle = () => {
        if (connectionStatus === 'connected') {
            return { color: '#52c41a', margin: '5px 0 0 0', padding: 0, cursor: 'pointer' };
        }
        return { color: '#ff4d4f', margin: '5px 0 0 0', padding: 0, cursor: 'pointer' };
    };

    return (
        <Layout>
            <Header style={{ backgroundColor: 'white', padding: '0 10px', height: '50px', borderBottom: '1px solid #f0f0f0' }}>
                <Flex align="center" justify="space-between">
                    <Flex justify="flex-start" style={{ marginTop: '10px' }}>
                        <Tooltip title="Back to Home">
                            <motion.div
                                whileHover={{ scale: 1.2, x: -3 }}
                                transition={{ type: "spring", stiffness: 400, damping: 17 }}
                                style={{ display: 'inline-flex', cursor: 'pointer' }}
                            >
                                <ArrowLeftFromLine style={{ marginRight: '10px', marginLeft: '5px', color: '#ff4d4f' }} onClick={() => router.back()} />
                            </motion.div>
                        </Tooltip>
                        <Text>{caseName}</Text>
                        <Button type="text" size="small" icon={<EditOutlined />} onClick={() => setShowUpdateCaseNameModal(true)} style={{ marginLeft: '5px' }} />
                    </Flex>
                    <Flex justify="flex-end" gap={8} style={{ marginTop: '10px', marginRight: '15px' }}>
                        <Button icon={<FileTextOutlined />} onClick={handleViewReport}>View Report</Button>
                        <Button
                            icon={<VideoCameraOutlined />}
                            onClick={handleRecordClick}
                            disabled={isRecording || isRunning}
                            style={getRecordButtonStyle()}
                        >
                            {isRecording ? "Recording..." : "Record"}
                        </Button>
                        <Siren size={20} style={getConnectButtonStyle()} onClick={handleSirenClick} />
                        <Button
                            icon={<PlayCircleOutlined />}
                            onClick={handleRun}
                            loading={isRunning}
                            disabled={isRunning || isRecording}
                        >
                            {isRunning ? "Running..." : "Run"}
                        </Button>
                        <Button icon={<Code size={14} />} onClick={handleViewCode} style={{ display: 'flex', alignItems: 'center', gap: 4 }}>View Code</Button>
                        <Button
                            type='primary'
                            onClick={handleSave}
                            danger={hasUnsavedChanges}
                        >
                            Save
                        </Button>
                    </Flex>
                </Flex>
            </Header>
            <Content style={{ padding: '15px', overflowY: 'auto' }}>
                <div style={{ minHeight: 360, height: 'calc(100vh - 80px)', overflow: 'auto' }}>
                    {recordedContract && recordedContract.length > 0 ? (
                        <DndContext
                            modifiers={[restrictToVerticalAxis]}
                            onDragEnd={handleDragEnd}
                            id="list-drag-sorting-handler"
                        >
                            <SortableContext items={recordedContract.map((item) => item.id)} strategy={verticalListSortingStrategy}>
                                <List
                                    header={<div>Case Steps ({recordedContract.length})</div>}
                                    footer={<Button type="dashed" onClick={handleAddStep} block icon={<PlusOutlined />}>Add Step</Button>}
                                    bordered
                                    dataSource={recordedContract}
                                    renderItem={(item) => (
                                        <SortableListItem key={item.id} itemKey={item.id}>
                                            <div style={{ display: 'flex', gap: 16, width: '100%', alignItems: 'center' }}>
                                                <DragHandle />
                                                <Select
                                                    value={item.type}
                                                    onChange={(value) => handleStepChange(item.id, 'type', value)}
                                                    style={{ width: 100, fontWeight: 'bold' }}
                                                >
                                                    <Option value="click">CLICK</Option>
                                                    <Option value="fill">FILL</Option>
                                                    <Option value="visit">VISIT</Option>
                                                    <Option value="wait">WAIT</Option>
                                                    <Option value="check">CHECK</Option>
                                                    +<Option value="select">SELECT</Option>
                                                </Select>
                                                <Input
                                                    value={item.selector}
                                                    onChange={(e) => handleStepChange(item.id, 'selector', e.target.value)}
                                                    style={{ flex: 1 }}
                                                    placeholder="Selector"
                                                />
                                                <Input
                                                    value={item.value}
                                                    onChange={(e) => handleStepChange(item.id, 'value', e.target.value)}
                                                    style={{ flex: 1 }}
                                                    placeholder="Value (if type/click)"
                                                />
                                                <Button danger icon={<DeleteOutlined />} onClick={() => handleDeleteStep(item.id)} />
                                            </div>
                                        </SortableListItem>
                                    )}
                                />
                            </SortableContext>
                        </DndContext>
                    ) : (
                        <Empty description="No recorded steps yet. Click Record to start.">
                            <Button type="primary" onClick={handleRecordClick} icon={<VideoCameraOutlined />}>
                                Start Recording
                            </Button>
                        </Empty>
                    )}
                </div>
            </Content>

            {/* Update Name Modal */}
            <Modal open={showUpdateCaseNameModal}
                title="Update Case Name"
                onOk={handleUpdateName}
                onCancel={() => setShowUpdateCaseNameModal(false)}
            >
                <Input style={{ margin: '15px 0' }} value={caseName} onChange={(e) => setCaseName(e.target.value)} />
            </Modal>

            {/* Bind Bridge Modal */}
            <Modal open={showBindModal}
                title="Connect to Bridge"
                onOk={handleBindBridge}
                onCancel={() => setShowBindModal(false)}
                okText="Connect"
            >
                <Input
                    style={{ margin: '15px 0' }}
                    value={bridgeUuidInput}
                    onChange={(e) => setBridgeUuidInput(e.target.value)}
                    placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                />
            </Modal>

            {/* Record Modal */}
            <Modal open={showRecordModal}
                title="Start Recording"
                onOk={handleStartRecording}
                onCancel={() => setShowRecordModal(false)}
            >
                <Typography.Text>Enter the URL to record:</Typography.Text>
                <Input
                    style={{ margin: '15px 0' }}
                    value={targetUrl}
                    onChange={(e) => setTargetUrl(e.target.value)}
                    placeholder="https://example.com"
                />
            </Modal>

            {/* Code Drawer */}
            <Drawer
                title="Playwright Code"
                placement="right"
                width={700}
                onClose={() => setShowCodeDrawer(false)}
                open={showCodeDrawer}
            >
                {loadingCode ? (
                    <div style={{ textAlign: 'center', padding: '50px' }}>
                        <Spin size="large" />
                    </div>
                ) : (
                    <pre style={{
                        backgroundColor: '#1e1e1e',
                        color: '#d4d4d4',
                        padding: '16px',
                        borderRadius: '8px',
                        overflow: 'auto',
                        fontSize: '13px',
                        lineHeight: '1.5'
                    }}>
                        {playwrightCode}
                    </pre>
                )}
            </Drawer>

            {messageContextHolder}
        </Layout>
    );
}