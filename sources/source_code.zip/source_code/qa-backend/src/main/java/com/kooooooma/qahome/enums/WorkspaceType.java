package com.kooooooma.qahome.enums;

public enum WorkspaceType {
    STANDARD,
    ORCHESTRATION
}
