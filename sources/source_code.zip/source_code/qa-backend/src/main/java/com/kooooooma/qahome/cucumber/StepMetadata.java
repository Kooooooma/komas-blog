package com.kooooooma.qahome.cucumber;

import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class StepMetadata {
    private String key;
    private String name;
    private String category;
    private String pattern;
    private String keyword; // Gherkin keyword: Given, When, Then, And
    private List<StepParameter> parameters;

    @Data
    @Builder
    public static class StepParameter {
        private String name;
        private String type; // STRING, INT, BOOLEAN
        private String defaultValue;
    }
}

