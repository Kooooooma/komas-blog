package com.kooooooma.qahome.dto;

import lombok.Data;

import java.util.Map;

@Data
public class NodeDTO {
    private String id;
    private String type;
    private Map<String, String> data;
}
