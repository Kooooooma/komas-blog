package com.kooooooma.qahome.cucumber.steps;

import com.kooooooma.qahome.annotation.ActionStep;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class AgentSteps {
    @ActionStep(name = "JMS Agent", key = "jmsAgent", category = "Agent")
    @Given("Inject {string} with JMS Agent")
    public void jmsAgent(String service) {
        log.info("[Mock] Inject {} with JMS Agent", service);
    }
}
