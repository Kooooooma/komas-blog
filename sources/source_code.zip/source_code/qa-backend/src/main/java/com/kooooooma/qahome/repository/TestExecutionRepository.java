package com.kooooooma.qahome.repository;

import com.kooooooma.qahome.entity.TestExecution;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public interface TestExecutionRepository extends JpaRepository<TestExecution, UUID> {
    List<TestExecution> findAllById(UUID id);
}
