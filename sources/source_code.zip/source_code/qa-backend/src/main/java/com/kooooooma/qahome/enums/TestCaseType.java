package com.kooooooma.qahome.enums;

public enum TestCaseType {
    CUCUMBER,
    CYPRESS
}
