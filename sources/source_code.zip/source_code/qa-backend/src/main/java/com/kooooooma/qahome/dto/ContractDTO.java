package com.kooooooma.qahome.dto;

import lombok.Data;
import java.util.List;

@Data
public class ContractDTO {
    private List<NodeDTO> nodes;
    private List<EdgeDTO> edges;
}
