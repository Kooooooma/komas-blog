package com.kooooooma.qahome.dto;

import lombok.Data;
import java.util.List;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Data
public class ContractDto {
    private List<NodeDto> nodes;
    private List<EdgeDto> edges;
}
