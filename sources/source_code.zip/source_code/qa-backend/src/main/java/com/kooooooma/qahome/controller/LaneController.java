package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.entity.Lane;
import com.kooooooma.qahome.service.LaneService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@RestController
@RequestMapping("/api/lane")
public class LaneController {

    @Autowired
    private LaneService laneService;

    @PostMapping
    public Lane createLane(@RequestBody Lane lane) {
        return laneService.createLane(lane);
    }

    @PutMapping("/order")
    public void updateLaneOrder(@RequestBody Map<String, Object> body) {
        // Expecting { "laneId": "...", "caseIds": ["...", "..."] }
        UUID laneId = UUID.fromString((String) body.get("laneId"));
        List<String> caseIdStrings = (List<String>) body.get("caseIds");
        List<UUID> caseIds = caseIdStrings.stream().map(UUID::fromString).toList();
        laneService.updateLaneOrder(laneId, caseIds);
    }

    @PutMapping("/{id}/name")
    public Lane updateLaneName(@PathVariable UUID id, @RequestBody Map<String, String> body) {
        return laneService.updateLaneName(id, body.get("name"));
    }

    @DeleteMapping("/{id}")
    public void deleteLane(@PathVariable UUID id) {
        laneService.deleteLane(id);
    }

    @GetMapping("/workspace/{workspaceId}")
    public List<Map<String, Object>> getLanesByWorkspace(@PathVariable UUID workspaceId) {
        return laneService.getLanesByWorkspace(workspaceId);
    }

    @PostMapping("/{laneId}/case/{caseId}")
    public void addCaseToLane(@PathVariable UUID laneId, @PathVariable UUID caseId) {
        laneService.addCaseToLane(laneId, caseId);
    }

    @DeleteMapping("/{laneId}/case/{caseId}")
    public void removeCaseFromLane(@PathVariable UUID laneId, @PathVariable UUID caseId) {
        laneService.removeCaseFromLane(laneId, caseId);
    }
}
