package com.kooooooma.qahome;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QaHomeApplication {

	public static void main(String[] args) {
		SpringApplication.run(QaHomeApplication.class, args);
	}

}
