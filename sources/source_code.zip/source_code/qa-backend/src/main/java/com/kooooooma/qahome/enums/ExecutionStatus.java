package com.kooooooma.qahome.enums;

public enum ExecutionStatus {
    NA,
    PENDING,
    RUNNING,
    SUCCESS,
    FAILURE
}
