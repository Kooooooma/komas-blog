package com.kooooooma.qahome.config;

import jakarta.persistence.Column;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.metamodel.EntityType;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

import javax.sql.DataSource;
import java.lang.reflect.Field;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

@Configuration
@Slf4j
public class DbSchemaSyncConfig implements CommandLineRunner {

    @Autowired
    private DataSource dataSource;

    @Autowired
    private EntityManagerFactory entityManagerFactory;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) throws Exception {
        log.info("Starting Database Schema Synchronization...");
        Set<EntityType<?>> entities = entityManagerFactory.getMetamodel().getEntities();

        for (EntityType<?> entityType : entities) {
            Class<?> javaType = entityType.getJavaType();
            syncEntityTable(javaType);
        }
        log.info("Database Schema Synchronization Completed.");
    }

    private void syncEntityTable(Class<?> entityClass) throws SQLException {
        String tableName = getTableName(entityClass);
        Map<String, String> entityColumns = getEntityColumns(entityClass);

        try (var connection = dataSource.getConnection()) {
            DatabaseMetaData metaData = connection.getMetaData();
            ResultSet tables = metaData.getTables(null, null, tableName.toUpperCase(), null); // H2 default upper case

            if (!tables.next()) {
                createTable(tableName, entityColumns);
            } else {
                syncColumns(tableName, entityColumns, metaData);
            }
        }
    }

    private void createTable(String tableName, Map<String, String> entityColumns) {
        log.info("Creating table: {}", tableName);
        StringBuilder sql = new StringBuilder("CREATE TABLE " + tableName + " (");

        List<String> definitions = new ArrayList<>();
        // Ensure ID is first or handled, currently just adding all
        // Ideally we should identify Primary Key, but for simplicity we rely on
        // entityColumns definition
        // Note: verify ID definition for PK constraints if possible, but basic creation
        // first.

        // Refined approach: We need to know which one is PK to add PRIMARY KEY
        // constraint
        // For now, let's just create columns. Functional primary key added if @Id found
        // in mapping.

        entityColumns.forEach((colName, colType) -> {
            definitions.add(colName + " " + colType);
        });

        sql.append(String.join(", ", definitions));
        sql.append(")");

        log.info("Executing SQL: {}", sql);
        jdbcTemplate.execute(sql.toString());
    }

    private void syncColumns(String tableName, Map<String, String> entityColumns, DatabaseMetaData metaData)
            throws SQLException {
        log.info("Syncing table: {}", tableName);
        Set<String> dbColumns = new HashSet<>();
        ResultSet columns = metaData.getColumns(null, null, tableName.toUpperCase(), null);

        while (columns.next()) {
            dbColumns.add(columns.getString("COLUMN_NAME").toLowerCase());
        }

        // Add missing columns
        for (Map.Entry<String, String> entry : entityColumns.entrySet()) {
            String colName = entry.getKey();
            String colDef = entry.getValue();
            if (!dbColumns.contains(colName.toLowerCase())) {
                log.info("Adding missing column: {}.{}", tableName, colName);
                jdbcTemplate.execute("ALTER TABLE " + tableName + " ADD COLUMN " + colName + " " + colDef);
            }
        }

        // Drop extra columns
        for (String dbCol : dbColumns) {
            if (!entityColumns.containsKey(dbCol.toLowerCase()) && !entityColumns.containsKey(dbCol.toUpperCase())) { // Case
                // insensitive
                // check
                // Double check if it matches any entity column (ignoring case)
                boolean existsInEntity = entityColumns.keySet().stream().anyMatch(k -> k.equalsIgnoreCase(dbCol));
                if (!existsInEntity) {
                    log.info("Dropping extra column: {}.{}", tableName, dbCol);
                    jdbcTemplate.execute("ALTER TABLE " + tableName + " DROP COLUMN " + dbCol);
                }
            }
        }
    }

    private String getTableName(Class<?> entityClass) {
        Table table = entityClass.getAnnotation(Table.class);
        if (table != null && !table.name().isEmpty()) {
            return table.name();
        }
        return camelToSnake(entityClass.getSimpleName());
    }

    private Map<String, String> getEntityColumns(Class<?> entityClass) {
        Map<String, String> columns = new LinkedHashMap<>();

        // Recursively get fields for mapped superclasses if any (simplification: just
        // declared fields for now)
        // Spring Data JPA entities often flat, but loop hierarchy if needed.
        // For this task, assuming flat or simple inheritance.

        for (Field field : entityClass.getDeclaredFields()) {
            if (field.isAnnotationPresent(jakarta.persistence.Transient.class)) {
                continue;
            }
            // Skip static fields
            if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                continue;
            }

            String colName = getColumnName(field);
            String colType = getSqlType(field);

            if (field.isAnnotationPresent(Id.class)) {
                colType += " PRIMARY KEY";
            }

            columns.put(colName, colType);
        }
        return columns;
    }

    private String getColumnName(Field field) {
        Column column = field.getAnnotation(Column.class);
        if (column != null && !column.name().isEmpty()) {
            return column.name();
        }
        return camelToSnake(field.getName());
    }

    private String getSqlType(Field field) {
        Class<?> type = field.getType();

        if (field.isAnnotationPresent(jakarta.persistence.Lob.class)) {
            return "CLOB";
        }

        if (type == String.class) {
            return "VARCHAR(255)";
        } else if (type == java.util.UUID.class) {
            return "UUID";
        } else if (type == java.time.LocalDateTime.class) {
            return "TIMESTAMP";
        } else if (type == Boolean.class || type == boolean.class) {
            return "BOOLEAN";
        } else if (type == Integer.class || type == int.class) {
            return "INT";
        } else if (type == Long.class || type == long.class) {
            return "BIGINT";
        } else if (type.isEnum()) {
            return "VARCHAR(255)";
        }

        // Default fallback
        return "VARCHAR(255)";
    }

    private String camelToSnake(String str) {
        return str.replaceAll("([a-z])([A-Z]+)", "$1_$2").toLowerCase();
    }
}
