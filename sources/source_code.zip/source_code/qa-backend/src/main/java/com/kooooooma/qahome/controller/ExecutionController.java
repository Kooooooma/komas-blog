package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.entity.TestExecution;
import com.kooooooma.qahome.service.ExecutionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@RestController
@RequestMapping("/api/execution")
public class ExecutionController {

    @Autowired
    private ExecutionService executionService;

    @PostMapping("/run/{testCaseId}")
    public TestExecution run(@PathVariable UUID testCaseId, @RequestHeader(value = "x-employee-id") String employeeId) {
        return executionService.runTestCase(testCaseId, employeeId);
    }

    @GetMapping("/report/{executionId}")
    public String report(@PathVariable UUID executionId) throws IOException {
        return executionService.getExecutionReport(executionId);
    }

}
