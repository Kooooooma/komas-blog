package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.dto.ContractDTO;
import com.kooooooma.qahome.entity.TestExecution;
import com.kooooooma.qahome.service.ExecutionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/execution")
public class ExecutionController {

    @Autowired
    private ExecutionService executionService;

    @PostMapping("/preview")
    public String preview(@RequestBody ContractDTO contract) {
        return executionService.previewCode(contract);
    }

    @PostMapping("/run/{testCaseId}")
    public TestExecution run(@PathVariable UUID testCaseId) {
        return executionService.runTestCase(testCaseId);
    }

    @GetMapping("/report/{executionId}")
    public ResponseEntity<String> getReportContent(@PathVariable UUID executionId) {
        String htmlContent = executionService.readReportContent(executionId);
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_HTML)
                .body(htmlContent);
    }

}
