package com.kooooooma.qahome.dto;

import lombok.Builder;
import lombok.Data;

public class AuthDto {
    @Data
    public static class LoginRequest {
        private String employeeId;
    }

    @Builder
    @Data
    public static class AuthResponse {
        private String employeeId;
    }
}
