package com.kooooooma.qahome.cucumber;

import com.kooooooma.qahome.QaHomeApplication;
import io.cucumber.spring.CucumberContextConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.ComponentScan;

@CucumberContextConfiguration
@SpringBootTest(
        classes = QaHomeApplication.class,
        properties = {"spring.application.admin.enabled=false"}
)
@ComponentScan(basePackages = "com.kooooooma.qahome")
public class CucumberSpringConfiguration {
}
