package com.kooooooma.qahome.service;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kooooooma.qahome.cucumber.StepMetadata;
import com.kooooooma.qahome.cucumber.service.StepRegistryService;
import com.kooooooma.qahome.dto.ContractDTO;
import com.kooooooma.qahome.dto.EdgeDTO;
import com.kooooooma.qahome.dto.NodeDTO;
import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.entity.TestExecution;
import com.kooooooma.qahome.enums.ExecutionStatus;
import com.kooooooma.qahome.repository.TestCaseRepository;
import com.kooooooma.qahome.repository.TestExecutionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Service
public class ExecutionService {
    @Autowired
    private TestCaseRepository testCaseRepository;

    @Autowired
    private TestExecutionRepository testExecutionRepository;

    @Autowired
    private StepRegistryService stepRegistryService;

    @Value("${report.path}")
    private String reportBasePath;

    public String previewCode(ContractDTO contract) {
        List<List<NodeDTO>> scenarioGroups = processContract(contract);
        return generateGherkin(scenarioGroups);
    }

    public TestExecution runTestCase(UUID testCaseId) {
        TestCase testCase = testCaseRepository.findById(testCaseId)
                .orElseThrow(() -> new RuntimeException("TestCase not found"));

        if (testCase.getContract() == null) {
            throw new RuntimeException("TestCase has no content to run");
        }

        // Parse contract JSON
        ContractDTO contract;
        try {
            ObjectMapper mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES,
                    false);
            contract = mapper.readValue(testCase.getContract(), ContractDTO.class);
        } catch (Exception e) {
            log.error("Failed to read contract from test case {}", testCaseId, e);
            throw new RuntimeException("Failed to parse test case contract", e);
        }

        List<List<NodeDTO>> scenarioGroups = processContract(contract);
        String gherkin = generateGherkin(scenarioGroups);

        // Create execution record
        TestExecution execution = TestExecution.builder()
                .status(ExecutionStatus.RUNNING)
                .startTime(LocalDateTime.now())
                .endTime(LocalDateTime.now()) // Temporary
                .testCaseId(testCaseId)
                .build();
        execution = testExecutionRepository.save(execution);

        // Setup directories
        String executionId = execution.getId().toString();
        Path executionDir = Paths.get(reportBasePath, executionId);
        try {
            Files.createDirectories(executionDir);
            Files.writeString(executionDir.resolve(executionId + ".feature"), gherkin);
        } catch (IOException e) {
            execution.setStatus(ExecutionStatus.FAILURE);
            execution.setLogs("Failed to setup execution directory: " + e.getMessage());
            execution.setEndTime(LocalDateTime.now());
            testExecutionRepository.save(execution);
            log.error("Failed to setup execution directory, testCaseId {}, executionId {}", testCaseId, executionId, e);
            throw new RuntimeException("Failed to setup execution environment", e);
        }

        // Run Cucumber
        // Capture output
        ByteArrayOutputStream outContent = new ByteArrayOutputStream();
        PrintStream originalOut = System.out;
        System.setOut(new PrintStream(outContent));

        try {
            String[] argv = new String[] {
                    "-g", "com.kooooooma.qahome.cucumber",
                    "-p", "html:" + executionDir.resolve("report.html").toString(),
                    "-p", "json:" + executionDir.resolve("report.json").toString(),
                    executionDir.resolve(executionId + ".feature").toString()
            };

            byte exitStatus = io.cucumber.core.cli.Main.run(argv, Thread.currentThread().getContextClassLoader());

            execution.setStatus(exitStatus == 0 ? ExecutionStatus.SUCCESS : ExecutionStatus.FAILURE);
        } catch (Exception e) {
            execution.setStatus(ExecutionStatus.FAILURE);
            System.out.println("Execution Error: " + e.getMessage());
        } finally {
            System.setOut(originalOut);
            execution.setLogs(outContent.toString());
            execution.setEndTime(LocalDateTime.now());
            execution.setReportPath(executionDir.resolve("report.html").toString());
            testExecutionRepository.save(execution);

            // Update last execution ID on test case
            testCase.setLastExecutionId(execution.getId());
            testCaseRepository.save(testCase);
            log.info("Finished run test case {}, executionId {}", testCaseId, executionId);
        }
        return execution;
    }

    private List<List<NodeDTO>> processContract(ContractDTO contract) {
        List<NodeDTO> nodes = contract.getNodes();
        if (nodes == null) {
            return new ArrayList<>();
        }

        List<EdgeDTO> edges = contract.getEdges();
        if (edges == null) {
            edges = new ArrayList<>();
        }

        // Build adjacency list for undirected graph (grouping)
        // and incoming edge count for directed graph (sorting)
        Map<String, List<String>> adjacency = new HashMap<>();
        Map<String, NodeDTO> nodeMap = new HashMap<>();

        for (NodeDTO node : nodes) {
            adjacency.put(node.getId(), new ArrayList<>());
            nodeMap.put(node.getId(), node);
        }

        for (EdgeDTO edge : edges) {
            if (adjacency.containsKey(edge.getSource())) {
                adjacency.get(edge.getSource()).add(edge.getTarget());
            }
            if (adjacency.containsKey(edge.getTarget())) {
                adjacency.get(edge.getTarget()).add(edge.getSource());
            }
        }

        // Find connected components (Scenarios)
        Set<String> visited = new HashSet<>();
        List<List<NodeDTO>> groups = new ArrayList<>();

        for (NodeDTO node : nodes) {
            if (visited.contains(node.getId())) {
                continue;
            }

            List<String> groupIds = new ArrayList<>();
            Queue<String> queue = new LinkedList<>();
            queue.add(node.getId());

            while (!queue.isEmpty()) {
                String current = queue.poll();
                if (visited.contains(current)) {
                    continue;
                }
                visited.add(current);
                groupIds.add(current);

                for (String neighbor : adjacency.get(current)) {
                    if (!visited.contains(neighbor)) {
                        queue.add(neighbor);
                    }
                }
            }

            groups.add(sortByEdgeOrder(groupIds, edges, nodeMap));
        }

        return groups;
    }

    private List<NodeDTO> sortByEdgeOrder(List<String> groupIds, List<EdgeDTO> edges, Map<String, NodeDTO> nodeMap) {
        if (groupIds.size() <= 1) {
            return groupIds.stream().map(nodeMap::get).collect(Collectors.toList());
        }

        Set<String> groupSet = new HashSet<>(groupIds);
        Set<String> hasIncoming = new HashSet<>();

        // Identify nodes with incoming edges *within this group*
        for (EdgeDTO edge : edges) {
            if (groupSet.contains(edge.getSource()) && groupSet.contains(edge.getTarget())) {
                hasIncoming.add(edge.getTarget());
            }
        }

        // Roots are nodes with no incoming edges from within the group
        List<String> roots = groupIds.stream()
                .filter(id -> !hasIncoming.contains(id))
                .collect(Collectors.toList());

        // If no roots found (cycle), fallback to random start or handling (for now
        // simple fallback)
        if (roots.isEmpty()) {
            roots.add(groupIds.get(0));
        }

        List<NodeDTO> sorted = new ArrayList<>();
        Set<String> visited = new HashSet<>();
        Queue<String> queue = new LinkedList<>(roots);

        // Topological-ish sort using BFS following edges
        while (!queue.isEmpty()) {
            String current = queue.poll();
            if (visited.contains(current)) {
                continue;
            }
            visited.add(current);
            sorted.add(nodeMap.get(current));

            for (EdgeDTO edge : edges) {
                if (edge.getSource().equals(current) && groupSet.contains(edge.getTarget())
                        && !visited.contains(edge.getTarget())) {
                    queue.add(edge.getTarget());
                }
            }
        }

        // Add any disconnected/missed nodes (safety net)
        if (sorted.size() < groupIds.size()) {
            for (String id : groupIds) {
                if (!visited.contains(id)) {
                    sorted.add(nodeMap.get(id));
                }
            }
        }

        return sorted;
    }

    public String generateGherkin(List<List<NodeDTO>> scenarioGroups) {
        StringBuilder gherkin = new StringBuilder();
        gherkin.append("Feature: Preview Feature\n\n");

        int scenarioCount = 1;
        for (List<NodeDTO> group : scenarioGroups) {
            gherkin.append("  Scenario: Preview Scenario ").append(scenarioCount++).append("\n");

            for (NodeDTO node : group) {
                StepMetadata metadata = stepRegistryService.getStepByKey(node.getType());
                if (metadata != null) {
                    String stepString = generateStepString(metadata, node.getData());
                    gherkin.append("    ").append(metadata.getKeyword()).append(" ").append(stepString).append("\n");
                } else {
                    gherkin.append("    # Unknown step for node type: ").append(node.getType()).append("\n");
                }
            }
            gherkin.append("\n");
        }

        return gherkin.toString();
    }

    private String generateStepString(StepMetadata metadata, Map<String, String> data) {
        String pattern = metadata.getPattern();
        if (data != null && data.containsKey("inputValue")) {
            String value = data.get("inputValue");
            if (value != null) {
                Pattern p = Pattern.compile("\\{.*?\\}");
                Matcher m = p.matcher(pattern);
                if (m.find()) {
                    return m.replaceFirst("\"" + value + "\"");
                }
            }
        }
        return pattern;
    }

    public String readReportContent(UUID executionId) {
        TestExecution execution = testExecutionRepository.findById(executionId)
                .orElseThrow(() -> new RuntimeException("Execution not found"));

        String reportPath = execution.getReportPath();
        if (reportPath == null || reportPath.isEmpty()) {
            throw new RuntimeException("Report path not available for this execution");
        }

        try {
            return Files.readString(Path.of(reportPath));
        } catch (IOException e) {
            log.error("Failed to read report file: {}", reportPath, e);
            throw new RuntimeException("Failed to read report file", e);
        }
    }
}
