package com.kooooooma.qahome.service;

import com.kooooooma.qahome.entity.Lane;
import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.entity.Workspace;
import com.kooooooma.qahome.enums.WorkspaceType;
import com.kooooooma.qahome.repository.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Slf4j
@Service
public class WorkspaceService {
    @Autowired
    private WorkspaceRepository workspaceRepository;

    @Autowired
    private LaneRepository laneRepository;

    @Autowired
    private TestCaseRepository testCaseRepository;

    @Autowired
    private TestExecutionRepository testExecutionRepository;

    @Autowired
    private LaneCaseMappingRepository laneCaseMappingRepository;

    @Autowired
    private TestCaseService testCaseService;

    @Autowired
    private LaneService laneService;

    public Workspace createWorkspace(Workspace workspace) {
        workspace.setCreateTime(LocalDateTime.now());
        if (workspace.getType() == null) {
            workspace.setType(WorkspaceType.STANDARD);
        }
        return workspaceRepository.save(workspace);
    }

    @Transactional
    public Workspace updateWorkspaceName(UUID id, String name) {
        Workspace workspace = workspaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Workspace not found: " + id));
        workspace.setName(name);
        return workspaceRepository.save(workspace);
    }

    @Transactional
    public void deleteWorkspace(UUID id, String employeeId) {
        long workspaceAmount = workspaceRepository.countByEmployeeId(employeeId);
        if (workspaceAmount <= 1) {
            throw new RuntimeException("There is only one workspace, cannot delete");
        }

        List<TestCase> allCases = testCaseRepository.findByWorkspaceId(id);
        for (TestCase tc : allCases) {
            try {
                testCaseService.deleteTestCase(tc.getId());
            } catch (Exception e) {
                // ignore error
            }
        }

        List<Lane> lanes = laneRepository.findByWorkspaceIdOrderByCreateTimeDesc(id);
        for (Lane lane : lanes) {
            try {
                laneService.deleteLane(lane.getId());
            } catch (Exception e) {
                // ignore error
            }
        }

        workspaceRepository.deleteById(id);
    }

    public List<Workspace> getWorkspacesByEmployee(String employeeId) {
        return workspaceRepository.findByEmployeeId(employeeId);
    }
}
