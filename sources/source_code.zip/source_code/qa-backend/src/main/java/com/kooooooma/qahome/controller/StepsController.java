package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.cucumber.StepMetadata;
import com.kooooooma.qahome.cucumber.service.StepRegistryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/steps")
public class StepsController {
    @Autowired
    private StepRegistryService stepRegistryService;

    @GetMapping("/by-category")
    public Map<String, List<StepMetadata>> getStepsByCategory() {
        return stepRegistryService.getStepsByCategory();
    }
}
