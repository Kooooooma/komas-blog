package com.kooooooma.qahome.service;

import com.kooooooma.qahome.entity.TestCase;
import com.kooooooma.qahome.repository.LaneCaseMappingRepository;
import com.kooooooma.qahome.repository.TestCaseRepository;
import com.kooooooma.qahome.repository.TestExecutionRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Service
public class TestCaseService {

    @Autowired
    private TestCaseRepository testCaseRepository;

    @Autowired
    private TestExecutionRepository testExecutionRepository;

    @Autowired
    private LaneCaseMappingRepository laneCaseMappingRepository;

    public List<Map<String, Object>> getTestCasesByWorkspace(UUID workspaceId) {
        List<TestCase> testCases = testCaseRepository.findByWorkspaceId(workspaceId);
        return testCases.stream().map(this::enrichTestCaseWithExecution).collect(Collectors.toList());
    }

    public Map<String, Object> getTestCaseDetail(UUID id) {
        TestCase testCase = testCaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("TestCase not found: " + id));
        return enrichTestCaseWithExecution(testCase);
    }

    private Map<String, Object> enrichTestCaseWithExecution(TestCase testCase) {
        Map<String, Object> result = new HashMap<>();
        result.put("case", testCase);
        if (testCase.getLastExecutionId() != null) {
            testExecutionRepository.findById(testCase.getLastExecutionId())
                    .ifPresent(execution -> result.put("lastExecution", execution));
        }
        return result;
    }

    @Transactional
    public TestCase createTestCase(TestCase testCase) {
        testCase.setLastUpdateTime(LocalDateTime.now());
        return testCaseRepository.save(testCase);
    }

    @Transactional
    public TestCase updateTestCaseName(UUID id, String name) {
        TestCase testCase = testCaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("TestCase not found: " + id));
        testCase.setName(name);
        testCase.setLastUpdateTime(LocalDateTime.now());
        return testCaseRepository.save(testCase);
    }

    @Transactional
    public TestCase updateTestCase(TestCase testCaseUpdate) {
        TestCase testCase = testCaseRepository.findById(testCaseUpdate.getId())
                .orElseThrow(() -> new RuntimeException("TestCase not found: " + testCaseUpdate.getId()));

        testCase.setName(testCaseUpdate.getName());
        testCase.setContract(testCaseUpdate.getContract());
        testCase.setLastUpdateTime(LocalDateTime.now());
        return testCaseRepository.save(testCase);
    }

    @Transactional
    public void deleteTestCase(UUID id) {
        TestCase testCase = testCaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("TestCase not found: " + id));

        laneCaseMappingRepository.deleteByTestCaseId(id);

        if (testCase.getLastExecutionId() != null) {
            testExecutionRepository.deleteById(testCase.getLastExecutionId());
        }

        testCaseRepository.delete(testCase);
    }
}
