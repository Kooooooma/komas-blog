package com.kooooooma.qahome.repository;

import com.kooooooma.qahome.entity.Workspace;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public interface WorkspaceRepository extends JpaRepository<Workspace, UUID> {
    List<Workspace> findByEmployeeId(String employeeId);

    long countById(UUID id);

    long countByEmployeeId(String employeeId);
}
