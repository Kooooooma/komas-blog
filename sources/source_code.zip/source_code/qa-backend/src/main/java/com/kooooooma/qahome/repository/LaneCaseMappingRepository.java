package com.kooooooma.qahome.repository;

import com.kooooooma.qahome.entity.LaneCaseMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface LaneCaseMappingRepository extends JpaRepository<LaneCaseMapping, UUID> {
    List<LaneCaseMapping> findByLaneIdOrderByOrderIndex(UUID laneId);

    void deleteByLaneId(UUID laneId);

    void deleteByTestCaseId(UUID testCaseId);

    void deleteLaneCaseMappingByLaneIdAndTestCaseId(UUID laneId, UUID testCaseId);

    long countByLaneId(UUID laneId);
}
