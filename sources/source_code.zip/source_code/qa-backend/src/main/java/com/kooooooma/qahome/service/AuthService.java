package com.kooooooma.qahome.service;

import com.kooooooma.qahome.dto.AuthDto;
import com.kooooooma.qahome.entity.Employee;
import com.kooooooma.qahome.entity.Workspace;
import com.kooooooma.qahome.enums.WorkspaceType;
import com.kooooooma.qahome.repository.EmployeeRepository;
import com.kooooooma.qahome.repository.WorkspaceRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class AuthService {
    private final ConcurrentHashMap<String, String> employeeIdIpMapping = new ConcurrentHashMap<>();

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private WorkspaceRepository workspaceRepository;

    public Employee login(AuthDto.LoginRequest request, String clientIp) {
        String employeeId = request.getEmployeeId();

        Employee employee = employeeRepository.findByEmployeeId(employeeId)
                .orElseGet(() -> employeeRepository.save(
                        Employee.builder()
                                .employeeId(employeeId)
                                .lastLoginTime(LocalDateTime.now())
                                .build()
                ));

        log.info("EmployeeId {} login with IP: {}", request.getEmployeeId(), clientIp);
        if (employeeIdIpMapping.containsKey(employeeId)) {
            throw new RuntimeException("EmployeeId already login with IP: " + clientIp);
        }

        List<Workspace> workspaces = workspaceRepository.findByEmployeeId(employee.getEmployeeId());

        if (Objects.isNull(workspaces) || workspaces.isEmpty()) {
            workspaceRepository.save(Workspace.builder()
                    .employeeId(employee.getEmployeeId())
                    .createTime(LocalDateTime.now())
                    .name("Default Workspace")
                    .type(WorkspaceType.STANDARD)
                    .build());
        }

        employeeIdIpMapping.put(employeeId, clientIp);
        log.info("login - employeeIdIpMapping {}", employeeIdIpMapping);
        return employee;
    }

    public void logout(String employeeId) {
        employeeIdIpMapping.remove(employeeId);
        log.info("EmployeeId {} logout", employeeId);
        log.info("logout - employeeIdIpMapping {}", employeeIdIpMapping);
    }

    public String getEmployeeId(String clientIp) {
        log.info("getEmployeeId - employeeIdIpMapping {}", employeeIdIpMapping);
        for (Map.Entry<String, String> entry : employeeIdIpMapping.entrySet()) {
            String id = entry.getKey();
            String ip = entry.getValue();
            if (ip.equals(clientIp)) {
                return id;
            }
        }
        return "";
    }

    public String getClientIp(String employeeId) {
        log.info("getClientIp - employeeIdIpMapping {}", employeeIdIpMapping);
        return employeeIdIpMapping.get(employeeId);
    }
}
