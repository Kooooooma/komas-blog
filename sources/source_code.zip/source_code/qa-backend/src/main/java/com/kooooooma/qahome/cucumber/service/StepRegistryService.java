package com.kooooooma.qahome.cucumber.service;

import com.kooooooma.qahome.annotation.ActionStep;
import com.kooooooma.qahome.cucumber.StepMetadata;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.core.type.classreading.CachingMetadataReaderFactory;
import org.springframework.core.type.classreading.MetadataReader;
import org.springframework.core.type.classreading.MetadataReaderFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.ClassUtils;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
public class StepRegistryService {
    private final List<StepMetadata> registry = new ArrayList<>();

    @EventListener(ContextRefreshedEvent.class)
    public void scanForSteps() {
        this.registry.clear();

        try {
            ResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
            MetadataReaderFactory metadataReaderFactory = new CachingMetadataReaderFactory(resolver);

            // Packages to scan
            String[] packagesToScan = { "com.kooooooma.qahome.cucumber" };

            for (String basePackage : packagesToScan) {
                String packageSearchPath = ResourcePatternResolver.CLASSPATH_ALL_URL_PREFIX +
                        ClassUtils.convertClassNameToResourcePath(basePackage) + "/**/*.class";

                Resource[] resources = resolver.getResources(packageSearchPath);

                for (Resource resource : resources) {
                    if (resource.isReadable()) {
                        try {
                            MetadataReader metadataReader = metadataReaderFactory.getMetadataReader(resource);
                            String className = metadataReader.getClassMetadata().getClassName();
                            Class<?> clazz = Class.forName(className);
                            scanMethodsInClass(clazz);
                        } catch (Exception e) {
                            log.error("load steps error.", e);
                        }
                    }
                }
            }
        } catch (Exception e) {
            log.error("load steps error.", e);
        }
    }

    private void scanMethodsInClass(Class<?> clazz) {
        // Handle CGLIB proxies if any (though unlikely with direct class loading)
        if (clazz.getName().contains("$$")) {
            clazz = clazz.getSuperclass();
        }

        for (Method method : clazz.getDeclaredMethods()) {
            StepMetadata metadata = StepMetadata.builder().build();
            boolean hasStepAnnotation = false;

            if (method.isAnnotationPresent(ActionStep.class)) {
                ActionStep annotation = method.getAnnotation(ActionStep.class);

                List<StepMetadata.StepParameter> params = new ArrayList<>();
                for (Parameter p : method.getParameters()) {
                    params.add(StepMetadata.StepParameter.builder()
                            .name(p.getName())
                            .type(p.getType().getSimpleName().toUpperCase())
                            .build());
                }

                metadata.setKey(annotation.key());
                metadata.setName(annotation.name());
                metadata.setCategory(annotation.category());
                metadata.setParameters(params);
                hasStepAnnotation = true;
            }

            if (hasStepAnnotation && method.isAnnotationPresent(Given.class)) {
                Given givenAnnotation = method.getAnnotation(Given.class);
                metadata.setKeyword("Given");
                metadata.setPattern(givenAnnotation.value());
            }

            if (hasStepAnnotation) {
                registry.add(metadata);
            }
        }
    }

    public Map<String, List<StepMetadata>> getStepsByCategory() {
        return registry.stream()
                .filter(metadata -> metadata.getCategory() != null)
                .collect(Collectors.groupingBy(StepMetadata::getCategory));
    }

    public StepMetadata getStepByKey(String key) {
        return registry.stream()
                .filter(metadata -> metadata.getKey().equals(key))
                .findFirst()
                .orElse(null);
    }
}
