package com.kooooooma.qahome.cucumber.steps;
import com.kooooooma.qahome.annotation.ActionStep;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CtrlmSteps {
    @ActionStep(name = "Login to CtrlM", key = "loginToCtrlM", category = "CtrlM")
    @Given("I login to CtrlM Server {string}")
    public void loginToCtrlM(String server) {
        log.info("[Mock] Login to CtrlM Server: {}", server);
    }

    @ActionStep(name = "Order CtrlM Job", key = "orderCtrlMJob", category = "CtrlM")
    @Given("I order job {string}")
    public void orderJob(String job) {
        log.info("[Mock] Order Job: {}", job);
    }

    @ActionStep(name = "Reorder CtrlM Job", key = "reorderCtrlMJob", category = "CtrlM")
    @Given("I reorder job {string}")
    public void reOrderJob(String job) {
        log.info("[Mock] Reorder Job: {}", job);
    }

    @ActionStep(name = "Free CtrlM Job", key = "freeCtrlMJob", category = "CtrlM")
    @Given("I free job {string}")
    public void freeJob(String job) {
        log.info("[Mock] Free Job: {}", job);
    }
}
