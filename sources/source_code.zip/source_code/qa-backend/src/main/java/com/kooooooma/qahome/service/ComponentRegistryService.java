package com.kooooooma.qahome.service;

import com.kooooooma.qahome.dagengine.GraphTaskNode;
import com.kooooooma.qahome.dto.ComponentDto;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Slf4j
@Service
public class ComponentRegistryService {
    @Getter
    private Map<String, List<ComponentDto>> components = new HashMap<>();

    @Autowired
    private List<GraphTaskNode> graphTaskNodeList;

    @EventListener(ContextRefreshedEvent.class)
    public void scanComponents() {
        graphTaskNodeList.stream().forEach(graphTaskNode -> {
            List<ComponentDto> componentDtoList = new ArrayList<>();
            if (components.containsKey(graphTaskNode.category())) {
                componentDtoList = components.get(graphTaskNode.category());
            }
            componentDtoList.add(ComponentDto.builder()
                    .key(graphTaskNode.id())
                    .name(graphTaskNode.name())
                    .build());
            components.put(graphTaskNode.category(), componentDtoList);
        });
    }
}
