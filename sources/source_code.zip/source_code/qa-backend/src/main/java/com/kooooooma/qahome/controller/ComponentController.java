package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.dto.ComponentDto;
import com.kooooooma.qahome.service.ComponentRegistryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@RestController
@RequestMapping("/api/component")
public class ComponentController {
    @Autowired
    private ComponentRegistryService componentRegistryService;

    @GetMapping
    public Map<String, List<ComponentDto>> getComponents() {
        return componentRegistryService.getComponents();
    }
}
