package com.kooooooma.qahome.dagengine;

import com.kooooooma.qahome.dto.NodeDto;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public interface GraphTaskNode {
    default String id() {
        String simpleName = this.getClass().getSimpleName();
        return Character.toLowerCase(simpleName.charAt(0)) + simpleName.substring(1);
    }

    default String name() {
        return this.id();
    }

    String category();

    default boolean accept(String nodeId) {
        return this.id().equals(nodeId);
    }

    void execute(NodeDto node, GraphExecutionContext context);
}
