package com.kooooooma.qahome.enums;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public enum BridgeMessageType {
    PING,
    PONG,
    RECORD,
    RUN,
    RECORD_FINISHED,
    EXECUTION_FINISHED
}
