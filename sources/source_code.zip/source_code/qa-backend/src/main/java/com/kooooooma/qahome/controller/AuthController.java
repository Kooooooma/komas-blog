package com.kooooooma.qahome.controller;

import com.kooooooma.qahome.dto.AuthDto;
import com.kooooooma.qahome.entity.Employee;
import com.kooooooma.qahome.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public AuthDto.AuthResponse login(@RequestBody AuthDto.LoginRequest request) {
        Employee employee = authService.login(request);
        return AuthDto.AuthResponse.builder()
                .employeeId(employee.getEmployeeId())
                .build();
    }
}
