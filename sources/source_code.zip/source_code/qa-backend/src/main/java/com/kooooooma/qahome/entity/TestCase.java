package com.kooooooma.qahome.entity;

import com.kooooooma.qahome.enums.TestCaseType;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.UUID;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
@Builder
@Entity
@Table(name = "test_case")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TestCase {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private UUID workspaceId;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TestCaseType type;

    @Lob
    @Column(columnDefinition = "CLOB")
    private String contract; // JSON string representing the flow

    @Column
    private UUID lastExecutionId;

    @Column(nullable = false)
    private LocalDateTime lastUpdateTime;
}

