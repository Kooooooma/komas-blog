package com.kooooooma.qahome.entity;

import com.kooooooma.qahome.enums.ExecutionStatus;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.UUID;
import java.time.LocalDateTime;

@Builder
@Entity
@Table(name = "test_execution")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class TestExecution {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ExecutionStatus status;

    @Lob
    @Column(columnDefinition = "CLOB")
    private String logs; // Execution logs

    @Column(nullable = false)
    private LocalDateTime startTime;

    @Column(nullable = false)
    private LocalDateTime endTime;

    @Column(nullable = false)
    private UUID testCaseId;

    @Column
    private String reportPath;
}
