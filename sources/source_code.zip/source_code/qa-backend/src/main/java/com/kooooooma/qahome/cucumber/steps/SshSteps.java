package com.kooooooma.qahome.cucumber.steps;

import com.kooooooma.qahome.annotation.ActionStep;
import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;
@Slf4j
public class SshSteps {
    @ActionStep(name = "Connect to Server", key = "connectServer", category = "Network")
    @Given("I connect to server {string}")
    public void connectToServer(String target) {
        log.info("[Mock] Connecting to SSH Server: {}", target);
    }

    @ActionStep(name = "Execute Command", key = "executeCommand", category = "Network")
    @Given("I execute command {string}")
    public void executeCommand(String command) {
        log.info("[Mock] Executing Command: {}", command);
    }
}
