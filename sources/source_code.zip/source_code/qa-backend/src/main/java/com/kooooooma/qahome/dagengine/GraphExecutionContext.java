package com.kooooooma.qahome.dagengine;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * @author Koma
 * @email komaqiangqiang.zhang@sc.com
 */
public class GraphExecutionContext {
    public final ConcurrentHashMap<String, List<Object>> data = new ConcurrentHashMap<>();

    public void put(String key, Object value) {
        List<Object> values = new ArrayList<>();
        if (data.containsKey(key)) {
            values = data.get(key);
        }
        values.add(value);
        data.put(key, values);
    }

    public List<Object> get(String key) {
        return data.containsKey(key) ? data.get(key) : List.of();
    }
}
