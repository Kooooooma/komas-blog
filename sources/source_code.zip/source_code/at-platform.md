# 本地化全栈测试平台：技术实现指南
## 项目概述与目标
本项目旨在构建一个高度定制化的内部测试平台，提供可视化 UI 来配置 Cucumber (BDD) 和 Cypress (E2E) 用例，并将所有核心组件（Spring Boot, Next.js UI, Node.js Bridge）打包部署到 QA 本地环境，实现配置、执行、报告的闭环管理。

## 核心功能列表
用户和工作区管理： 基于工号的登录和用户专属工作区。

用例配置： 可视化（拖拽/点击）配置 Cucumber (Gherkin) 和 Cypress (Action Chain) 用例。

智能录制： 通过浏览器插件实现 Edge/Chrome 的跨域元素选择。

动态执行： 后端/Bridge 动态生成 .feature 或 .cy.js 文件，并通过命令行触发执行。

本地化部署： 所有组件打包并由 .sh / .bat 脚本一键启动。


## 技术栈与环境要求
领域,模块,技术/库,版本要求,备注
前端 UI,UI/配置中心,Next.js,15+ (App Router),高性能、全栈 Web 框架。
,UI 组件,Ant Design (AntD),适配next.js 15版本,企业级 UI 组件库，用于快速构建复杂的表单。
,状态管理,Zustand,最新,轻量级状态管理。
,可视化,React Flow,最新,用于步骤流、拖拽、编排可视化。
,数据请求,SWR,最新,统一管理数据缓存和请求。
后端服务,API/持久化,Spring Boot,3+ (Java 17+),核心 API 服务，本地化启动。
,数据库,H2 Database,最新,本地文件模式，实现零配置持久化。
,API 通信,Jackson,最新,JSON 序列化/反序列化。
,运行时集成,Cucumber Core,最新,编程方式启动 Cucumber Runtime。
本地执行器,Bridge/Runner,Node.js,18+,运行 Cypress 和 Bridge 脚本。
,E2E 引擎,Cypress,最新,实际测试执行工具。
,API 客户端,Axios,最新,Bridge 脚本与 Spring Boot 间的通信。
录制工具,插件开发,Chrome/Edge Extension API,Manifest V3,实现跨域 DOM 元素选择和录制。
分发脚本,启动脚本,.sh 和 .bat,-,负责一键启动 Spring Boot 和 Node.js Bridge。

## 核心模块设计与实现细节

### 登录与工作区 (Spring Boot & Next.js)
模块,职责,实现要点
登录 API,接收工号，验证/创建用户，返回 Token/User Info。,Spring Boot： POST /api/auth/login。基于工号（employeeId）进行查找或创建新用户。不需要密码验证，因为是内部工具。
工作区管理,根据工号查找/创建工作区，管理用例存储。,Spring Boot： H2 数据库中创建 User 和 Workspace 表。默认每个用户一个 Workspace。
前端逻辑,登录页面，将工号发送给后端，接收 JWT 或 Session 信息，并使用 Zustand 存储全局用户状态和 Workspace ID。,

### 用例配置与可视化 (Next.js & React Flow)
模块,职责,实现要点
Gherkin 可视化,将 BDD 步骤转化为可视化节点。,React Flow： 用于展示 Given/When/Then 步骤序列。每个节点对应一个预定义的 Gherkin 模板，节点参数（如 [用户名]）通过 AntD 表单编辑。
Cypress 可视化,将 E2E 操作链可视化。,React Flow： 用于展示 visit/click/type/assert 操作链。每个节点对应一个操作，节点参数包括 selector 和 value。
SWR 集成,实时保存用例配置。,使用 SWR 的 mutate 或本地状态管理，配合 Spring Boot API (POST /api/testcase/{id}) 实现配置的自动保存。

### 智能录制与元素选择 (浏览器插件 & Next.js)
模块,职责,实现要点
插件开发,在被测页面 DOM 上捕获用户事件。,"插件 (Edge/Chrome)： 运行 Content Script 监听 click, type 等事件。利用元素的 ID、data-testid 属性等生成稳定的 CSS 选择器。"
通信协议,插件与配置 UI 间的数据传输。,Next.js UI： 开启 WebSocket 或使用浏览器插件的 runtime.sendMessage API。
用例编辑,修改录制生成的 JSON 契约。,Next.js UI： 提供 AntD 表格或列表视图，允许 QA 直接编辑每个操作步骤的 action 和生成的 selector。

### 本地执行与报告 (Spring Boot & Node.js Bridge)
这是最核心且最复杂的流程，全部由本地脚本和进程协调完成。
模块,职责,实现要点
启动脚本,一键启动所有服务。,.sh / .bat： 顺序启动：1. Spring Boot JAR (java -jar)，里面包含了 next.js UI。 2. Node.js Bridge 进程 (node bridge.js)。
Bridge API 客户端,获取配置和上传报告。,Node.js Bridge (Axios)： 调用 Spring Boot 的 /api/test/config/{id} 和 /api/test/report/{id}。
Cypress 执行,动态生成文件并运行 Cypress。,Node.js Bridge： 接收 Execution ID → fs 模块将 JSON 契约转换为 .cy.js → child_process 模块运行 npx cypress run --spec <file> --reporter junit。
Cucumber 执行,动态生成文件并运行 Gherkin。,Spring Boot： 独立 API (POST /api/test/run/cucumber)，接收 Execution ID → Java 代码动态生成 .feature 文件 → 编程调用 io.cucumber.core.cli.Main.run()。
报告解析,将测试结果持久化到 DB。,Spring Boot： 接收 Bridge 上传的 JUnit XML 报告 → 使用 Java XML/JSON 库解析 → 提取关键结果 → 存入 H2 数据库。

### 核心 API 契约设计 (Spring Boot)
序号,API 路径,方法,描述,请求体 (Request Body),响应体 (Response Body)
1,/api/auth/login,POST,用户登录/创建，返回工作区信息。,"{ ""employeeId"": ""string"" }","{ ""userId"": ""uuid"", ""workspaceId"": ""uuid"", ""token"": ""string"" }"
2,/api/testcase,POST,保存新的测试用例（或更新）。,"{ ""workspaceId"": ""uuid"", ""name"": ""string"", ""type"": ""CYPRESS/CUCUMBER"", ""contract"": ""json"" }","{ ""testCaseId"": ""uuid"" }"
3,/api/testcase/{id},GET,供 Bridge 拉取配置。,N/A,"{ ""name"": ""string"", ""contract"": ""json"", ... }"
4,/api/test/run/{type},POST,触发用例执行（CYPRESS 或 CUCUMBER）。,"{ ""testCaseId"": ""uuid"" }","{ ""executionId"": ""uuid"" }"
5,/api/test/report/{execId},POST,供 Bridge 上传报告。,MultiPart/Raw String (JUnit XML/JSON),"{ ""status"": ""success"", ""resultId"": ""uuid"" }"
6,/api/workspace/{id},GET,获取工作区所有用例列表。,N/A,"{ ""testCases"": [...] }"
