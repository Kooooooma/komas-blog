const axios = require('axios');
const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const express = require('express');
const bodyParser = require('body-parser');

const app = express();
const PORT = 3302;
const SPRING_API = 'http://localhost:3300/api';

app.use(bodyParser.json());

// Endpoint to trigger Cypress execution
app.post('/run/cypress', async (req, res) => {
    const { executionId, contract, caseId } = req.body;
    console.log(`Received Cypress execution request: ${executionId}`);

    // 1. Define Local Paths (Safe for Cypress Execution)
    const localSpecDir = path.join(__dirname, 'cypress', 'e2e');
    const localSpecFile = path.join(localSpecDir, `test_${executionId}.cy.js`);

    // Ensure local e2e dir exists
    if (!fs.existsSync(localSpecDir)) {
        fs.mkdirSync(localSpecDir, { recursive: true });
    }

    // 2. Generate Spec Content
    let fileContent = `
    describe('Auto Generated Test ${executionId}', () => {
        it('should execute steps', () => {
    `;

    try {
        const contractJson = JSON.parse(contract);
        if (contractJson.url) {
            fileContent += `            cy.visit('${contractJson.url}');\n`;
            fileContent += `            cy.wait(2000);\n`;
        }

        if (contractJson.steps && Array.isArray(contractJson.steps)) {
            contractJson.steps.forEach(step => {
                fileContent += `            cy.log('Executing ${step.type}: ${step.selector}');\n`;
                if (step.type === 'CLICK') {
                    fileContent += `            cy.get('${step.selector}').click();\n`;
                } else if (step.type === 'TYPE') {
                    fileContent += `            cy.get('${step.selector}').type('${step.value}');\n`;
                }
                fileContent += `            cy.wait(500);\n`;
            });
        }
        else if (contractJson.nodes && Array.isArray(contractJson.nodes)) {
            contractJson.nodes.forEach(node => {
                if (node.data.type === 'GIVEN' || node.data.type === 'When' || node.data.type === 'ACTION') {
                    fileContent += `            cy.log('Executing step: ${node.data.value}');\n`;
                    fileContent += `            cy.wait(500);\n`;
                }
            });
        }
    } catch (e) {
        console.error("Failed to parse contract", e);
        fileContent += `            cy.log('Error parsing contract');\n`;
    }

    fileContent += `
        });
    });
    `;

    // Write Spec File Locally
    fs.writeFileSync(localSpecFile, fileContent);
    console.log("Local spec file created:", localSpecFile);

    // 3. Define Temporary Report Config
    const tempReportDirName = `temp_report_${executionId}`;
    const localReportDir = path.join(__dirname, 'cypress', 'reports', tempReportDirName);

    // Relative path for Cypress options (cleaner for cross-platform)
    const relativeReportDir = path.join('cypress', 'reports', tempReportDirName).replace(/\\/g, '/');

    // Config Options
    const reporterOptions = `reportDir=${relativeReportDir},overwrite=true,html=true,json=false,inlineAssets=true`;

    // Use relative path for spec to avoid specific OS path issues if possible, 
    // but since it is in default folder, we can interpret it relative to project root or use normalized absolute
    const normalizedSpecFile = localSpecFile.replace(/\\/g, '/');

    console.log("Starting Cypress Execution...");
    const cypressCommand = `npx cypress run --headed --spec "${normalizedSpecFile}" --reporter-options "${reporterOptions}"`;

    exec(cypressCommand, { cwd: __dirname }, async (error, stdout, stderr) => {
        console.log("Cypress finished.");
        const logs = stdout || stderr;
        let status = 'SUCCESS';

        if (error) {
            console.error(`Cypress execution error message: ${error.message}`);
            status = 'FAILURE';
        }

        // 4. Move Artifacts to Final Destination
        let reportContent = "Report not generated";

        // Define Final Destination Directory
        const finalArtifactDir = caseId
            ? path.join(__dirname, '..', 'reports', 'cypress', caseId)
            : path.join(__dirname, '..', 'reports', 'cypress', 'misc');

        if (!fs.existsSync(finalArtifactDir)) {
            fs.mkdirSync(finalArtifactDir, { recursive: true });
        }

        try {
            // A. Move Report
            if (fs.existsSync(localReportDir)) {
                const files = fs.readdirSync(localReportDir);
                const htmlFile = files.find(f => f.endsWith('.html'));

                if (htmlFile) {
                    const srcPath = path.join(localReportDir, htmlFile);
                    reportContent = fs.readFileSync(srcPath, 'utf-8');

                    const destPath = path.join(finalArtifactDir, `${executionId}.html`);
                    fs.copyFileSync(srcPath, destPath);
                    console.log(`Report moved to: ${destPath}`);
                } else {
                    console.log("No HTML report found in temp dir.");
                }

                // Cleanup Temp Report Dir
                try {
                    fs.rmSync(localReportDir, { recursive: true, force: true });
                } catch (e) { console.error("Cleanup report error", e); }
            }

            // B. Move Screenshots (If any)
            const localScreenshotsDir = path.join(__dirname, 'cypress', 'screenshots');
            if (fs.existsSync(localScreenshotsDir)) {
                // The screenshots are usually in a subdir named after the spec file
                // e.g. cypress/screenshots/test_xxx.cy.js/screenshot.png
                // We want to move these to finalArtifactDir/screenshots
                const finalScreenshotsDir = path.join(finalArtifactDir, 'screenshots');
                if (!fs.existsSync(finalScreenshotsDir)) {
                    fs.mkdirSync(finalScreenshotsDir, { recursive: true });
                }

                // Copy recursively
                // For simplicity in Node < 16.7, using simple recursor or system command, 
                // but cpSync is available in Node 16.7. Assuming modern node.
                try {
                    fs.cpSync(localScreenshotsDir, finalScreenshotsDir, { recursive: true });
                    console.log(`Screenshots moved to: ${finalScreenshotsDir}`);

                    // Cleanup Local Screenshots
                    fs.rmSync(localScreenshotsDir, { recursive: true, force: true });
                } catch (cpErr) {
                    console.error("Failed to copy/cleanup screenshots", cpErr);
                }
            }

            // C. Clean up Videos (if generated)
            const localVideosDir = path.join(__dirname, 'cypress', 'videos');
            if (fs.existsSync(localVideosDir)) {
                try {
                    fs.rmSync(localVideosDir, { recursive: true, force: true });
                } catch (e) { }
            }

            // D. Move Spec File (Optional, but requested)
            // Copy local spec to final dir for archiving
            const finalSpecPath = path.join(finalArtifactDir, `test_${executionId}.cy.js`);
            fs.copyFileSync(localSpecFile, finalSpecPath);
            console.log(`Spec moved to: ${finalSpecPath}`);

            // Cleanup Local Spec
            try {
                fs.unlinkSync(localSpecFile);
            } catch (e) { console.error("Cleanup spec error", e); }

        } catch (e) {
            console.error("Failed to move artifacts", e);
        }

        // 5. Send Result to Backend
        try {
            await axios.post(`${SPRING_API}/test/report/${executionId}`, {
                status: status,
                logs: logs,
                report: reportContent
            });
            console.log(`Report sent for ${executionId}`);
        } catch (err) {
            console.error("Failed to upload report to Spring Boot", err);
        }
    });

    res.json({ status: 'started', executionId });
});

app.listen(PORT, () => {
    console.log(`Bridge listening on port ${PORT}`);
});
