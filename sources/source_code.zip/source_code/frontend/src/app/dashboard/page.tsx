'use client';

import React, { useEffect, useState } from 'react';
import { Layout, Menu, Typography, Card, Empty, Button, Modal, Input, message, List, Dropdown, Tag } from 'antd';
import { LogoutOutlined, AppstoreOutlined, PlusOutlined, EditOutlined, DeleteOutlined, DownOutlined } from '@ant-design/icons';
import { useAuthStore } from '@/store/useAuthStore';
import { useRouter } from 'next/navigation';
import { OrchestrationWorkspace } from '@/components/OrchestrationWorkspace';

const { Header, Content, Sider } = Layout;
const { Title, Text } = Typography;

type WorkspaceType = 'STANDARD' | 'ORCHESTRATION';

export default function DashboardPage() {
    const { user, workspace, setWorkspace, logout } = useAuthStore();
    const router = useRouter();
    const [testCases, setTestCases] = useState<any[]>([]);
    const [workspaces, setWorkspaces] = useState<any[]>([]);
    const [isModalOpen, setIsModalOpen] = useState(false);

    // Workspace Management State
    const [editingWorkspace, setEditingWorkspace] = useState<string | null>(null);
    const [checkResult, setCheckResult] = useState("");

    useEffect(() => {
        if (workspace?.id && workspace?.type !== 'ORCHESTRATION') {
            fetch(`/api/workspace/${workspace.id}`)
                .then(res => res.json())
                .then(data => setTestCases(data))
                .catch(err => console.error(err));
        } else {
            setTestCases([]);
        }
    }, [workspace]);

    // Fetch all workspaces on mount
    useEffect(() => {
        const fetchWorkspaces = async () => {
            try {
                const res = await fetch(`http://localhost:3300/api/workspace/user/${user?.id}`);
                if (res.ok) {
                    const data = await res.json();
                    setWorkspaces(data);
                    // If no workspace is selected, select the first one
                    if (!workspace && data.length > 0) {
                        setWorkspace(data[0]);
                    }
                }
            } catch (err) {
                console.error('Failed to fetch workspaces:', err);
            }
        };

        if (user?.id) {
            fetchWorkspaces();
        }
    }, [user?.id]);

    const handleCreateCase = (type: string) => {
        router.push(`/editor/new?type=${type}`);
        setIsModalOpen(false);
    };

    const handleLogout = () => {
        logout();
        router.push('/login');
    };

    const handleCreateWorkspace = async (type: WorkspaceType) => {
        const typeName = type === 'ORCHESTRATION' ? '编排 Workspace' : 'New Workspace';
        try {
            const res = await fetch('http://localhost:3300/api/workspace', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: typeName, userId: user?.id, type }),
            });
            const newWs = await res.json();
            setWorkspaces([...workspaces, newWs]);
            setWorkspace(newWs);
            message.success('Workspace created');
            setEditingWorkspace(newWs.id); // Auto-focus edit
        } catch (e) {
            message.error('Failed to create workspace');
        }
    };

    const handleRenameWorkspace = async (id: string, newName: string) => {
        try {
            const res = await fetch(`http://localhost:3300/api/workspace/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name: newName }),
            });
            const updated = await res.json();
            setWorkspaces(workspaces.map(w => w.id === id ? updated : w));
            if (workspace?.id === id) setWorkspace(updated);
            setEditingWorkspace(null);
            message.success('Renamed');
        } catch (e) {
            message.error('Failed to rename');
        }
    };

    // Switch workspace handler
    const onWorkspaceSelect = (id: string) => {
        const selected = workspaces.find(w => w.id === id);
        if (selected) setWorkspace(selected);
    };

    const handleDeleteWorkspace = async (id: string) => {
        const targetWorkspace = workspaces.find(w => w.id === id);
        if (!targetWorkspace) return;

        Modal.confirm({
            title: 'Delete Workspace?',
            content: `Are you sure you want to delete "${targetWorkspace.name}"? This will permanently delete all test cases in this workspace and their reports.`,
            okText: 'Delete',
            okType: 'danger',
            cancelText: 'Cancel',
            onOk: async () => {
                try {
                    const res = await fetch(`http://localhost:3300/api/workspace/${id}`, {
                        method: 'DELETE',
                    });

                    if (res.ok) {
                        // Remove from local state
                        const updatedWorkspaces = workspaces.filter(w => w.id !== id);
                        setWorkspaces(updatedWorkspaces);

                        // If deleted workspace was the current one, switch to first available
                        if (workspace?.id === id) {
                            if (updatedWorkspaces.length > 0) {
                                setWorkspace(updatedWorkspaces[0]);
                            } else {
                                setWorkspace(undefined as any);
                            }
                        }

                        message.success('Workspace deleted successfully');
                    } else {
                        message.error('Failed to delete workspace');
                    }
                } catch (e) {
                    console.error(e);
                    message.error('Error deleting workspace');
                }
            }
        });
    };

    const handleDeleteCase = async (id: string) => {
        if (!confirm("Are you sure you want to delete this test case?")) return;
        try {
            const res = await fetch(`http://localhost:3300/api/testcase/${id}`, {
                method: 'DELETE',
            });
            if (res.ok) {
                setTestCases(testCases.filter(tc => tc.id !== id));
                message.success('Deleted');
            } else {
                message.error('Failed to delete');
            }
        } catch (e) {
            console.error(e);
            message.error('Error deleting');
        }
    };

    // Workspace type dropdown menu items
    const workspaceTypeMenu = {
        items: [
            { key: 'STANDARD', label: '📁 标准 Workspace', description: '创建和管理测试用例' },
            { key: 'ORCHESTRATION', label: '🔀 编排 Workspace', description: '泳道编排多用例执行' },
        ],
        onClick: ({ key }: { key: string }) => handleCreateWorkspace(key as WorkspaceType),
    };

    // Get workspace type tag
    const getWorkspaceTypeTag = (type: string | undefined) => {
        if (type === 'ORCHESTRATION') {
            return <Tag color="purple" style={{ fontSize: 10, marginLeft: 4 }}>编排</Tag>;
        }
        return null;
    };

    if (!user) return null;

    // Render content based on workspace type
    const renderContent = () => {
        if (!workspace) {
            return <Empty description="No workspace selected" />;
        }

        if (workspace.type === 'ORCHESTRATION') {
            return (
                <OrchestrationWorkspace
                    workspaceId={workspace.id}
                    workspaceName={workspace.name}
                    userId={user.id}
                />
            );
        }

        // Standard workspace content
        return (
            <>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 24 }}>
                    <Title level={3}>{workspace?.name}</Title>
                    <Button type="primary" icon={<PlusOutlined />} onClick={() => setIsModalOpen(true)}>New Case</Button>
                </div>

                {testCases.length === 0 ? (
                    <Empty description="No test cases found in this workspace yet." />
                ) : (
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(250px, 1fr))', gap: 16 }}>
                        {testCases.map((tc: any) => {
                            let bgColor = '#fff';
                            let statusColor = '#999';
                            if (tc.lastExecutionStatus === 'SUCCESS') {
                                bgColor = '#f6ffed';
                                statusColor = '#52c41a';
                            } else if (tc.lastExecutionStatus === 'FAILURE') {
                                bgColor = '#fff1f0';
                                statusColor = '#f5222d';
                            }

                            return (
                                <Card
                                    key={tc.id}
                                    title={tc.name}
                                    style={{ backgroundColor: bgColor, borderColor: statusColor === '#999' ? '#f0f0f0' : statusColor }}
                                    extra={
                                        <div style={{ display: 'flex', gap: 8 }}>
                                            <Button type="link" size="small" onClick={() => router.push(`/editor/${tc.id}`)}>Edit</Button>
                                            <Button type="text" danger size="small" icon={<DeleteOutlined />} onClick={() => handleDeleteCase(tc.id)} />
                                        </div>
                                    }
                                >
                                    <p>Type: {tc.type}</p>
                                    <p style={{ color: statusColor, fontWeight: 'bold' }}>
                                        Last Run: {tc.lastExecutionStatus || 'N/A'}
                                    </p>
                                </Card>
                            );
                        })}
                    </div>
                )}
                <div style={{ marginTop: 20, color: '#999' }}>
                    Workspace ID: {workspace?.id}
                </div>

                <Modal title="Select Test Case Type" open={isModalOpen} onCancel={() => setIsModalOpen(false)} footer={null}>
                    <div style={{ display: 'flex', gap: 16, justifyContent: 'center', padding: 20 }}>
                        <Button size="large" onClick={() => handleCreateCase('CUCUMBER')}>Cucumber (Visual)</Button>
                        <Button size="large" onClick={() => handleCreateCase('CYPRESS')}>Cypress (Recorder)</Button>
                    </div>
                </Modal>
            </>
        );
    };

    return (
        <Layout style={{ minHeight: '100vh' }}>
            <Header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px', background: '#fff', borderBottom: '1px solid #f0f0f0' }}>
                <Title level={4} style={{ margin: 0 }}>AT Platform</Title>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <span>{user.employeeId}</span>
                    <Button type="text" icon={<LogoutOutlined />} onClick={handleLogout}>Logout</Button>
                </div>
            </Header>
            <Layout>
                <Sider width={300} theme="light" style={{ borderRight: '1px solid #f0f0f0', display: 'flex', flexDirection: 'column' }}>
                    <div style={{ padding: '16px', borderBottom: '1px solid #f0f0f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Text strong>Workspaces</Text>
                        <Dropdown menu={workspaceTypeMenu} trigger={['click']}>
                            <Button type="text" size="small" icon={<PlusOutlined />} />
                        </Dropdown>
                    </div>
                    <div style={{ flex: 1, overflowY: 'auto' }}>
                        <List
                            itemLayout="horizontal"
                            dataSource={workspaces}
                            renderItem={(item) => (
                                <List.Item
                                    style={{
                                        padding: '12px 16px',
                                        background: workspace?.id === item.id ? '#e6f7ff' : 'transparent',
                                        cursor: 'pointer'
                                    }}
                                    onClick={() => onWorkspaceSelect(item.id)}
                                    actions={[
                                        <Button key="edit" type="text" icon={<EditOutlined />} onClick={(e) => { e.stopPropagation(); setEditingWorkspace(item.id); }} />,
                                        <Button key="delete" type="text" danger icon={<DeleteOutlined />} onClick={(e) => { e.stopPropagation(); handleDeleteWorkspace(item.id); }} />
                                    ]}
                                >
                                    {editingWorkspace === item.id ? (
                                        <Input
                                            defaultValue={item.name}
                                            autoFocus
                                            onBlur={(e) => handleRenameWorkspace(item.id, e.target.value)}
                                            onPressEnter={(e) => handleRenameWorkspace(item.id, (e.target as any).value)}
                                            onClick={(e) => e.stopPropagation()}
                                        />
                                    ) : (
                                        <div style={{ display: 'flex', alignItems: 'center' }}>
                                            <Text ellipsis style={{ maxWidth: 120 }}>{item.name}</Text>
                                            {getWorkspaceTypeTag(item.type)}
                                        </div>
                                    )}
                                </List.Item>
                            )}
                        />
                    </div>
                </Sider>
                <Layout style={{ padding: '24px' }}>
                    <Content
                        style={{
                            padding: 24,
                            margin: 0,
                            minHeight: 280,
                            background: '#fff',
                        }}
                    >
                        {renderContent()}
                    </Content>
                </Layout>
            </Layout>
        </Layout>
    );
}
