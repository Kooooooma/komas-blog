'use client';

import React, { useState } from 'react';
import { Form, Input, Button, Card, Typography, message } from 'antd';
import { UserOutlined } from '@ant-design/icons';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/useAuthStore';

const { Title } = Typography;

export default function LoginPage() {
    const router = useRouter();
    const login = useAuthStore((state) => state.login);
    const [loading, setLoading] = useState(false);

    const onFinish = async (values: { employeeId: string }) => {
        setLoading(true);
        try {
            const res = await fetch('/api/auth/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(values),
            });

            if (!res.ok) throw new Error('Login failed');

            const data = await res.json();
            login(
                { id: data.userId, employeeId: data.employeeId },
                { id: data.workspaceId, name: data.workspaceName, userId: data.userId },
                data.token || 'mock-token'
            );

            message.success('Login successful');
            router.push('/dashboard');
        } catch (error) {
            message.error('Login failed. Please check backend connection.');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', background: '#f0f2f5' }}>
            <Card style={{ width: 400 }}>
                <div style={{ textAlign: 'center', marginBottom: 24 }}>
                    <Title level={2}>AT Platform</Title>
                    <Typography.Text type="secondary">Internal Test Automation</Typography.Text>
                </div>
                <Form
                    name="login"
                    onFinish={onFinish}
                    layout="vertical"
                >
                    <Form.Item
                        name="employeeId"
                        rules={[{ required: true, message: 'Please input your Employee ID!' }]}
                    >
                        <Input
                            prefix={<UserOutlined />}
                            placeholder="Employee ID (e.g., EMP001)"
                            size="large"
                        />
                    </Form.Item>

                    <Form.Item>
                        <Button type="primary" htmlType="submit" block size="large" loading={loading}>
                            Login
                        </Button>
                    </Form.Item>
                </Form>
            </Card>
        </div>
    );
}
