'use client';

import React, { useState, useEffect } from 'react';
import { message, Spin, Modal, Button, Tag } from 'antd';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuthStore } from '@/store/useAuthStore';
import { CucumberEditor } from '@/components/editors/CucumberEditor';
import { CypressEditor } from '@/components/editors/CypressEditor';

export default function EditorPage({ params }: { params: Promise<{ id: string }> }) {
    const router = useRouter();
    const searchParams = useSearchParams();
    const { id } = React.use(params);
    const { user } = useAuthStore();

    // State
    const [loading, setLoading] = useState(true);
    const [type, setType] = useState<string | null>(null);
    const [initialData, setInitialData] = useState<any>(null);
    const [executing, setExecuting] = useState(false);
    const [runStatus, setRunStatus] = useState<string | null>(null);
    const [caseName, setCaseName] = useState<string>('');

    // Refactored to track execution ID
    const [currentExecutionId, setCurrentExecutionId] = useState<string | null>(null);
    const [lastExecutionId, setLastExecutionId] = useState<string | null>(null);
    const [logs, setLogs] = useState<string>('');
    const [isLogModalOpen, setIsLogModalOpen] = useState(false);

    // 1. Fetch Data (if existing) OR Set Type (if new)
    useEffect(() => {
        if (id === 'new') {
            const queryType = searchParams.get('type');
            setType(queryType || 'CUCUMBER'); // Default to Cucumber if missing
            setCaseName(`New Test Case ${new Date().toLocaleTimeString()}`);
            setLoading(false);
        } else {
            fetch(`http://localhost:3300/api/testcase/${id}`)
                .then(res => {
                    if (!res.ok) throw new Error('Failed to fetch');
                    return res.json();
                })
                .then(data => {
                    setType(data.type);
                    setCaseName(data.name || 'Untitled Test Case');
                    if (data.contract) {
                        try {
                            setInitialData(JSON.parse(data.contract));
                        } catch (e) {
                            console.error("Failed to parse contract", e);
                        }
                    }
                    // Load last execution status if available
                    if (data.lastExecutionId) {
                        setLastExecutionId(data.lastExecutionId);
                        setRunStatus(data.lastExecutionStatus);

                        // Fetch logs for the last execution
                        fetch(`http://localhost:3300/api/test/${data.lastExecutionId}`)
                            .then(res => {
                                if (!res.ok) throw new Error('Failed to fetch logs');
                                return res.json();
                            })
                            .then(execData => {
                                setLogs(execData.logs || '');
                            })
                            .catch(e => console.error("Failed to load last execution logs", e));
                    }
                    setLoading(false);
                })
                .catch(err => {
                    console.error(err);
                    message.error("Could not load test case");
                    router.push('/dashboard');
                });
        }
    }, [id, searchParams, router]);

    const handleSave = async (contract: string) => {
        try {
            const res = await fetch('http://localhost:3300/api/testcase', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    id: id === 'new' ? undefined : id,
                    workspaceId: useAuthStore.getState().workspace?.id,
                    name: caseName,
                    type: type,
                    contract: contract
                }),
            });
            if (!res.ok) throw new Error('Failed to save');
            const data = await res.json();
            message.success('Test Case Saved!');
            if (id === 'new') {
                router.replace(`/editor/${data.id}`);
            }
        } catch (error) {
            console.error(error);
            message.error('Save failed');
        }
    };

    const handleSaveName = async (caseName: string) => {
        if (id === 'new') {
            setCaseName(caseName);
            return;
        }
        try {
            const res = await fetch(`http://localhost:3300/api/testcase/${id}/name`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    name: caseName
                }),
            });
            if (!res.ok) throw new Error('Failed to update test case title');
            const data = await res.json();
            message.success('Test Case Title Updated!');
            setCaseName(caseName);
        } catch (error) {
            console.error(error);
            message.error('Test case title update failed');
        }
    };

    // Polling Logic
    useEffect(() => {
        let interval: NodeJS.Timeout;
        if (runStatus === 'RUNNING' || runStatus === 'PENDING') {
            interval = setInterval(async () => {
                try {
                    // Check local execution state first or just poll the latest execution we triggered
                    // Ideally we should track the executionId.
                    // For now, we assume the latest execution for this test case or need to store executionId.
                } catch (e) {
                    console.error(e);
                }
            }, 2000);
        }
        return () => clearInterval(interval);
    }, [runStatus]);

    useEffect(() => {
        let interval: NodeJS.Timeout;
        if (currentExecutionId && (runStatus === 'RUNNING' || runStatus === 'PENDING')) {
            interval = setInterval(async () => {
                try {
                    const res = await fetch(`http://localhost:3300/api/test/${currentExecutionId}`);
                    if (res.ok) {
                        const data = await res.json();
                        setRunStatus(data.status);
                        if (data.status === 'SUCCESS' || data.status === 'FAILURE') {
                            setExecuting(false);
                            setLogs(data.logs);
                            setLastExecutionId(currentExecutionId);
                            setCurrentExecutionId(null); // Stop polling
                            message.info(`Test Finished: ${data.status}`);
                        }
                    }
                } catch (e) {
                    console.error("Polling error", e);
                }
            }, 2000);
        }
        return () => clearInterval(interval);
    }, [currentExecutionId, runStatus]);


    const handleRun = async () => {
        if (id === 'new') {
            message.warning('Please save first.');
            return;
        }

        try {
            setExecuting(true);
            setRunStatus('PENDING');
            const res = await fetch('http://localhost:3300/api/test/run', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ testCaseId: id }),
            });
            if (!res.ok) throw new Error('Failed to start');

            const execution = await res.json();
            setCurrentExecutionId(execution.id);
            setRunStatus('RUNNING');
            message.success('Execution started');

        } catch (error) {
            console.error(error);
            message.error('Run failed');
            setRunStatus('FAILURE');
            setExecuting(false);
        }
    };

    const handleViewLogs = () => {
        setIsLogModalOpen(true);
    };

    const handleViewReport = () => {
        const reportId = lastExecutionId || currentExecutionId;
        if (!reportId) {
            message.warning("No report available.");
            return;
        }
        window.open(`http://localhost:3300/api/test/report/${reportId}`, '_blank');
    };

    if (loading) return <div style={{ display: 'flex', justifyContent: 'center', marginTop: 100 }}><Spin size="large" /></div>;

    // Determine status display
    const getStatusTag = () => {
        if (!runStatus) return null;

        const statusConfig: Record<string, { color: string; text: string }> = {
            SUCCESS: { color: 'green', text: '✓ Last Run: Success' },
            FAILURE: { color: 'red', text: '✗ Last Run: Failed' },
            RUNNING: { color: 'blue', text: '⟳ Running...' },
            PENDING: { color: 'orange', text: '⋯ Pending...' }
        };

        const config = statusConfig[runStatus] || { color: 'default', text: runStatus };
        return <Tag color={config.color} style={{ marginLeft: 8 }}>{config.text}</Tag>;
    };

    const commonProps = {
        onSave: handleSave,
        onBack: () => router.back(),
        initialData: initialData,
        executing: executing,
        onRun: handleRun,
        runStatus: runStatus,
        name: caseName,
        onNameChange: handleSaveName,
        statusTag: getStatusTag(),
        onViewReport: handleViewReport,
        hasReport: !!(lastExecutionId || currentExecutionId)
    };

    return (
        <>
            {type === 'CYPRESS' ? (
                <CypressEditor {...commonProps} onCheckReport={handleViewLogs} />
            ) : (
                <CucumberEditor
                    {...commonProps}
                    onCheckReport={handleViewLogs}
                />
            )}

            <Modal
                title="Execution Logs"
                open={isLogModalOpen}
                onCancel={() => setIsLogModalOpen(false)}
                footer={[
                    <Button key="report" onClick={handleViewReport}>
                        View Full Report
                    </Button>,
                    <Button key="close" type="primary" onClick={() => setIsLogModalOpen(false)}>
                        Close
                    </Button>
                ]}
                width={800}
            >
                <div style={{ whiteSpace: 'pre-wrap', maxHeight: '600px', overflow: 'auto', background: '#f5f5f5', padding: '16px', fontFamily: 'monospace' }}>
                    {logs || 'No logs available.'}
                </div>
            </Modal>
            {/* Hidden marker for extension detection */}
            <div id="at-editor-marker" data-type={type} style={{ display: 'none' }} />
        </>
    );
}
