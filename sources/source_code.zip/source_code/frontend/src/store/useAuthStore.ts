import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface User {
    id: string;
    employeeId: string;
}

interface Workspace {
    id: string;
    name: string;
    userId: string;
    type?: 'STANDARD' | 'ORCHESTRATION';
}

interface AuthState {
    user: User | null;
    workspace: Workspace | null;
    token: string | null;
    login: (user: User, workspace: Workspace, token: string) => void;
    setWorkspace: (workspace: Workspace) => void;
    logout: () => void;
}

export const useAuthStore = create<AuthState>()(
    persist(
        (set) => ({
            user: null,
            workspace: null,
            token: null,
            login: (user, workspace, token) => set({ user, workspace, token }),
            setWorkspace: (workspace) => set({ workspace }),
            logout: () => set({ user: null, workspace: null, token: null }),
        }),
        {
            name: 'auth-storage',
        }
    )
);
