'use client';

import React, { useState } from 'react';
import { Card, Button, Input, Progress, Tag, Dropdown, Select, Modal, Empty, message } from 'antd';
import { PlusOutlined, PlayCircleOutlined, DeleteOutlined, HolderOutlined } from '@ant-design/icons';
import { CaseCard } from './CaseCard';

interface LaneCase {
    mappingId: string;
    testCaseId: string;
    name: string;
    type: string;
    workspaceId: string;
    workspaceName?: string;
    orderIndex: number;
    lastExecutionStatus?: string;
}

interface SwimLaneProps {
    id: string;
    name: string;
    cases: LaneCase[];
    lastExecutionStatus?: string;
    standardWorkspaces: { id: string; name: string }[];
    onNameChange: (id: string, name: string) => void;
    onDelete: (id: string) => void;
    onAddCase: (laneId: string, testCaseId: string) => void;
    onRemoveCase: (laneId: string, mappingId: string) => void;
    onReorderCases: (laneId: string, orderedMappings: { mappingId: string }[]) => void;
    onRunLane: (laneId: string) => void;
    onViewCaseDetails: (caseId: string) => void;
    availableCases: { workspaceId: string; workspaceName: string; cases: { id: string; name: string; type: string }[] }[];
}

/**
 * 泳道组件 - 水平看板形式展示 Case 执行顺序
 */
export const SwimLane: React.FC<SwimLaneProps> = ({
    id,
    name,
    cases,
    lastExecutionStatus,
    onNameChange,
    onDelete,
    onAddCase,
    onRemoveCase,
    onReorderCases,
    onRunLane,
    onViewCaseDetails,
    availableCases,
}) => {
    const [isEditing, setIsEditing] = useState(false);
    const [editName, setEditName] = useState(name);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [selectedWorkspace, setSelectedWorkspace] = useState<string | null>(null);
    const [selectedCase, setSelectedCase] = useState<string | null>(null);
    const [draggedIndex, setDraggedIndex] = useState<number | null>(null);

    // 计算进度
    const successCount = cases.filter(c => c.lastExecutionStatus === 'SUCCESS').length;
    const failedCount = cases.filter(c => c.lastExecutionStatus === 'FAILURE').length;
    const totalCount = cases.length;
    const progress = totalCount > 0 ? Math.round(((successCount + failedCount) / totalCount) * 100) : 0;

    const getStatusColor = () => {
        switch (lastExecutionStatus) {
            case 'SUCCESS': return '#52c41a';
            case 'FAILURE': return '#f5222d';
            case 'RUNNING': return '#1890ff';
            default: return '#d9d9d9';
        }
    };

    const handleNameSave = () => {
        if (editName.trim() && editName !== name) {
            onNameChange(id, editName.trim());
        }
        setIsEditing(false);
    };

    const handleAddCase = () => {
        if (selectedCase) {
            onAddCase(id, selectedCase);
            setIsAddModalOpen(false);
            setSelectedWorkspace(null);
            setSelectedCase(null);
        }
    };

    // 拖拽处理
    const handleDragStart = (e: React.DragEvent, index: number) => {
        setDraggedIndex(index);
        e.dataTransfer.effectAllowed = 'move';
    };

    const handleDragOver = (e: React.DragEvent, index: number) => {
        e.preventDefault();
        if (draggedIndex === null || draggedIndex === index) return;

        // 视觉效果可以在这里添加
    };

    const handleDrop = (e: React.DragEvent, targetIndex: number) => {
        e.preventDefault();
        if (draggedIndex === null || draggedIndex === targetIndex) {
            setDraggedIndex(null);
            return;
        }

        // 重新排序
        const newCases = [...cases];
        const [draggedItem] = newCases.splice(draggedIndex, 1);
        newCases.splice(targetIndex, 0, draggedItem);

        // 调用重排 API
        onReorderCases(id, newCases.map(c => ({ mappingId: c.mappingId })));
        setDraggedIndex(null);
    };

    const handleDragEnd = () => {
        setDraggedIndex(null);
    };

    const filteredCases = selectedWorkspace
        ? availableCases.find(w => w.workspaceId === selectedWorkspace)?.cases || []
        : [];

    return (
        <Card
            style={{
                marginBottom: 16,
                borderLeft: `4px solid ${getStatusColor()}`,
            }}
            bodyStyle={{ padding: 16 }}
        >
            {/* 泳道头部 */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 12, flex: 1 }}>
                    {isEditing ? (
                        <Input
                            value={editName}
                            onChange={(e) => setEditName(e.target.value)}
                            onBlur={handleNameSave}
                            onPressEnter={handleNameSave}
                            autoFocus
                            style={{ width: 200 }}
                        />
                    ) : (
                        <span
                            onClick={() => setIsEditing(true)}
                            style={{ fontWeight: 600, fontSize: 16, cursor: 'pointer' }}
                        >
                            {name}
                        </span>
                    )}
                    <Tag color={getStatusColor()}>
                        {lastExecutionStatus || 'PENDING'}
                    </Tag>
                    <span style={{ color: '#999', fontSize: 12 }}>
                        {successCount}/{totalCount} passed
                    </span>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                    <Button
                        type="primary"
                        icon={<PlayCircleOutlined />}
                        onClick={() => onRunLane(id)}
                        disabled={cases.length === 0}
                    >
                        Run Lane
                    </Button>
                    <Button
                        icon={<PlusOutlined />}
                        onClick={() => setIsAddModalOpen(true)}
                    >
                        Add Case
                    </Button>
                    <Button
                        danger
                        icon={<DeleteOutlined />}
                        onClick={() => onDelete(id)}
                    />
                </div>
            </div>

            {/* 进度条 */}
            <Progress
                percent={progress}
                strokeColor={failedCount > 0 ? '#f5222d' : '#52c41a'}
                style={{ marginBottom: 12 }}
                format={() => `${successCount + failedCount}/${totalCount}`}
            />

            {/* Case 列表（水平排列） */}
            <div
                style={{
                    display: 'flex',
                    gap: 12,
                    overflowX: 'auto',
                    padding: '8px 0',
                    minHeight: 120,
                    alignItems: 'flex-start',
                }}
            >
                {cases.length === 0 ? (
                    <Empty description="No cases in this lane" style={{ margin: '0 auto' }} />
                ) : (
                    cases.map((c, index) => (
                        <div
                            key={c.mappingId}
                            draggable
                            onDragStart={(e) => handleDragStart(e, index)}
                            onDragOver={(e) => handleDragOver(e, index)}
                            onDrop={(e) => handleDrop(e, index)}
                            onDragEnd={handleDragEnd}
                            style={{
                                opacity: draggedIndex === index ? 0.5 : 1,
                                transition: 'opacity 0.2s',
                            }}
                        >
                            <CaseCard
                                id={c.testCaseId}
                                mappingId={c.mappingId}
                                name={c.name}
                                type={c.type}
                                workspaceName={c.workspaceName}
                                lastExecutionStatus={c.lastExecutionStatus}
                                onRemove={(mappingId) => onRemoveCase(id, mappingId)}
                                onViewDetails={onViewCaseDetails}
                            />
                        </div>
                    ))
                )}
            </div>

            {/* 添加 Case Modal */}
            <Modal
                title="Add Case to Lane"
                open={isAddModalOpen}
                onCancel={() => {
                    setIsAddModalOpen(false);
                    setSelectedWorkspace(null);
                    setSelectedCase(null);
                }}
                onOk={handleAddCase}
                okButtonProps={{ disabled: !selectedCase }}
            >
                <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                    <div>
                        <div style={{ marginBottom: 8 }}>Select Workspace:</div>
                        <Select
                            style={{ width: '100%' }}
                            placeholder="Choose a workspace"
                            value={selectedWorkspace}
                            onChange={(value) => {
                                setSelectedWorkspace(value);
                                setSelectedCase(null);
                            }}
                            options={availableCases.map(w => ({
                                value: w.workspaceId,
                                label: w.workspaceName,
                            }))}
                        />
                    </div>
                    <div>
                        <div style={{ marginBottom: 8 }}>Select Case:</div>
                        <Select
                            style={{ width: '100%' }}
                            placeholder="Choose a case"
                            value={selectedCase}
                            onChange={setSelectedCase}
                            disabled={!selectedWorkspace}
                            options={filteredCases.map(c => ({
                                value: c.id,
                                label: `${c.name} (${c.type})`,
                            }))}
                        />
                    </div>
                </div>
            </Modal>
        </Card>
    );
};

export default SwimLane;
