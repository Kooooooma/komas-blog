'use client';

import React from 'react';
import { Card, Progress, Statistic, Row, Col, Tag, Table } from 'antd';
import { CheckCircleOutlined, CloseCircleOutlined, ClockCircleOutlined, PercentageOutlined } from '@ant-design/icons';

interface LaneStat {
    laneId: string;
    laneName: string;
    status: string;
    totalCases: number;
    successCases: number;
    failedCases: number;
    pendingCases: number;
}

interface LaneStatisticsProps {
    totalLanes: number;
    totalCases: number;
    successCases: number;
    failedCases: number;
    pendingCases: number;
    successRate: number;
    lanes: LaneStat[];
}

/**
 * 泳道执行统计组件
 */
export const LaneStatistics: React.FC<LaneStatisticsProps> = ({
    totalLanes,
    totalCases,
    successCases,
    failedCases,
    pendingCases,
    successRate,
    lanes,
}) => {
    const columns = [
        {
            title: 'Lane',
            dataIndex: 'laneName',
            key: 'laneName',
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            render: (status: string) => {
                const color = status === 'SUCCESS' ? 'green' : status === 'FAILURE' ? 'red' : status === 'RUNNING' ? 'blue' : 'default';
                return <Tag color={color}>{status || 'PENDING'}</Tag>;
            },
        },
        {
            title: 'Total',
            dataIndex: 'totalCases',
            key: 'totalCases',
        },
        {
            title: 'Passed',
            dataIndex: 'successCases',
            key: 'successCases',
            render: (val: number) => <span style={{ color: '#52c41a' }}>{val}</span>,
        },
        {
            title: 'Failed',
            dataIndex: 'failedCases',
            key: 'failedCases',
            render: (val: number) => <span style={{ color: '#f5222d' }}>{val}</span>,
        },
        {
            title: 'Pending',
            dataIndex: 'pendingCases',
            key: 'pendingCases',
            render: (val: number) => <span style={{ color: '#faad14' }}>{val}</span>,
        },
        {
            title: 'Progress',
            key: 'progress',
            render: (_: any, record: LaneStat) => {
                const percent = record.totalCases > 0
                    ? Math.round(((record.successCases + record.failedCases) / record.totalCases) * 100)
                    : 0;
                return (
                    <Progress
                        percent={percent}
                        size="small"
                        strokeColor={record.failedCases > 0 ? '#f5222d' : '#52c41a'}
                    />
                );
            },
        },
    ];

    return (
        <Card title="Execution Statistics" style={{ marginBottom: 16 }}>
            <Row gutter={16} style={{ marginBottom: 24 }}>
                <Col span={4}>
                    <Statistic
                        title="Total Lanes"
                        value={totalLanes}
                        prefix={<ClockCircleOutlined />}
                    />
                </Col>
                <Col span={4}>
                    <Statistic
                        title="Total Cases"
                        value={totalCases}
                    />
                </Col>
                <Col span={4}>
                    <Statistic
                        title="Passed"
                        value={successCases}
                        valueStyle={{ color: '#52c41a' }}
                        prefix={<CheckCircleOutlined />}
                    />
                </Col>
                <Col span={4}>
                    <Statistic
                        title="Failed"
                        value={failedCases}
                        valueStyle={{ color: '#f5222d' }}
                        prefix={<CloseCircleOutlined />}
                    />
                </Col>
                <Col span={4}>
                    <Statistic
                        title="Pending"
                        value={pendingCases}
                        valueStyle={{ color: '#faad14' }}
                    />
                </Col>
                <Col span={4}>
                    <Statistic
                        title="Success Rate"
                        value={successRate}
                        precision={1}
                        valueStyle={{ color: successRate >= 80 ? '#52c41a' : successRate >= 50 ? '#faad14' : '#f5222d' }}
                        suffix="%"
                        prefix={<PercentageOutlined />}
                    />
                </Col>
            </Row>

            <Table
                columns={columns}
                dataSource={lanes.map(l => ({ ...l, key: l.laneId }))}
                pagination={false}
                size="small"
            />
        </Card>
    );
};

export default LaneStatistics;
