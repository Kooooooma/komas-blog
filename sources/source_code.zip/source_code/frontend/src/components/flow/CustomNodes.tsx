import React, { memo, useState } from 'react';
import { Handle, Position } from 'reactflow';
import { Card, Input, Select, Button, Tooltip, Typography } from 'antd';
import { DeleteOutlined } from '@ant-design/icons';

// Generic Action Node Interface
interface ActionNodeData {
    metadata: any; // StepMetadata from backend
    values: Record<string, any>;
    onUpdate: (field: string, val: any) => void;
    onDelete: () => void;
}

const StepNode = ({ data }: { data: { label: string, type: string, value: string, onUpdate: (val: string) => void } }) => {
    return (
        <Card size="small" title={data.type} style={{ width: 200, boxShadow: '0 2px 4px rgba(0,0,0,0.1)' }}>
            <Handle type="target" position={Position.Top} />
            <Input
                placeholder="Value"
                value={data.value}
                onChange={(e) => data.onUpdate(e.target.value)}
            />
            <Handle type="source" position={Position.Bottom} />
        </Card>
    );
};


const ActionNode = ({ data }: { data: ActionNodeData }) => {
    const [servers, setServers] = useState<string[]>([]);
    const [loadingServers, setLoadingServers] = useState(false);

    // Lazy load servers only when dropdown is opened
    const handleServerDropdownOpen = (open: boolean) => {
        if (open && servers.length === 0 && !loadingServers) {
            setLoadingServers(true);
            fetch('/api/servers')
                .then(res => res.json())
                .then(list => {
                    setServers(list);
                    setLoadingServers(false);
                })
                .catch(e => {
                    console.error("Failed to fetch servers", e);
                    setLoadingServers(false);
                });
        }
    };

    return (
        <Card
            size="small"
            title={
                <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Tooltip title={data.metadata.description}>
                        <span>{data.metadata.name}</span>
                    </Tooltip>
                    <Button
                        type="text"
                        danger
                        size="small"
                        icon={<DeleteOutlined />}
                        onClick={(e) => {
                            e.stopPropagation();
                            data.onDelete();
                        }}
                    />
                </div>
            }
            style={{ width: 300, border: '1px solid #1890ff', borderRadius: 8 }}
            bodyStyle={{ padding: 12 }}
        >
            <Handle type="target" position={Position.Top} />
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {data.metadata.parameters?.map((param: any) => {
                    // Special handling for 'target' (Server Select)
                    if (param.name === 'target') {
                        return (
                            <div key={param.name} className="nodrag">
                                <Typography.Text type="secondary" style={{ fontSize: 12 }}>Server (user@host)</Typography.Text>
                                <Select
                                    size="small"
                                    style={{ width: '100%' }}
                                    placeholder="Select Server"
                                    options={servers.map((s: string) => ({ label: s, value: s }))}
                                    value={data.values[param.name] || undefined}
                                    onChange={(val) => data.onUpdate(param.name, val)}
                                    onDropdownVisibleChange={handleServerDropdownOpen}
                                    loading={loadingServers}
                                    showSearch
                                    allowClear
                                    onClick={(e) => e.stopPropagation()}
                                    onMouseDown={(e) => e.stopPropagation()}
                                />
                            </div>
                        );
                    }

                    // Special handling for 'keyPath'
                    if (param.name === 'keyPath') {
                        return (
                            <div key={param.name}>
                                <Typography.Text type="secondary" style={{ fontSize: 12 }}>SSH Key Path</Typography.Text>
                                <div style={{ display: 'flex', gap: 4 }}>
                                    <Input
                                        size="small"
                                        placeholder="keys/"
                                        value={data.values[param.name] || 'keys/'}
                                        onChange={(e) => data.onUpdate(param.name, e.target.value)}
                                    />
                                    <Button
                                        size="small"
                                        onClick={() => {
                                            const input = document.createElement('input');
                                            input.type = 'file';
                                            input.accept = '.pem,.key,.pub';
                                            input.onchange = (e: any) => {
                                                const file = e.target?.files?.[0];
                                                if (file) {
                                                    data.onUpdate(param.name, file.name);
                                                }
                                            };
                                            input.click();
                                        }}
                                    >
                                        ...
                                    </Button>
                                </div>
                            </div>
                        );
                    }

                    // Default Input
                    return (
                        <div key={param.name}>
                            <Typography.Text type="secondary" style={{ fontSize: 12 }}>{param.name}</Typography.Text>
                            <Input
                                size="small"
                                placeholder={param.defaultValue}
                                value={data.values[param.name] || ''}
                                onChange={(e) => data.onUpdate(param.name, e.target.value)}
                            />
                        </div>
                    );
                })}
            </div>
            <Handle type="source" position={Position.Bottom} />
        </Card>
    );
};

export const nodeTypes = {
    step: memo(StepNode),
    action: memo(ActionNode),
};
