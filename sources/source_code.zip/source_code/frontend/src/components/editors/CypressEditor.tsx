import React, { useState, useEffect } from 'react';
import { Button, Layout, Typography, List, Input, Modal, message, Drawer, Select } from 'antd';
import { SaveOutlined, ArrowLeftOutlined, VideoCameraOutlined, DeleteOutlined, MenuOutlined, PlusOutlined } from '@ant-design/icons';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

const { Header, Content } = Layout;
const { Title } = Typography;
const { Option } = Select;

interface Step {
    id?: string;
    type: string;
    selector: string;
    value: string;
}

interface CypressEditorProps {
    onSave: (contract: string, nameOverride?: string) => void;
    onBack: () => void;
    initialData?: { steps: Step[]; url?: string };
    executing: boolean;
    onRun: () => void;
    runStatus: string | null;
    name: string;
    onNameChange: (name: string) => void;
    onCheckReport: () => void;
    statusTag?: React.ReactNode;
    onViewReport?: () => void;
    hasReport?: boolean;
}

// Sortable Item Component
function SortableItem({ id, item, index, onChange, onDelete }: any) {
    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
    };

    return (
        <List.Item ref={setNodeRef} style={style}>
            <div style={{ display: 'flex', gap: 16, width: '100%', alignItems: 'center' }}>
                <MenuOutlined style={{ cursor: 'grab', color: '#999' }} {...attributes} {...listeners} />
                <Select
                    value={item.type}
                    onChange={(value) => onChange(index, 'type', value)}
                    style={{ width: 100, fontWeight: 'bold' }}
                >
                    <Option value="CLICK">CLICK</Option>
                    <Option value="TYPE">TYPE</Option>
                    <Option value="VISIT">VISIT</Option>
                    <Option value="WAIT">WAIT</Option>
                </Select>
                <Input
                    value={item.selector}
                    onChange={(e) => onChange(index, 'selector', e.target.value)}
                    style={{ flex: 1 }}
                    placeholder="Selector"
                />
                <Input
                    value={item.value}
                    onChange={(e) => onChange(index, 'value', e.target.value)}
                    style={{ flex: 1 }}
                    placeholder="Value (if type/click)"
                />
                <Button danger icon={<DeleteOutlined />} onClick={() => onDelete(index)} />
            </div>
        </List.Item>
    );
}

export const CypressEditor: React.FC<CypressEditorProps> = ({ onSave, onBack, initialData, executing, onRun, runStatus, name, onNameChange, onCheckReport, statusTag, onViewReport, hasReport }) => {
    // Ensure steps have unique IDs for DnD
    const [steps, setSteps] = useState<any[]>(
        (initialData?.steps || []).map((s: any, i: number) => ({ ...s, id: s.id || `step-${i}-${Date.now()}` }))
    );
    const [isRecording, setIsRecording] = useState(false);
    const [targetUrl, setTargetUrl] = useState(initialData?.url || '');
    const [isModalVisible, setIsModalVisible] = useState(false);

    const sensors = useSensors(
        useSensor(PointerSensor),
        useSensor(KeyboardSensor, {
            coordinateGetter: sortableKeyboardCoordinates,
        })
    );

    // Recording Listener & Init
    useEffect(() => {
        // 1. Notify extension that we are here
        window.postMessage({ type: 'AT_EXTENSION_INIT', editorType: 'CYPRESS' }, '*');

        // 2. Listen for messages
        const handleMessage = (event: MessageEvent) => {
            if (event.source !== window) return;
            if (event.data.type === 'AT_NEW_STEP') {
                const step = { ...event.data.step, id: `step-${Date.now()}` };
                setSteps((prev) => [...prev, step]);
                message.info(`Captured: ${step.type}`);
            }
        };

        window.addEventListener('message', handleMessage);

        // Cleanup: remove listener and notify extension of deactivation
        return () => {
            window.removeEventListener('message', handleMessage);
            window.postMessage({ type: 'AT_EXTENSION_DEACTIVATE' }, '*');
        };
    }, []);

    const startRecording = () => {
        if (!targetUrl) {
            message.error("Please enter a target URL");
            return;
        }
        window.open(targetUrl, '_blank');
        window.postMessage({ type: 'AT_START_RECORDING', targetUrl }, '*');
        setIsRecording(true);
        setIsModalVisible(false);
        message.success("Recording started in new tab");
    };

    const stopRecording = () => {
        window.postMessage({ type: 'AT_STOP_RECORDING' }, '*');
        setIsRecording(false);
        message.info("Recording stopped");
    };

    const handleSave = () => {
        // Strip internal IDs before saving if needed, but keeping them is fine for now
        const contract = JSON.stringify({ steps, url: targetUrl });
        onSave(contract);
    };

    const handleStepChange = (index: number, field: string, value: string) => {
        const newSteps = [...steps];
        newSteps[index][field] = value;
        setSteps(newSteps);
    };

    const handleDeleteStep = (index: number) => {
        const newSteps = [...steps];
        newSteps.splice(index, 1);
        setSteps(newSteps);
    };

    const handleAddStep = () => {
        const newStep = {
            id: `step-${Date.now()}`,
            type: 'CLICK',
            selector: '',
            value: ''
        };
        setSteps([...steps, newStep]);
    };

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;

        if (active.id !== over?.id) {
            setSteps((items) => {
                const oldIndex = items.findIndex((i) => i.id === active.id);
                const newIndex = items.findIndex((i) => i.id === over?.id);
                return arrayMove(items, oldIndex, newIndex);
            });
        }
    };

    // Code Preview Logic
    const [isCodeDrawerOpen, setIsCodeDrawerOpen] = useState(false);
    const [previewCode, setPreviewCode] = useState('');

    const generateCypressCode = () => {
        let code = `describe('${name}', () => {\n    it('should execute steps', () => {\n`;

        if (targetUrl) {
            code += `        cy.visit('${targetUrl}');\n`;
            code += `        cy.wait(2000);\n`;
        }

        steps.forEach(step => {
            code += `        cy.log('Executing ${step.type}: ${step.selector}');\n`;
            if (step.type === 'CLICK') {
                code += `        cy.get('${step.selector}').click();\n`;
            } else if (step.type === 'TYPE') {
                code += `        cy.get('${step.selector}').type('${step.value}');\n`;
            } else if (step.type === 'VISIT') {
                code += `        cy.visit('${step.value}');\n`;
            } else if (step.type === 'WAIT') {
                code += `        cy.wait(${parseInt(step.value) || 1000});\n`;
            }
            code += `        cy.wait(500);\n`;
        });

        code += `    });\n});`;
        setPreviewCode(code);
        setIsCodeDrawerOpen(true);
    };

    return (
        <Layout style={{ height: '100vh' }}>
            <Header style={{ background: '#fff', borderBottom: '1px solid #f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <Button icon={<ArrowLeftOutlined />} onClick={onBack} />
                    <Title level={4} style={{ margin: 0 }} editable={{
                        onChange: (val) => {
                            onNameChange(val);
                        }
                    }}>{name}</Title>
                    {statusTag}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                    <Button onClick={generateCypressCode}>View Code</Button>
                    {hasReport && <Button onClick={onViewReport}>View Report</Button>}
                    {(runStatus === 'SUCCESS' || runStatus === 'FAILURE') && <Button onClick={onCheckReport}>Check Logs</Button>}
                    {!isRecording ? (
                        <Button icon={<VideoCameraOutlined />} onClick={() => setIsModalVisible(true)}>Record</Button>
                    ) : (
                        <Button danger onClick={stopRecording}>Stop Recording</Button>
                    )}
                    <Button onClick={onRun} disabled={executing || isRecording}>Run</Button>
                    <Button type="primary" icon={<SaveOutlined />} onClick={handleSave}>Save</Button>
                </div>
            </Header>
            <Content style={{ padding: '24px', overflowY: 'auto' }}>
                {targetUrl && (
                    <div style={{ marginBottom: 16, padding: '12px', background: '#f5f5f5', borderRadius: '4px', border: '1px solid #d9d9d9' }}>
                        <span style={{ marginRight: 8, fontWeight: 'bold' }}>Target URL:</span>
                        <a href={targetUrl} target="_blank" rel="noopener noreferrer" style={{ color: '#1890ff' }}>
                            {targetUrl}
                        </a>
                    </div>
                )}
                <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
                    <SortableContext items={steps} strategy={verticalListSortingStrategy}>
                        <List
                            header={<div>Case Steps</div>}
                            footer={<Button type="dashed" onClick={handleAddStep} block icon={<PlusOutlined />}>Add Step</Button>}
                            bordered
                            dataSource={steps}
                            renderItem={(item, index) => (
                                <SortableItem
                                    key={item.id}
                                    id={item.id}
                                    item={item}
                                    index={index}
                                    onChange={handleStepChange}
                                    onDelete={handleDeleteStep}
                                />
                            )}
                        />
                    </SortableContext>
                </DndContext>
            </Content>

            <Drawer
                title="Code Preview (Read Only)"
                placement="right"
                onClose={() => setIsCodeDrawerOpen(false)}
                open={isCodeDrawerOpen}
                width={600}
            >
                <pre style={{ background: '#f5f5f5', padding: '16px', borderRadius: '4px', overflow: 'auto' }}>
                    {previewCode}
                </pre>
            </Drawer>

            <Modal
                title="Start Recording"
                open={isModalVisible}
                onOk={startRecording}
                onCancel={() => setIsModalVisible(false)}
            >
                <p>Enter the URL to test:</p>
                <Input
                    placeholder="https://example.com"
                    value={targetUrl}
                    onChange={e => setTargetUrl(e.target.value)}
                />
            </Modal>
        </Layout>
    );
};
