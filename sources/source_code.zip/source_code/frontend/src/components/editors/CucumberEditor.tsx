import React, { useCallback, useEffect, useState } from 'react';
import ReactFlow, {
    addEdge,
    MiniMap,
    Controls,
    Background,
    useNodesState,
    useEdgesState,
    Connection,
    Edge,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Button, Layout, Typography, message, Modal, Input, Drawer } from 'antd';
import { SaveOutlined, ArrowLeftOutlined } from '@ant-design/icons';
import { nodeTypes } from '@/components/flow/CustomNodes';
const { Header, Content, Sider } = Layout;
const { Title } = Typography;

const initialNodes: Node[] = [];

interface CucumberEditorProps {
    onSave: (contract: string, nameOverride?: string) => void;
    onBack: () => void;
    initialData?: { nodes: any[], edges: any[] };
    executing: boolean;
    onRun: () => void;
    runStatus: string | null;
    onCheckReport: () => void;
    name: string;
    onNameChange: (name: string) => void;
    statusTag?: React.ReactNode;
    onViewReport?: () => void;
    hasReport?: boolean;
}

export const CucumberEditor: React.FC<CucumberEditorProps> = ({ onSave, onBack, initialData, executing, onRun, runStatus, onCheckReport, name, onNameChange, statusTag, onViewReport, hasReport }) => {
    const [nodes, setNodes, onNodesChange] = useNodesState(initialData?.nodes || initialNodes);
    const [edges, setEdges, onEdgesChange] = useEdgesState(initialData?.edges || []);
    const [selectedEdges, setSelectedEdges] = useState<string[]>([]);

    // Dynamic Steps State
    const [stepCategories, setStepCategories] = useState<Record<string, any[]>>({});

    useEffect(() => {
        // Fetch steps from backend
        fetch('/api/steps/by-category')
            .then(res => res.json())
            .then(data => setStepCategories(data))
            .catch(err => console.error("Failed to fetch steps", err));
    }, []);

    // Handle keyboard delete for edges
    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.key === 'Delete' && selectedEdges.length > 0) {
                setEdges((eds) => eds.filter((edge) => !selectedEdges.includes(edge.id)));
                setSelectedEdges([]);
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => window.removeEventListener('keydown', handleKeyDown);
    }, [selectedEdges, setEdges]);

    // Restore onUpdate and onDelete handlers for loaded nodes
    useEffect(() => {
        if (initialData?.nodes && initialData.nodes.length > 0) {
            setNodes((nds) => nds.map(node => {
                if (node.type === 'action') {
                    return {
                        ...node,
                        data: {
                            ...node.data,
                            onUpdate: (field: string, val: any) => {
                                setNodes((currentNodes) => currentNodes.map(n => {
                                    if (n.id === node.id) {
                                        return { ...n, data: { ...n.data, values: { ...n.data.values, [field]: val } } };
                                    }
                                    return n;
                                }));
                            },
                            onDelete: () => {
                                setNodes((currentNodes) => currentNodes.filter(n => n.id !== node.id));
                            }
                        }
                    };
                }
                return node;
            }));
        }
    }, [initialData]);

    // Edit State
    const [isEditModalOpen, setIsEditModalOpen] = useState(false);
    const [editingNode, setEditingNode] = useState<any>(null);
    const [editValue, setEditValue] = useState('');

    const onNodeClick = (event: React.MouseEvent, node: any) => {
        // Only allow editing for basic 'step' nodes, not 'action' nodes (which edit in-place)
        if (node.type === 'step') {
            setEditingNode(node);
            setEditValue(node.data.value);
            setIsEditModalOpen(true);
        }
    };

    const saveNodeChanges = () => {
        if (!editingNode) return;
        setNodes((nds) =>
            nds.map((node) => {
                if (node.id === editingNode.id) {
                    node.data = {
                        ...node.data,
                        value: editValue,
                    };
                }
                return node;
            })
        );
        setIsEditModalOpen(false);
        setEditingNode(null);
    };

    const onConnect = useCallback(
        (params: Edge | Connection) => setEdges((eds) => addEdge(params, eds)),
        [setEdges]
    );

    // Memoized selection change handler to prevent infinite loops
    const handleSelectionChange = useCallback((params: any) => {
        const selectedEdgeIds = params.edges.map((edge: any) => edge.id);
        // Only update if the selection actually changed
        setSelectedEdges((prev) => {
            if (prev.length !== selectedEdgeIds.length ||
                !prev.every((id, idx) => id === selectedEdgeIds[idx])) {
                return selectedEdgeIds;
            }
            return prev;
        });
    }, []);

    const handleSave = () => {
        const contract = JSON.stringify({ nodes, edges });
        onSave(contract);
    };

    const addActionStep = (metadata: any) => {
        const newNode = {
            id: `action-${Date.now()}`,
            type: 'action',
            position: { x: 250, y: nodes.length * 100 + 50 },
            data: {
                metadata,
                values: {}, // Initial empty values 
                onUpdate: (field: string, val: any) => {
                    setNodes((nds) => nds.map(n => {
                        if (n.id === newNode.id) {
                            return { ...n, data: { ...n.data, values: { ...n.data.values, [field]: val } } };
                        }
                        return n;
                    }));
                },
                onDelete: () => {
                    setNodes((nds) => nds.filter(n => n.id !== newNode.id));
                }
            }
        };
        setNodes((nds) => nds.concat(newNode));
    };

    // Code Preview State
    const [isCodeDrawerOpen, setIsCodeDrawerOpen] = useState(false);
    const [previewCode, setPreviewCode] = useState('');

    const generateGherkin = async () => {
        try {
            const res = await fetch('/api/test/preview', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nodes, edges, name })
            });
            const code = await res.text();
            setPreviewCode(code);
            setIsCodeDrawerOpen(true);
        } catch (err) {
            console.error('Failed to generate preview:', err);
            message.error('Failed to generate code preview');
        }
    };

    return (
        <Layout style={{ height: '100vh' }}>
            <Header style={{ background: '#fff', borderBottom: '1px solid #f0f0f0', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 24px' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <Button icon={<ArrowLeftOutlined />} onClick={onBack} />
                    <Title level={4} style={{ margin: 0 }} editable={{
                        onChange: (val) => {
                            onNameChange(val);
                        }
                    }}>{name}</Title>
                    {statusTag}
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                    <Button onClick={generateGherkin}>View Code</Button>
                    {hasReport && <Button onClick={onViewReport}>View Report</Button>}
                    {(runStatus === 'SUCCESS' || runStatus === 'FAILURE') && <Button onClick={onCheckReport}>Check Logs</Button>}
                    <Button onClick={onRun} disabled={executing}>Run</Button>
                    <Button type="primary" icon={<SaveOutlined />} onClick={handleSave}>Save</Button>
                </div>
            </Header>
            <Layout>
                <Sider width={250} style={{ background: '#fff', padding: '16px', borderRight: '1px solid #f0f0f0', overflowY: 'auto' }}>
                    <Title level={5}>Toolbox</Title>

                    {Object.entries(stepCategories).map(([category, steps]) => (
                        <div key={category} style={{ marginBottom: 16 }}>
                            <Title level={5} style={{ fontSize: 14, color: '#666', marginBottom: 8 }}>{category}</Title>
                            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                                {steps.map((step: any) => (
                                    <Button key={step.key} onClick={() => addActionStep(step)} style={{ textAlign: 'left', height: 'auto', whiteSpace: 'normal' }}>
                                        {step.name}
                                    </Button>
                                ))}
                            </div>
                        </div>
                    ))}

                    {Object.keys(stepCategories).length === 0 && <p>Loading steps...</p>}

                </Sider>
                <Content style={{ height: 'calc(100vh - 64px)' }}>
                    <ReactFlow
                        nodes={nodes}
                        edges={edges}
                        onNodesChange={onNodesChange}
                        onEdgesChange={onEdgesChange}
                        onConnect={onConnect}
                        onNodeClick={onNodeClick}
                        onSelectionChange={handleSelectionChange}
                        nodeTypes={nodeTypes}
                        fitView
                    >
                        <Controls />
                        <MiniMap />
                        <Background gap={12} size={1} />
                    </ReactFlow>
                </Content>
            </Layout>
            <Drawer
                title="Code Preview (Read Only)"
                placement="right"
                onClose={() => setIsCodeDrawerOpen(false)}
                open={isCodeDrawerOpen}
                width={500}
            >
                <pre style={{ background: '#f5f5f5', padding: '16px', borderRadius: '4px', overflow: 'auto' }}>
                    {previewCode}
                </pre>
            </Drawer>
            <Modal
                title="Edit Step"
                open={isEditModalOpen}
                onOk={saveNodeChanges}
                onCancel={() => setIsEditModalOpen(false)}
            >
                <div style={{ marginBottom: 16 }}>
                    <label>Step Type:</label>
                    <Input value={editingNode?.data.type} disabled />
                </div>
                <div>
                    <label>Step Value:</label>
                    <Input
                        value={editValue}
                        onChange={(e) => setEditValue(e.target.value)}
                        onPressEnter={saveNodeChanges}
                    />
                </div>
            </Modal>
        </Layout>
    );
};
