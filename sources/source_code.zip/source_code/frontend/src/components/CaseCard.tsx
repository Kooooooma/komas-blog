'use client';

import React from 'react';
import { Card, Tag, Button, Tooltip } from 'antd';
import { EyeOutlined, CloseOutlined } from '@ant-design/icons';

interface CaseCardProps {
    id: string;
    mappingId: string;
    name: string;
    type: string;
    workspaceName?: string;
    lastExecutionStatus?: string;
    onRemove: (mappingId: string) => void;
    onViewDetails: (caseId: string) => void;
}

/**
 * Case 卡片组件 - 显示在泳道内的单个 Case
 */
export const CaseCard: React.FC<CaseCardProps> = ({
    id,
    mappingId,
    name,
    type,
    workspaceName,
    lastExecutionStatus,
    onRemove,
    onViewDetails,
}) => {
    const getStatusColor = () => {
        switch (lastExecutionStatus) {
            case 'SUCCESS': return '#52c41a';
            case 'FAILURE': return '#f5222d';
            case 'RUNNING': return '#1890ff';
            default: return '#d9d9d9';
        }
    };

    const getStatusBg = () => {
        switch (lastExecutionStatus) {
            case 'SUCCESS': return '#f6ffed';
            case 'FAILURE': return '#fff1f0';
            case 'RUNNING': return '#e6f7ff';
            default: return '#fafafa';
        }
    };

    return (
        <Card
            size="small"
            style={{
                width: 180,
                minWidth: 180,
                backgroundColor: getStatusBg(),
                borderColor: getStatusColor(),
                borderWidth: 2,
                cursor: 'grab',
            }}
            bodyStyle={{ padding: 12 }}
        >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 8 }}>
                <Tooltip title={name}>
                    <div style={{ fontWeight: 500, fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', maxWidth: 110 }}>
                        {name}
                    </div>
                </Tooltip>
                <Button
                    type="text"
                    size="small"
                    danger
                    icon={<CloseOutlined />}
                    onClick={(e) => { e.stopPropagation(); onRemove(mappingId); }}
                    style={{ padding: 0, width: 20, height: 20 }}
                />
            </div>

            <div style={{ marginBottom: 8 }}>
                <Tag color={type === 'CUCUMBER' ? 'green' : 'blue'} style={{ fontSize: 10 }}>
                    {type}
                </Tag>
            </div>

            {workspaceName && (
                <div style={{ fontSize: 11, color: '#999', marginBottom: 8, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                    from: {workspaceName}
                </div>
            )}

            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Tag color={getStatusColor()} style={{ margin: 0, fontSize: 10 }}>
                    {lastExecutionStatus || 'N/A'}
                </Tag>
                <Button
                    type="link"
                    size="small"
                    icon={<EyeOutlined />}
                    onClick={(e) => { e.stopPropagation(); onViewDetails(id); }}
                    style={{ padding: 0, fontSize: 12 }}
                >
                    View
                </Button>
            </div>
        </Card>
    );
};

export default CaseCard;
