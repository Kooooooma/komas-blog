'use client';

import React, { useEffect, useState, useCallback } from 'react';
import { Button, message, Empty, Spin } from 'antd';
import { PlusOutlined, PlayCircleOutlined, BarChartOutlined } from '@ant-design/icons';
import { useRouter } from 'next/navigation';
import { SwimLane } from './SwimLane';
import { LaneStatistics } from './LaneStatistics';

interface Lane {
    id: string;
    name: string;
    orderIndex: number;
    lastExecutionStatus?: string;
    cases: {
        mappingId: string;
        testCaseId: string;
        name: string;
        type: string;
        workspaceId: string;
        orderIndex: number;
        lastExecutionStatus?: string;
    }[];
}

interface AvailableWorkspace {
    workspaceId: string;
    workspaceName: string;
    cases: { id: string; name: string; type: string }[];
}

interface Stats {
    totalLanes: number;
    totalCases: number;
    successCases: number;
    failedCases: number;
    pendingCases: number;
    successRate: number;
    lanes: any[];
}

interface OrchestrationWorkspaceProps {
    workspaceId: string;
    workspaceName: string;
    userId: string;
}

/**
 * 编排 Workspace 主页面组件
 * 显示泳道列表，支持添加/删除泳道，执行所有泳道
 */
export const OrchestrationWorkspace: React.FC<OrchestrationWorkspaceProps> = ({
    workspaceId,
    workspaceName,
    userId,
}) => {
    const router = useRouter();
    const [lanes, setLanes] = useState<Lane[]>([]);
    const [loading, setLoading] = useState(true);
    const [showStats, setShowStats] = useState(false);
    const [stats, setStats] = useState<Stats | null>(null);
    const [availableCases, setAvailableCases] = useState<AvailableWorkspace[]>([]);
    const [isRunning, setIsRunning] = useState(false);

    // 获取泳道列表
    const fetchLanes = useCallback(async () => {
        try {
            const res = await fetch(`http://localhost:3300/api/lane/workspace/${workspaceId}`);
            if (res.ok) {
                const data = await res.json();
                setLanes(data);
            }
        } catch (err) {
            console.error('Failed to fetch lanes:', err);
        } finally {
            setLoading(false);
        }
    }, [workspaceId]);

    // 获取可用的标准 Workspace 及其 Cases
    const fetchAvailableCases = useCallback(async () => {
        try {
            // 获取用户的所有 Workspaces
            const wsRes = await fetch(`http://localhost:3300/api/workspace/user/${userId}`);
            if (wsRes.ok) {
                const workspaces = await wsRes.json();
                // 过滤只选择标准类型的 Workspace
                const standardWorkspaces = workspaces.filter((w: any) => w.type === 'STANDARD' || !w.type);

                // 获取每个 Workspace 的 Cases
                const casesPromises = standardWorkspaces.map(async (ws: any) => {
                    const casesRes = await fetch(`http://localhost:3300/api/workspace/${ws.id}`);
                    if (casesRes.ok) {
                        const cases = await casesRes.json();
                        return {
                            workspaceId: ws.id,
                            workspaceName: ws.name,
                            cases: cases.map((c: any) => ({ id: c.id, name: c.name, type: c.type })),
                        };
                    }
                    return { workspaceId: ws.id, workspaceName: ws.name, cases: [] };
                });

                const results = await Promise.all(casesPromises);
                setAvailableCases(results.filter(r => r.cases.length > 0));
            }
        } catch (err) {
            console.error('Failed to fetch available cases:', err);
        }
    }, [userId]);

    // 获取统计数据
    const fetchStats = async () => {
        try {
            const res = await fetch(`http://localhost:3300/api/orchestration/workspace/${workspaceId}/status`);
            if (res.ok) {
                const data = await res.json();
                setStats(data);
            }
        } catch (err) {
            console.error('Failed to fetch stats:', err);
        }
    };

    useEffect(() => {
        fetchLanes();
        fetchAvailableCases();
    }, [fetchLanes, fetchAvailableCases]);

    // 创建新泳道
    const handleCreateLane = async () => {
        try {
            const res = await fetch('http://localhost:3300/api/lane', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ workspaceId, name: `Lane ${lanes.length + 1}` }),
            });
            if (res.ok) {
                message.success('Lane created');
                fetchLanes();
            }
        } catch (err) {
            message.error('Failed to create lane');
        }
    };

    // 更新泳道名称
    const handleLaneNameChange = async (laneId: string, name: string) => {
        try {
            const res = await fetch(`http://localhost:3300/api/lane/${laneId}/name`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ name }),
            });
            if (res.ok) {
                message.success('Lane renamed');
                fetchLanes();
            }
        } catch (err) {
            message.error('Failed to rename lane');
        }
    };

    // 删除泳道
    const handleDeleteLane = async (laneId: string) => {
        try {
            const res = await fetch(`http://localhost:3300/api/lane/${laneId}`, {
                method: 'DELETE',
            });
            if (res.ok) {
                message.success('Lane deleted');
                fetchLanes();
            }
        } catch (err) {
            message.error('Failed to delete lane');
        }
    };

    // 添加 Case 到泳道
    const handleAddCase = async (laneId: string, testCaseId: string) => {
        try {
            const res = await fetch(`http://localhost:3300/api/lane/${laneId}/case`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ testCaseId }),
            });
            if (res.ok) {
                message.success('Case added');
                fetchLanes();
            }
        } catch (err) {
            message.error('Failed to add case');
        }
    };

    // 从泳道移除 Case
    const handleRemoveCase = async (laneId: string, mappingId: string) => {
        try {
            const res = await fetch(`http://localhost:3300/api/lane/${laneId}/case/${mappingId}`, {
                method: 'DELETE',
            });
            if (res.ok) {
                message.success('Case removed');
                fetchLanes();
            }
        } catch (err) {
            message.error('Failed to remove case');
        }
    };

    // 重排泳道内 Case 顺序
    const handleReorderCases = async (laneId: string, orderedMappings: { mappingId: string }[]) => {
        try {
            const res = await fetch(`http://localhost:3300/api/lane/${laneId}/case/reorder`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(orderedMappings),
            });
            if (res.ok) {
                fetchLanes();
            }
        } catch (err) {
            message.error('Failed to reorder cases');
        }
    };

    // 执行单个泳道
    const handleRunLane = async (laneId: string) => {
        try {
            const res = await fetch(`http://localhost:3300/api/orchestration/lane/${laneId}/run`, {
                method: 'POST',
            });
            if (res.ok) {
                message.success('Lane execution started');
                // 定期刷新状态
                const interval = setInterval(() => fetchLanes(), 2000);
                setTimeout(() => clearInterval(interval), 60000); // 最多轮询1分钟
            }
        } catch (err) {
            message.error('Failed to run lane');
        }
    };

    // 执行所有泳道
    const handleRunAll = async () => {
        setIsRunning(true);
        try {
            const res = await fetch(`http://localhost:3300/api/orchestration/workspace/${workspaceId}/run`, {
                method: 'POST',
            });
            if (res.ok) {
                message.success('All lanes execution started');
                // 定期刷新状态
                const interval = setInterval(() => {
                    fetchLanes();
                    fetchStats();
                }, 2000);
                setTimeout(() => {
                    clearInterval(interval);
                    setIsRunning(false);
                }, 120000); // 最多轮询2分钟
            }
        } catch (err) {
            message.error('Failed to run all lanes');
            setIsRunning(false);
        }
    };

    // 查看 Case 详情
    const handleViewCaseDetails = (caseId: string) => {
        router.push(`/editor/${caseId}`);
    };

    // 切换统计面板
    const toggleStats = () => {
        if (!showStats) {
            fetchStats();
        }
        setShowStats(!showStats);
    };

    if (loading) {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: 400 }}>
                <Spin size="large" />
            </div>
        );
    }

    return (
        <div>
            {/* 头部操作区 */}
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <h2 style={{ margin: 0 }}>{workspaceName}</h2>
                    <span style={{ color: '#999' }}>Orchestration Workspace</span>
                </div>
                <div style={{ display: 'flex', gap: 8 }}>
                    <Button
                        icon={<BarChartOutlined />}
                        onClick={toggleStats}
                    >
                        {showStats ? 'Hide Stats' : 'Show Stats'}
                    </Button>
                    <Button
                        type="primary"
                        icon={<PlayCircleOutlined />}
                        onClick={handleRunAll}
                        disabled={lanes.length === 0 || isRunning}
                        loading={isRunning}
                    >
                        Run All Lanes
                    </Button>
                    <Button
                        icon={<PlusOutlined />}
                        onClick={handleCreateLane}
                    >
                        Add Lane
                    </Button>
                </div>
            </div>

            {/* 统计面板 */}
            {showStats && stats && (
                <LaneStatistics
                    totalLanes={stats.totalLanes}
                    totalCases={stats.totalCases}
                    successCases={stats.successCases}
                    failedCases={stats.failedCases}
                    pendingCases={stats.pendingCases}
                    successRate={stats.successRate}
                    lanes={stats.lanes}
                />
            )}

            {/* 泳道列表 */}
            {lanes.length === 0 ? (
                <Empty
                    description="No lanes yet. Click 'Add Lane' to create one."
                    style={{ marginTop: 100 }}
                >
                    <Button type="primary" icon={<PlusOutlined />} onClick={handleCreateLane}>
                        Create First Lane
                    </Button>
                </Empty>
            ) : (
                lanes.map(lane => (
                    <SwimLane
                        key={lane.id}
                        id={lane.id}
                        name={lane.name}
                        cases={lane.cases.map(c => ({
                            ...c,
                            workspaceName: availableCases.find(w => w.cases.some(wc => wc.id === c.testCaseId))?.workspaceName,
                        }))}
                        lastExecutionStatus={lane.lastExecutionStatus}
                        standardWorkspaces={availableCases.map(w => ({ id: w.workspaceId, name: w.workspaceName }))}
                        onNameChange={handleLaneNameChange}
                        onDelete={handleDeleteLane}
                        onAddCase={handleAddCase}
                        onRemoveCase={handleRemoveCase}
                        onReorderCases={handleReorderCases}
                        onRunLane={handleRunLane}
                        onViewCaseDetails={handleViewCaseDetails}
                        availableCases={availableCases}
                    />
                ))
            )}

            <div style={{ marginTop: 20, color: '#999' }}>
                Workspace ID: {workspaceId}
            </div>
        </div>
    );
};

export default OrchestrationWorkspace;
