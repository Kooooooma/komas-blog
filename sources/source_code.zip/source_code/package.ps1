# Check for required tools
if (-not (Get-Command mvn -ErrorAction SilentlyContinue)) {
    Write-Error "Maven (mvn) is not installed or not in PATH."
    exit 1
}
if (-not (Get-Command npm -ErrorAction SilentlyContinue)) {
    Write-Error "NPM is not installed or not in PATH."
    exit 1
}

$RootDir = Get-Location
$DistDir = Join-Path $RootDir "dist"

# 1. Prepare Dist Directory
Write-Host "Cleaning dist directory..." -ForegroundColor Cyan
if (Test-Path $DistDir) {
    Remove-Item $DistDir -Recurse -Force
}
New-Item -ItemType Directory -Path $DistDir | Out-Null

# 2. Build Backend
Write-Host "Building Backend..." -ForegroundColor Cyan
Set-Location "backend"
cmd /c "mvn clean package -DskipTests"
if ($LASTEXITCODE -ne 0) { Write-Error "Backend build failed"; exit 1 }

$BackendDist = Join-Path $DistDir "backend"
New-Item -ItemType Directory -Path $BackendDist | Out-Null
Copy-Item "target/*.jar" $BackendDist
Set-Location $RootDir

# 3. Build Frontend
Write-Host "Building Frontend..." -ForegroundColor Cyan
Set-Location "frontend"
cmd /c "npm install"
cmd /c "npm run build"
if ($LASTEXITCODE -ne 0) { Write-Error "Frontend build failed"; exit 1 }

$FrontendDist = Join-Path $DistDir "frontend"
New-Item -ItemType Directory -Path $FrontendDist | Out-Null
# Next.js standalone build requires copying public and static files manually
# Structure: dist/frontend (files from .next/standalone)
#            dist/frontend/public (from public)
#            dist/frontend/.next/static (from .next/static)

Write-Host "Copying Frontend artifacts..." -ForegroundColor Cyan
# Copy standalone build as the base
Copy-Item -Path ".next/standalone/*" -Destination $FrontendDist -Recurse

# ... (rest of frontend copy) ...

# Copy public folder
$PublicDest = Join-Path $FrontendDist "public"
New-Item -ItemType Directory -Path $PublicDest -Force | Out-Null
Copy-Item -Path "public/*" -Destination $PublicDest -Recurse

# Copy .next/static folder
$StaticDest = Join-Path $FrontendDist ".next/static"
New-Item -ItemType Directory -Path $StaticDest -Force | Out-Null
Copy-Item -Path ".next/static/*" -Destination $StaticDest -Recurse

Set-Location $RootDir

# 4. Package Bridge
Write-Host "Packaging Bridge..." -ForegroundColor Cyan
$BridgeDist = Join-Path $DistDir "bridge"
New-Item -ItemType Directory -Path $BridgeDist | Out-Null
# Copy bridge files excluding node_modules
Get-ChildItem "bridge" -Exclude "node_modules",".git","cypress/videos","cypress/screenshots" | Copy-Item -Destination $BridgeDist -Recurse

# Install production dependencies for bridge
Set-Location $BridgeDist
cmd /c "npm install --omit=dev"
Set-Location $RootDir

# 5. Package Extension
Write-Host "Packaging Extension..." -ForegroundColor Cyan
$ExtensionDist = Join-Path $DistDir "extension"
New-Item -ItemType Directory -Path $ExtensionDist | Out-Null
Copy-Item -Path "extension/*" -Destination $ExtensionDist -Recurse

# 6. Create Start Script
Write-Host "Creating Start Script..." -ForegroundColor Cyan
$StartScriptContent = @"
@echo off
setlocal

echo Starting AT Platform...

:: 1. Start Backend (in new window)
echo Starting Backend...
start "AT Platform Backend" java -jar backend\at-platform-0.0.1-SNAPSHOT.jar

:: Wait a bit for backend to initialize (optional, but good practice)
timeout /t 5 /nobreak >nul

:: 2. Start Bridge (in new window)
echo Starting Bridge...
cd bridge
start "AT Platform Bridge" node bridge.js
cd ..

:: 3. Start Frontend (in new window)
echo Starting Frontend...
cd frontend
:: The standalone server is usually node server.js
set PORT=3301
start "AT Platform Frontend" node server.js
cd ..

echo All services started!
echo Backend: JAR running
echo Bridge: Node process running
echo Frontend: Node process running (Port 3301)
echo.
echo Please load the Extension manually in your browser from the 'extension' folder.
echo.
pause
"@

$StartScriptPath = Join-Path $DistDir "start-all.bat"
Set-Content -Path $StartScriptPath -Value $StartScriptContent

# 7. Create README
Write-Host "Creating README..." -ForegroundColor Cyan
$ReadmeContent = @"
# AT Platform Distribution

This folder contains the packaged version of the AT Platform.

## Contents
- **backend/**: The Java Spring Boot backend (JAR file).
- **frontend/**: The Next.js frontend application (Node.js standalone build).
- **bridge/**: The Node.js bridge service.
- **extension/**: The Browser Extension source code.

## Prerequisites
- **Java 17+**: Required to run the backend.
- **Node.js 18+**: Required to run the frontend and bridge.
- **Browser**: Chrome or Edge (to load the extension).

## How to Start
1. Double-click **start-all.bat**.
   - This will open separate command windows for the Backend, Bridge, and Frontend.
   - Wait for all services to start.
   - Access the Frontend at **http://localhost:3301**.

## How to Use the Extension
1. Open Chrome or Edge.
2. Go to \`chrome://extensions\` or \`edge://extensions\`.
3. Enable **Developer mode** (toggle in top right corner).
4. Click **Load unpacked**.
5. Select the **extension** folder inside this directory.

## Troubleshooting
- If the frontend fails to start, ensure Node.js is installed and accessible in your PATH.
- If the backend fails, ensure Java is installed. Check the backend console window for errors.
- Ensure ports 3300 (Backend), 3301 (Frontend), and 3302 (Bridge/API) are free.
"@

$ReadmePath = Join-Path $DistDir "README.md"
Set-Content -Path $ReadmePath -Value $ReadmeContent

Write-Host "Packaging Complete! Output in $DistDir" -ForegroundColor Green
