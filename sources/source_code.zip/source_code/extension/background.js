let isRecording = false;
let editorTabId = null;
let targetTabIds = new Set(); // Track all target pages (can be multiple tabs)
let targetUrl = ''; // The target URL being recorded
const editorTabIds = new Set(); // Track tabs that are confirmed Cypress Editors

// Initialize badge to show inactive state
chrome.action.setBadgeText({ text: '' });
chrome.action.setBadgeBackgroundColor({ color: '#8c8c8c' });

// Helper function to check if a URL matches the target
function urlMatchesTarget(url) {
    if (!targetUrl || !url) return false;

    try {
        const targetUrlObj = new URL(targetUrl);
        const currentUrlObj = new URL(url);

        // Match by origin (protocol + host + port)
        return targetUrlObj.origin === currentUrlObj.origin;
    } catch (e) {
        // Fallback to simple string comparison
        return url.includes(targetUrl) || targetUrl.includes(url);
    }
}

// Function to update badge based on URL and recording state
function updateBadgeForTab(tabId, url) {
    // Check if this is a known editor page (confirmed by content script)
    const isEditorPage = editorTabIds.has(tabId);

    // Check if this is a target recording tab
    const isTargetTab = targetTabIds.has(tabId) || (isRecording && urlMatchesTarget(url) && tabId !== editorTabId);

    // Badge should be green if it's editor page or a target tab
    const shouldBeActive = isEditorPage || isTargetTab;

    if (shouldBeActive) {
        chrome.action.setBadgeText({ tabId: tabId, text: '●' });
        chrome.action.setBadgeBackgroundColor({ tabId: tabId, color: '#52c41a' });
    } else {
        chrome.action.setBadgeText({ tabId: tabId, text: '' });
    }
}

// Listen for tab updates to set badge status
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    // If page is loading, clear editor status until confirmed again by content script
    if (changeInfo.status === 'loading') {
        editorTabIds.delete(tabId);
        // Also clear target status potentially, but usually we re-check on complete
        updateBadgeForTab(tabId, tab ? tab.url : '');
    }

    if (changeInfo.status === 'complete' && tab.url) {
        updateBadgeForTab(tabId, tab.url);

        // Check if this newly loaded page is our target
        if (isRecording && urlMatchesTarget(tab.url) && tabId !== editorTabId) {
            if (!targetTabIds.has(tabId)) {
                targetTabIds.add(tabId);
                updateBadgeForTab(tabId, tab.url);
                console.log('Target page loaded:', tabId, tab.url);

                // Notify the content script that it's the target
                chrome.tabs.sendMessage(tabId, {
                    type: 'RECORDING_STARTED'
                }).catch(() => { });
            }
        }
    }
});

// Listen for tab activation to update badge
chrome.tabs.onActivated.addListener((activeInfo) => {
    chrome.tabs.get(activeInfo.tabId, (tab) => {
        if (tab.url) {
            updateBadgeForTab(activeInfo.tabId, tab.url);
        }
    });
});

// Listen for messages from content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'PAGE_ACTIVATED') {
        // Editor page activated (detected marker)
        if (sender.tab) {
            editorTabIds.add(sender.tab.id);
            chrome.action.setBadgeText({ tabId: sender.tab.id, text: '●' });
            chrome.action.setBadgeBackgroundColor({ tabId: sender.tab.id, color: '#52c41a' });
        }
    }
    else if (request.type === 'PAGE_DEACTIVATED') {
        // Page deactivated
        if (sender.tab) {
            editorTabIds.delete(sender.tab.id);
            chrome.action.setBadgeText({ tabId: sender.tab.id, text: '' });
        }
    }
    else if (request.type === 'START_RECORDING') {
        isRecording = true;
        editorTabId = sender.tab.id;
        // Ensure this tab is marked as editor
        editorTabIds.add(editorTabId);

        targetUrl = request.targetUrl || '';
        targetTabIds.clear(); // Clear previous target tabs

        console.log('Recording started. Editor Tab ID:', editorTabId, 'Target URL:', targetUrl);

        // Set editor tab badge
        chrome.action.setBadgeText({ tabId: editorTabId, text: '●' });
        chrome.action.setBadgeBackgroundColor({ tabId: editorTabId, color: '#52c41a' });

        // Find and mark any already-open tabs that match the target URL
        chrome.tabs.query({}, (tabs) => {
            tabs.forEach(tab => {
                if (tab.id !== editorTabId && tab.url && urlMatchesTarget(tab.url)) {
                    targetTabIds.add(tab.id);
                    updateBadgeForTab(tab.id, tab.url);

                    // Notify the tab it's now a target
                    chrome.tabs.sendMessage(tab.id, {
                        type: 'RECORDING_STARTED'
                    }).catch(() => { });
                }
            });
        });
    }
    else if (request.type === 'STOP_RECORDING') {
        isRecording = false;

        // Reset all target tab badges
        targetTabIds.forEach(tabId => {
            chrome.tabs.get(tabId, (tab) => {
                if (tab && tab.url) {
                    chrome.action.setBadgeText({ tabId: tabId, text: '' });
                }
            });

            // Notify tabs recording has stopped
            chrome.tabs.sendMessage(tabId, {
                type: 'RECORDING_STOPPED'
            }).catch(() => { });
        });

        // Editor tab badge remains active (green) because it's still the editor
        if (editorTabId) {
            chrome.tabs.get(editorTabId, (tab) => {
                if (tab && tab.url) {
                    updateBadgeForTab(editorTabId, tab.url);
                }
            });
        }

        targetTabIds.clear();
        targetUrl = '';
        editorTabId = null;
        console.log('Recording stopped.');
    }
    else if (request.type === 'TARGET_PAGE_READY') {
        // Target page content script is ready
        if (isRecording && sender.tab && urlMatchesTarget(sender.tab.url)) {
            targetTabIds.add(sender.tab.id);
            updateBadgeForTab(sender.tab.id, sender.tab.url);
        }
    }
    else if (request.type === 'RECORD_STEP') {
        // Only process if recording is active
        if (isRecording && editorTabId) {
            // Ignore events from the editor tab itself
            if (sender.tab.id !== editorTabId) {
                // Verify this is a target tab
                if (urlMatchesTarget(sender.tab.url)) {
                    // Add this tab to target tabs
                    if (!targetTabIds.has(sender.tab.id)) {
                        targetTabIds.add(sender.tab.id);
                        updateBadgeForTab(sender.tab.id, sender.tab.url);
                        console.log('New target tab confirmed:', sender.tab.id);
                    }

                    // Send step to editor tab
                    chrome.tabs.sendMessage(editorTabId, {
                        type: 'NEW_STEP',
                        step: request.step
                    }).catch(err => {
                        console.error('Failed to send step to editor:', err);
                    });
                }
            }
        }
    }
    else if (request.type === 'CHECK_IF_TARGET') {
        // Content script asks if its page is the target
        const isTarget = isRecording && urlMatchesTarget(request.url);
        sendResponse({ isTarget: isTarget });
        return true;
    }
    else if (request.type === 'GET_STATUS') {
        // Popup requests current status
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const currentTab = tabs[0];
            const isCurrentTabTarget = targetTabIds.has(currentTab.id) ||
                (isRecording && urlMatchesTarget(currentTab.url) && currentTab.id !== editorTabId);
            const isCurrentTabEditor = editorTabIds.has(currentTab.id);

            sendResponse({
                isRecording: isRecording,
                isTargetTab: isCurrentTabTarget,
                isEditorTab: isCurrentTabEditor,
                targetUrl: targetUrl
            });
        });
        return true;
    }
});
