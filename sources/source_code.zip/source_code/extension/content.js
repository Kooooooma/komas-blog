// Recording state
let isRecording = false;

// Config
const URL_PATTERN_EDITOR = /^http:\/\/(localhost|127\.0\.0\.1):3301\/editor\//;
const URL_PATTERN_APP = /^http:\/\/(localhost|127\.0\.0\.1):3301/;

// Helper to generate selector
// Helper to generate selector using the Finder library
function getSelector(element) {
    if (window.finder) {
        try {
            return window.finder(element, {
                root: document.body,
                idName: (name) => true,
                className: (name) => true,
                tagName: (name) => true,
                attr: (name, value) => {
                    // Prioritize stable attributes suitable for testing
                    // data-* attributes are best, followed by form names and placeholders
                    return ['data-testid', 'data-cy', 'data-test', 'data-qa', 'name', 'placeholder', 'aria-label'].includes(name);
                },
                seedMinLength: 1,
                optimizedMinLength: 2
            });
        } catch (e) {
            console.error('[AT Recorder] Finder failed, falling back to simple tag', e);
        }
    }

    // Fallback if finder not loaded or fails
    if (element.id) return `#${element.id}`;
    return element.tagName.toLowerCase();
}

// Logic to check if this is the Cypress editor via hidden marker
function checkEditorMarker() {
    const marker = document.getElementById('at-editor-marker');
    return marker && marker.getAttribute('data-type') === 'CYPRESS';
}

// State tracking to prevent duplicate listeners
let isEditorInitialized = false;
let areRecordingListenersAttached = false;

function initEditorPage() {
    console.log('[AT Platform Recorder] Editor init message received');

    // ALWAYS notify background (needed for SPA navigation cases)
    chrome.runtime.sendMessage({ type: 'PAGE_ACTIVATED' });

    if (isEditorInitialized) return;
    isEditorInitialized = true;

    // Listen for messages from Web Page
    window.addEventListener('message', (event) => {
        if (event.source !== window) return;

        if (event.data.type === 'AT_START_RECORDING') {
            isRecording = true;
            chrome.runtime.sendMessage({
                type: 'START_RECORDING',
                targetUrl: event.data.targetUrl || ''
            });
        } else if (event.data.type === 'AT_STOP_RECORDING') {
            isRecording = false;
            chrome.runtime.sendMessage({ type: 'STOP_RECORDING' });
        }
    }, false);

    // Listen for recorded steps to forward to UI
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.type === 'NEW_STEP') {
            window.postMessage({ type: 'AT_NEW_STEP', step: request.step }, '*');
        }
    });
}

function initTargetPage() {
    // Only init if not already recording or if we suspect this might be a target
    // We can just rely on the background check which happens anyway
    console.log('[AT Platform Recorder] Content script loaded on potential target page');

    setupRecordingListeners();

    // Query if this page is target
    chrome.runtime.sendMessage({
        type: 'CHECK_IF_TARGET',
        url: window.location.href
    }, (response) => {
        if (response && response.isTarget) {
            isRecording = true;
            console.log('[AT Platform Recorder] This page is the recording target');
            chrome.runtime.sendMessage({ type: 'TARGET_PAGE_READY' });
        }
    });

    // Listen for recording state
    // Note: It's safe to add this multiple times? NO.
    // Ideally we should guard this too, but chrome.runtime listeners are usually additive.
    // Let's guard it with a flag as well essentially via the execution flow,
    // but better to be explicit if this function is called multiple times.
    // However, initTargetPage is called at top level once per load.

    // Actually, let's wrap this listener in a check too just in case.
    if (!areRecordingListenersAttached) {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.type === 'RECORDING_STARTED') {
                isRecording = true;
                console.log('[AT Platform Recorder] Recording started on this page');
            } else if (request.type === 'RECORDING_STOPPED') {
                isRecording = false;
                console.log('[AT Platform Recorder] Recording stopped on this page');
            }
        });
    }
}

function setupRecordingListeners() {
    if (areRecordingListenersAttached) return;
    areRecordingListenersAttached = true;

    document.addEventListener('click', (event) => {
        if (!isRecording) return;
        const step = {
            type: 'CLICK',
            selector: getSelector(event.target),
            value: event.target.innerText || ''
        };
        chrome.runtime.sendMessage({ type: 'RECORD_STEP', step });
    }, true);

    document.addEventListener('change', (event) => {
        if (!isRecording) return;
        const step = {
            type: 'TYPE',
            selector: getSelector(event.target),
            value: event.target.value
        };
        chrome.runtime.sendMessage({ type: 'RECORD_STEP', step });
    }, true);

    console.log('[AT Platform Recorder] Recording listeners attached');
}

// Main Initialization Logic
const currentUrl = window.location.href;

// 1. Listen for Editor Init Message
window.addEventListener('message', (event) => {
    if (event.source !== window) return;

    if (event.data.type === 'AT_EXTENSION_INIT' && event.data.editorType === 'CYPRESS') {
        initEditorPage();
    }
    // New: Handle deactivation signal from frontend (e.g. unmount)
    else if (event.data.type === 'AT_EXTENSION_DEACTIVATE') {
        console.log('[AT Platform Recorder] Deactivation message received');
        chrome.runtime.sendMessage({ type: 'PAGE_DEACTIVATED' });
    }
});

// 2. Check if this is a target page
if (URL_PATTERN_APP.test(currentUrl) && !currentUrl.includes('/editor/')) {
    // It's the app but not editor (e.g. dashboard)
    // We can ignore or explicitly deactivate, but generally we just don't send init
    console.log('[AT Platform Recorder] App page (non-editor)');
} else {
    // Could be target OR editor (before we know it)
    // IMPORTANT: If this IS the editor, we don't want to run initTargetPage logic
    // which adds listeners that might conflict or just trigger unnecessarily.
    // But since we removed strict URL patterns for generic target support,
    // we must ensure we don't add "target" logic if we become "editor".
    // However, current logic just runs initTargetPage immediately.

    // Mitigation: If it is the editor, isRecording will likely be false locally until set true.
    // But better to separate concerns.

    // For now, adding the flags prevents the critical "double click" issue on target pages
    // and double "NEW_STEP" issue on editor pages.
    initTargetPage();
}
