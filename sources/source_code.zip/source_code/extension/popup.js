// Query current tab and display unified status
chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    const currentTab = tabs[0];
    const url = currentTab.url || '';

    const statusEl = document.getElementById('status');
    const statusTextEl = document.getElementById('statusText');
    const infoTextEl = document.getElementById('infoText');

    // Query recording status from background
    chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (response) => {
        if (!response) {
            // Fallback if no response
            statusEl.className = 'status-indicator status-inactive';
            statusTextEl.textContent = 'Inactive';
            infoTextEl.textContent = 'Extension is inactive on this page.';
            return;
        }

        const isTargetTab = response.isTargetTab;
        const isRecording = response.isRecording;
        // Use the strict editor check from background
        const isEditorTab = response.isEditorTab;

        // Determine overall status
        if (isEditorTab) {
            statusEl.className = 'status-indicator status-active';
            statusTextEl.textContent = 'Active (Editor)';
            if (isRecording) {
                infoTextEl.textContent = `Recording in progress. Target: ${response.targetUrl || 'Not set'}`;
            } else {
                infoTextEl.textContent = 'Editor page detected. Click "Record" to start.';
            }
        } else if (isTargetTab) {
            statusEl.className = 'status-indicator status-active';
            statusTextEl.textContent = 'Active (Target)';
            infoTextEl.textContent = 'This is the recording target page. Your actions are being captured.';
        } else {
            statusEl.className = 'status-indicator status-inactive';
            statusTextEl.textContent = 'Inactive';
            infoTextEl.textContent = 'Extension is inactive on this page.';
        }
    });
});
