"use client";

import { Card, Flex, Typography, Button, Spin, Empty, Modal, message } from "antd";
import { DeleteOutlined, HighlightOutlined, ExclamationCircleOutlined } from '@ant-design/icons';
import { PackagePlus } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useCommonStore } from '@/store/commonStore';
import { useEffect, useState } from 'react';
import { getTestCasesByWorkspace, deleteTestCase } from '@/libs/edit';

interface LastExecution {
    id: string;
    status: string;
    startTime: string;
    endTime: string;
}

interface TestCaseData {
    id: string;
    name: string;
    type: string;
    workspaceId: string;
    lastUpdateTime: string;
}

interface TestCaseItem {
    lastExecution?: LastExecution;
    case: TestCaseData;
}

export default function StandardWorkspace() {
    const { Text } = Typography;
    const router = useRouter();
    const { workspaceId } = useCommonStore();
    const [modal, modalContextHolder] = Modal.useModal();
    const [messageApi, messageContextHolder] = message.useMessage();

    const [testCases, setTestCases] = useState<TestCaseItem[]>([]);
    const [isLoading, setIsLoading] = useState(false);

    const loadTestCases = async () => {
        if (!workspaceId) return;
        setIsLoading(true);
        try {
            const data = await getTestCasesByWorkspace(workspaceId);
            setTestCases(data || []);
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to load test cases');
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        loadTestCases();
    }, [workspaceId]);

    const handleAddCase = () => {
        router.push('/edit?workspaceId=' + workspaceId);
    };

    const handleEditCase = (caseId: string) => {
        router.push(`/edit?id=${caseId}&workspaceId=${workspaceId}`);
    };

    const handleDeleteCase = (caseId: string) => {
        modal.confirm({
            title: 'Delete Test Case',
            icon: <ExclamationCircleOutlined />,
            content: 'Are you sure you want to delete this test case?',
            okText: 'Confirm',
            cancelText: 'Cancel',
            onOk: async () => {
                try {
                    await deleteTestCase(caseId);
                    messageApi.success('Test case deleted successfully');
                    loadTestCases(); // Refresh the list
                } catch (err) {
                    messageApi.error(err instanceof Error ? err.message : 'Delete failed');
                }
            }
        });
    };

    const getStatusColor = (status?: string) => {
        if (!status) return 'gray';
        switch (status.toUpperCase()) {
            case 'SUCCESS': return 'green';
            case 'FAILURE': return 'red';
            case 'RUNNING': return 'blue';
            default: return 'gray';
        }
    };

    const formatDateTime = (dateStr?: string) => {
        if (!dateStr) return 'N/A';
        const date = new Date(dateStr);
        const pad = (n: number) => n.toString().padStart(2, '0');
        return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    };

    return (
        <Flex vertical>
            <Flex align="center" justify="flex-end">
                <Button type="primary" icon={<PackagePlus size={14} />} onClick={handleAddCase}>
                    Add Case
                </Button>
            </Flex>
            {isLoading ? (
                <Flex justify="center" style={{ padding: '50px' }}><Spin size="large" /></Flex>
            ) : testCases.length === 0 ? (
                <Empty description="No test cases" style={{ marginTop: '50px' }} />
            ) : (
                <Flex wrap gap="middle" style={{ marginTop: '15px' }}>
                    {testCases.map((tc) => (
                        <Card
                            key={tc.case.id}
                            title={<Text ellipsis={{ tooltip: tc.case.name }}>{tc.case.name}</Text>}
                            hoverable={true}
                            style={{ width: 280, borderColor: getStatusColor(tc.lastExecution?.status) }}
                            extra={
                                <>
                                    <Button
                                        key="edit"
                                        type="text"
                                        icon={<HighlightOutlined />}
                                        style={{ color: 'green', marginLeft: '5px' }}
                                        onClick={() => handleEditCase(tc.case.id)}
                                    />
                                    <Button
                                        key="delete"
                                        type="text"
                                        danger
                                        icon={<DeleteOutlined />}
                                        onClick={() => handleDeleteCase(tc.case.id)}
                                    />
                                </>
                            }>
                            <p>Last Run Status: <Text style={{ color: getStatusColor(tc.lastExecution?.status) }}>{tc.lastExecution?.status || 'N/A'}</Text></p>
                            <p>Last Run Time: <Text>{formatDateTime(tc.lastExecution?.startTime)}</Text></p>
                            <p style={{ marginTop: '10px' }}>Case Type: <Text strong>{tc.case.type}</Text></p>
                        </Card>
                    ))}
                </Flex>
            )}
            {modalContextHolder}{messageContextHolder}
        </Flex>
    )
}