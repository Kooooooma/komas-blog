"use client";

import { Flex, Typography, Progress, Button, message, Empty, Spin, Modal, Select, Input } from "antd";
import { green, red, gray } from "@ant-design/colors";
import { DeleteOutlined, EditOutlined } from '@ant-design/icons';
import { PackagePlus, SquarePlay, Grid2x2Plus } from 'lucide-react';
import { getLanesByWorkspace, createLane, addCaseToLane, getWorkspacesByEmployee, deleteLane, removeCaseFromLane, updateLaneName, updateLaneOrder } from "@/libs/lane";
import { getTestCasesByWorkspace } from "@/libs/edit";
import { useCommonStore } from '@/store/commonStore';
import { useCurrentUser } from '@/hooks/useCurrentUser';
import { useEffect, useState } from "react";
import { useRouter } from 'next/navigation';
import SortableLaneCases from './SortableLaneCases';

interface LaneCase {
    case: {
        id: string;
        name: string;
        type: string;
    };
    lastExecution?: {
        status: string;
        startTime: string;
    };
}

interface LaneData {
    lane: {
        id: string;
        name: string;
        workspaceId: string;
        createTime: string;
    };
    cases: LaneCase[];
    stats: Record<string, number>;
    status: string;
}

interface WorkspaceOption {
    id: string;
    name: string;
    type: string;
}

interface CaseOption {
    case: {
        id: string;
        name: string;
        type: string;
    };
}

export default function OrchestrationWorkspace() {
    const { Title, Text } = Typography;
    const { workspaceId } = useCommonStore();
    const { employeeId } = useCurrentUser();
    const router = useRouter();
    const [messageApi, messageContextHolder] = message.useMessage();
    const [isLoading, setIsLoading] = useState(false);
    const [lanes, setLanes] = useState<LaneData[]>([]);

    // Add Case Modal states
    const [showAddCaseModal, setShowAddCaseModal] = useState(false);
    const [selectedLaneId, setSelectedLaneId] = useState<string | null>(null);
    const [workspaces, setWorkspaces] = useState<WorkspaceOption[]>([]);
    const [selectedWorkspaceId, setSelectedWorkspaceId] = useState<string | null>(null);
    const [cases, setCases] = useState<CaseOption[]>([]);
    const [selectedCaseId, setSelectedCaseId] = useState<string | null>(null);
    const [isLoadingWorkspaces, setIsLoadingWorkspaces] = useState(false);
    const [isLoadingCases, setIsLoadingCases] = useState(false);

    // Update Lane Name Modal states
    const [showUpdateLaneNameModal, setShowUpdateLaneNameModal] = useState(false);
    const [updateLaneTarget, setUpdateLaneTarget] = useState<{ id: string; name: string } | null>(null);

    const loadLanes = async () => {
        if (!workspaceId) return;
        try {
            setIsLoading(true);
            const data = await getLanesByWorkspace(workspaceId);
            setLanes(data || []);
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to load lanes');
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        loadLanes();
    }, [workspaceId]);

    const handleAddLane = async () => {
        if (!workspaceId) return;
        try {
            const now = new Date();
            const name = `Lane ${now.toISOString().replace('T', ' ').substring(0, 19)}`;
            await createLane(workspaceId, name);
            messageApi.success('Lane created successfully');
            loadLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to create lane');
        }
    };

    const handleOpenAddCaseModal = async (laneId: string) => {
        setSelectedLaneId(laneId);
        setSelectedWorkspaceId(null);
        setSelectedCaseId(null);
        setCases([]);
        setShowAddCaseModal(true);

        // Load workspaces
        if (employeeId) {
            setIsLoadingWorkspaces(true);
            try {
                const data = await getWorkspacesByEmployee(employeeId);
                setWorkspaces(data || []);
            } catch (err) {
                messageApi.error('Failed to load workspaces');
            } finally {
                setIsLoadingWorkspaces(false);
            }
        }
    };

    const handleWorkspaceChange = async (wsId: string) => {
        setSelectedWorkspaceId(wsId);
        setSelectedCaseId(null);
        setCases([]);

        // Load cases for selected workspace
        setIsLoadingCases(true);
        try {
            const data = await getTestCasesByWorkspace(wsId);
            setCases(data || []);
        } catch (err) {
            messageApi.error('Failed to load cases');
        } finally {
            setIsLoadingCases(false);
        }
    };

    const handleAddCaseConfirm = async () => {
        if (!selectedLaneId || !selectedCaseId) {
            messageApi.warning('Please select a case');
            return;
        }
        try {
            await addCaseToLane(selectedLaneId, selectedCaseId);
            messageApi.success('Case added to lane successfully');
            setShowAddCaseModal(false);
            loadLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to add case');
        }
    };

    // Delete Lane Modal states
    const [showDeleteLaneModal, setShowDeleteLaneModal] = useState(false);
    const [deleteLaneTarget, setDeleteLaneTarget] = useState<{ id: string; name: string } | null>(null);

    const handleDeleteLane = (laneId: string, laneName: string) => {
        setDeleteLaneTarget({ id: laneId, name: laneName });
        setShowDeleteLaneModal(true);
    };

    const handleDeleteLaneConfirm = async () => {
        if (!deleteLaneTarget) return;
        try {
            await deleteLane(deleteLaneTarget.id);
            messageApi.success('Lane deleted successfully');
            setShowDeleteLaneModal(false);
            setDeleteLaneTarget(null);
            loadLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to delete lane');
        }
    };

    const handleRemoveCase = async (laneId: string, caseId: string) => {
        try {
            await removeCaseFromLane(laneId, caseId);
            messageApi.success('Case removed from lane successfully');
            loadLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to remove case');
        }
    };

    const handleOpenUpdateLaneNameModal = (laneId: string, laneName: string) => {
        setUpdateLaneTarget({ id: laneId, name: laneName });
        setShowUpdateLaneNameModal(true);
    };

    const handleUpdateLaneName = async () => {
        if (!updateLaneTarget) return;
        try {
            await updateLaneName(updateLaneTarget.id, updateLaneTarget.name);
            messageApi.success('Lane name updated');
            setShowUpdateLaneNameModal(false);
            setUpdateLaneTarget(null);
            loadLanes();
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to update lane name');
        }
    };

    const handleReorderCases = async (laneId: string, newCaseIds: string[]) => {
        // Optimistic update
        setLanes(prevLanes => prevLanes.map(laneData => {
            if (laneData.lane.id !== laneId) return laneData;
            const reorderedCases = newCaseIds.map(id => laneData.cases.find(c => c.case.id === id)!).filter(Boolean);
            return { ...laneData, cases: reorderedCases };
        }));

        try {
            await updateLaneOrder(laneId, newCaseIds);
        } catch (err) {
            messageApi.error(err instanceof Error ? err.message : 'Failed to update order');
            loadLanes(); // Revert on error
        }
    };

    const getStatusColor = (status?: string) => {
        if (!status) return gray[5];
        switch (status.toUpperCase()) {
            case 'SUCCESS': return green[6];
            case 'FAILURE': return red[5];
            case 'RUNNING': return '#1890ff';
            default: return gray[5];
        }
    };

    const formatDateTime = (dateStr?: string) => {
        if (!dateStr) return 'N/A';
        const date = new Date(dateStr);
        const pad = (n: number) => n.toString().padStart(2, '0');
        return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(date.getSeconds())}`;
    };

    const getProgressSteps = (laneData: LaneData) => {
        const cases = laneData.cases || [];
        if (cases.length === 0) return { steps: 0, colors: [] };

        const colors = cases.map(c => getStatusColor(c.lastExecution?.status));
        return { steps: cases.length, colors };
    };

    const handleEditCase = (caseId: string) => {
        router.push(`/edit?id=${caseId}&workspaceId=${workspaceId}`);
    };

    return (
        <Flex vertical>
            <Flex align="center" justify="flex-end" style={{ marginBottom: '15px', borderBottom: '1px solid #ccc', padding: '10px 0' }}>
                <Button type="primary" icon={<Grid2x2Plus size={14} />} onClick={handleAddLane}>
                    Add Lane
                </Button>
            </Flex>
            {isLoading ? (
                <Flex justify="center" style={{ padding: '50px' }}><Spin size="large" /></Flex>
            ) : lanes.length === 0 ? (
                <Empty description="No lanes" style={{ marginTop: '50px' }} />
            ) : (
                lanes.map((laneData) => {
                    const { steps, colors } = getProgressSteps(laneData);
                    return (
                        <Flex key={laneData.lane.id} vertical style={{ marginBottom: '15px', borderBottom: '1px solid #ccc' }}>
                            <Flex align="center" justify="space-between">
                                <Flex align="center" justify="flex-start">
                                    <Title level={4} style={{ margin: 0 }}>{laneData.lane.name}</Title>
                                    <Button type="text" size="small" icon={<EditOutlined />} style={{ marginLeft: '5px' }} onClick={() => handleOpenUpdateLaneNameModal(laneData.lane.id, laneData.lane.name)} />
                                </Flex>
                                {steps > 0 && (
                                    <Progress
                                        showInfo={false}
                                        size={12}
                                        percent={100}
                                        steps={steps}
                                        strokeColor={colors}
                                    />
                                )}
                                <Flex align="center" gap="small" justify="flex-end">
                                    <Button type="default" icon={<PackagePlus size={14} />} onClick={() => handleOpenAddCaseModal(laneData.lane.id)}>
                                        Add Case
                                    </Button>
                                    <Button type="default" icon={<SquarePlay size={14} />}>
                                        Run Lane
                                    </Button>
                                    <Button type="default" danger icon={<DeleteOutlined />} onClick={() => handleDeleteLane(laneData.lane.id, laneData.lane.name)}>
                                        Delete Lane
                                    </Button>
                                </Flex>
                            </Flex>
                            <SortableLaneCases
                                laneId={laneData.lane.id}
                                cases={laneData.cases}
                                getStatusColor={getStatusColor}
                                formatDateTime={formatDateTime}
                                onEditCase={handleEditCase}
                                onRemoveCase={handleRemoveCase}
                                onReorder={handleReorderCases}
                            />
                        </Flex>
                    );
                })
            )}

            {/* Add Case Modal */}
            <Modal
                title="Add Case to Lane"
                open={showAddCaseModal}
                onOk={handleAddCaseConfirm}
                onCancel={() => setShowAddCaseModal(false)}
                okText="Add"
                okButtonProps={{ disabled: !selectedCaseId }}
            >
                <Flex vertical gap="middle" style={{ marginTop: '20px' }}>
                    <div>
                        <Text strong>Select Workspace:</Text>
                        <Select
                            style={{ width: '100%', marginTop: '8px' }}
                            placeholder="Select a workspace"
                            loading={isLoadingWorkspaces}
                            value={selectedWorkspaceId}
                            onChange={handleWorkspaceChange}
                            options={workspaces.map(ws => ({
                                value: ws.id,
                                label: `${ws.name} (${ws.type})`
                            }))}
                        />
                    </div>
                    <div>
                        <Text strong>Select Case:</Text>
                        <Select
                            style={{ width: '100%', marginTop: '8px' }}
                            placeholder={selectedWorkspaceId ? "Select a case" : "Please select a workspace first"}
                            loading={isLoadingCases}
                            disabled={!selectedWorkspaceId}
                            value={selectedCaseId}
                            onChange={(value) => setSelectedCaseId(value)}
                            options={cases.map(c => ({
                                value: c.case.id,
                                label: `${c.case.name} (${c.case.type})`
                            }))}
                        />
                    </div>
                </Flex>
            </Modal>

            {/* Delete Lane Confirmation Modal */}
            <Modal
                title="Delete Lane"
                open={showDeleteLaneModal}
                onOk={handleDeleteLaneConfirm}
                onCancel={() => {
                    setShowDeleteLaneModal(false);
                    setDeleteLaneTarget(null);
                }}
                okText="Delete"
                okType="danger"
                cancelText="Cancel"
            >
                <p>Are you sure you want to delete lane "{deleteLaneTarget?.name}"?</p>
                <p>This action cannot be undone.</p>
            </Modal>

            {/* Update Lane Name Modal */}
            <Modal
                title="Update Lane Name"
                open={showUpdateLaneNameModal}
                onOk={handleUpdateLaneName}
                onCancel={() => {
                    setShowUpdateLaneNameModal(false);
                    setUpdateLaneTarget(null);
                }}
            >
                <Input
                    style={{ margin: '15px 0' }}
                    value={updateLaneTarget?.name || ''}
                    onChange={(e) => setUpdateLaneTarget(prev => prev ? { ...prev, name: e.target.value } : null)}
                />
            </Modal>
            {messageContextHolder}
        </Flex>
    );
}