"use client";

import { Select, Typography } from 'antd';
import { Position, Handle, NodeProps, useReactFlow } from '@xyflow/react';
import { useCommonStore } from '@/store/commonStore';

interface InputNodeData extends Record<string, unknown> {
    name: string;
    inputValue?: string;
}

export default function SelectNode({ id, selected, data }: NodeProps) {

    const { Title } = Typography;
    const { updateNodeData } = useReactFlow();
    const setHasUnsavedChanges = useCommonStore((state) => state.setHasUnsavedChanges);

    const nodeData = data as unknown as InputNodeData;

    const databaseOptions = [
        { value: 'mysql', label: 'MySQL' },
        { value: 'postgres', label: 'Postgres' },
        { value: 'sqlite', label: 'SQLite' },
        { value: 'mssql', label: 'MSSQL' },
        { value: 'oracle', label: 'Oracle' },
    ];

    const handleChange = (value: string) => {
        // Update node data in ReactFlow state
        updateNodeData(id, { ...data, inputValue: value });
        setHasUnsavedChanges(true);
    };

    return (
        <div style={{
            padding: '13px 10px',
            backgroundColor: '#fff',
            minWidth: '200px',
            minHeight: '70px',
            borderRadius: '6px',
            border: selected ? '2px solid #ff4d4f' : '1px solid #b1b1b7',
            boxShadow: selected ? '0 0 8px rgba(255, 77, 79, 0.3)' : 'none',
        }}>
            <Title level={5}>{nodeData.name}</Title>
            <Select
                style={{ width: '100%' }}
                allowClear
                options={databaseOptions}
                value={nodeData.inputValue}
                onChange={handleChange}
                className='nodrag'
                onClick={(e) => e.stopPropagation()}
                onMouseDown={(e) => e.stopPropagation()}
            />
            <Handle type="target" position={Position.Top} />
            <Handle type="source" position={Position.Bottom} />
        </div >
    );
}