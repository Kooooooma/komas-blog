"use client";

import SelectNode from "./SelectNode";
import InputNode from "./InputNode";

export const nodeTypes = {
    jmsAgent: SelectNode,
    freeCtrlMJob: InputNode,
    orderCtrlMJob: InputNode,
    loginToCtrlM: SelectNode,
    reorderCtrlMJob: InputNode,
    connectServer: InputNode,
    executeCommand: InputNode,
}