"use client";

import { Input, Typography } from 'antd';
import { Position, Handle, NodeProps, useReactFlow } from '@xyflow/react';
import { useCommonStore } from '@/store/commonStore';

interface InputNodeData extends Record<string, unknown> {
    name: string;
    inputValue?: string;
}

export default function InputNode({ id, selected, data }: NodeProps) {
    const { Title } = Typography;
    const { updateNodeData } = useReactFlow();
    const setHasUnsavedChanges = useCommonStore((state) => state.setHasUnsavedChanges);

    // Cast data to our specific type to safely access properties
    const nodeData = data as unknown as InputNodeData;

    const handleChange = (value: string) => {
        // Update node data in ReactFlow state
        updateNodeData(id, { ...nodeData, inputValue: value });
        setHasUnsavedChanges(true);
    };

    return (
        <div style={{
            padding: '13px 10px',
            backgroundColor: '#fff',
            minWidth: '200px',
            minHeight: '70px',
            borderRadius: '6px',
            border: selected ? '2px solid #ff4d4f' : '1px solid #b1b1b7',
            boxShadow: selected ? '0 0 8px rgba(255, 77, 79, 0.3)' : 'none',
        }}>
            <Title level={5}>{nodeData.name}</Title>
            <Input onChange={(e) => handleChange(e.target.value)} value={nodeData.inputValue} />
            <Handle type="target" position={Position.Top} />
            <Handle type="source" position={Position.Bottom} />
        </div >
    );
}