'use client';

import { useState, useEffect } from 'react';
import { getCurrentUser } from '@/libs/auth';

export const useCurrentUser = () => {
    const [employeeId, setEmployeeId] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const id = getCurrentUser();
        setEmployeeId(id);
        setLoading(false);
    }, []);

    return { employeeId, loading };
};