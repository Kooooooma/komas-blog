"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { getCurrentUser } from "@/libs/auth";

export const useAuthRedirect = () => {
    const router = useRouter();
    useEffect(() => {
        const employeeId = getCurrentUser();
        if (!employeeId) {
            router.replace('/login');
        }
    }, [router]);
};
