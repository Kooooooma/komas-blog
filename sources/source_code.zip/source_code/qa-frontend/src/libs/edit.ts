"use client";

import useSWR from 'swr';
import { API_BASE_URL } from './config';

export interface StepParameter {
    name: string;
    type: string;
    defaultValue: string;
}

export interface StepMetadata {
    key: string;
    name: string;
    category: string;
    pattern: string;
    keyword: string;
    parameters: StepParameter[];
}

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export const useStepList = () => {
    const { data, error, isLoading } = useSWR<Record<string, StepMetadata[]>>(
        `${API_BASE_URL}/api/steps/by-category`,
        fetcher
    );

    return {
        steps: data,
        isLoading,
        isError: error,
    };
};

export const previewCode = async (contract: string) => {
    const response = await fetch(`${API_BASE_URL}/api/execution/preview`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: contract,
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to preview code[' + errorMessage + ']');
    }
    return response.text();
};

export const updateTestCase = async (id: string, name: string, contract: string) => {
    const response = await fetch(`${API_BASE_URL}/api/testcase/${id}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name, contract }),
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to update test case[' + errorMessage + ']');
    }
    return response.json();
};

export const createTestCase = async (workspaceId: string, type: string, name: string, contract: string) => {
    const response = await fetch(`${API_BASE_URL}/api/testcase`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ workspaceId, type, name, contract }),
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to create test case[' + errorMessage + ']');
    }
    return response.json();
};

export const runTestCase = async (id: string) => {
    const response = await fetch(`${API_BASE_URL}/api/execution/run/${id}`, {
        method: 'POST',
    });

    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to run test case[' + errorMessage + ']');
    }
    return response.json();
};

export const getTestCase = async (id: string) => {
    const response = await fetch(`${API_BASE_URL}/api/testcase/${id}`);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to load test case[' + errorMessage + ']');
    }
    return response.json();
};

export const updateTestCaseName = async (id: string, name: string) => {
    const response = await fetch(`${API_BASE_URL}/api/testcase/${id}/name`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name }),
    });

    console.log(response.ok);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to update test case name[' + errorMessage + ']');
    }
    return response.json();
};

export const getReportContent = async (executionId: string) => {
    const response = await fetch(`${API_BASE_URL}/api/execution/report/${executionId}`);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to load report[' + errorMessage + ']');
    }
    return response.text();
};

export const getTestCasesByWorkspace = async (workspaceId: string) => {
    const response = await fetch(`${API_BASE_URL}/api/testcase/workspace/${workspaceId}`);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to load test cases[' + errorMessage + ']');
    }
    return response.json();
};

export const deleteTestCase = async (id: string) => {
    const response = await fetch(`${API_BASE_URL}/api/testcase/${id}`, {
        method: 'DELETE',
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to delete test case[' + errorMessage + ']');
    }
};


