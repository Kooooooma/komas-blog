import { API_BASE_URL, API_PREFIX } from './config';

export const login = async (employeeId: string) => {
    const response = await fetch(`${API_BASE_URL}${API_PREFIX}/auth/login`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ employeeId }),
    });

    if (!response.ok) {
        throw new Error('Login failed');
    }

    const data = await response.json();
    if (data.employeeId) {
        localStorage.setItem('employeeId', data.employeeId);
    }
    return data;
};

export const logout = () => {
    localStorage.removeItem('employeeId');
};

export const getCurrentUser = () => {
    if (typeof window !== 'undefined') { //check the runtime env is browser
        return localStorage.getItem('employeeId');
    }
    return null;
};
