"use client";

import useSWR from 'swr';
import { API_BASE_URL } from './config';

const fetcher = (url: string) => fetch(url).then((res) => res.json());

export const getLanesByWorkspace = async (workspaceId: string) => {
    const response = await fetch(`${API_BASE_URL}/api/lane/workspace/${workspaceId}`);
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to load lanes[' + errorMessage + ']');
    }
    return response.json();
};

export const createLane = async (workspaceId: string, name: string) => {
    const response = await fetch(`${API_BASE_URL}/api/lane`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ workspaceId, name }),
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to create lane[' + errorMessage + ']');
    }
    return response.json();
};

export const addCaseToLane = async (laneId: string, caseId: string) => {
    const response = await fetch(`${API_BASE_URL}/api/lane/${laneId}/case/${caseId}`, {
        method: 'POST',
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to add case to lane[' + errorMessage + ']');
    }
};

export const getWorkspacesByEmployee = async (employeeId: string) => {
    const response = await fetch(`${API_BASE_URL}/api/workspace/employee/${employeeId}`);
    if (!response.ok) {
        throw new Error('Failed to load workspaces');
    }
    return response.json();
};

export const deleteLane = async (laneId: string) => {
    const response = await fetch(`${API_BASE_URL}/api/lane/${laneId}`, {
        method: 'DELETE',
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to delete lane[' + errorMessage + ']');
    }
};

export const removeCaseFromLane = async (laneId: string, caseId: string) => {
    const response = await fetch(`${API_BASE_URL}/api/lane/${laneId}/case/${caseId}`, {
        method: 'DELETE',
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to remove case from lane[' + errorMessage + ']');
    }
};

export const updateLaneName = async (laneId: string, name: string) => {
    const response = await fetch(`${API_BASE_URL}/api/lane/${laneId}/name`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ name }),
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to update lane name[' + errorMessage + ']');
    }
};

export const updateLaneOrder = async (laneId: string, caseIds: string[]) => {
    const response = await fetch(`${API_BASE_URL}/api/lane/order`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ laneId, caseIds }),
    });
    if (!response.ok) {
        let errorMessage = 'null';
        try {
            const error = await response.json();
            errorMessage = error.message || errorMessage;
        } catch {
            //ignore error
        }
        throw new Error('Failed to update lane order[' + errorMessage + ']');
    }
};
