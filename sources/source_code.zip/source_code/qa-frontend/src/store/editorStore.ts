import { create } from 'zustand';
import { Node, Edge } from '@xyflow/react';
import { nanoid } from 'nanoid';

interface EditorState {
    nodes: Node[];
    edges: Edge[];
    setNodes: (nodes: Node[] | ((nodes: Node[]) => Node[])) => void;
    setEdges: (edges: Edge[] | ((edges: Edge[]) => Edge[])) => void;
    addNode: (nodeType: string, nodeName: string) => void;
}

export const useEditorStore = create<EditorState>((set, get) => ({
    nodes: [],
    edges: [],

    setNodes: (nodesOrUpdater) => {
        if (typeof nodesOrUpdater === 'function') {
            set({ nodes: nodesOrUpdater(get().nodes) });
        } else {
            set({ nodes: nodesOrUpdater });
        }
    },

    setEdges: (edgesOrUpdater) => {
        if (typeof edgesOrUpdater === 'function') {
            set({ edges: edgesOrUpdater(get().edges) });
        } else {
            set({ edges: edgesOrUpdater });
        }
    },

    addNode: (nodeType: string, nodeName: string) => {
        const nodes = get().nodes;
        const newNode: Node = {
            id: nanoid(),
            type: nodeType,
            position: {
                x: 100 + (nodes.length * 30) % 200,
                y: 100 + (nodes.length * 50) % 300
            },
            data: { name: nodeName, key: nodeType },
        };
        set({ nodes: [...nodes, newNode] });
    },
}));
