import { create } from 'zustand';

interface CommonState {
    workspaceType: string;
    setWorkspaceType: (workspaceType: string) => void;
    workspaceId: string;
    setWorkspaceId: (workspaceId: string) => void;
    hasUnsavedChanges: boolean;
    setHasUnsavedChanges: (hasUnsavedChanges: boolean) => void;
    isSelectEvent: boolean;
    setIsSelectEvent: (isSelectEvent: boolean) => void;
}

export const useCommonStore = create<CommonState>((set, get) => ({
    workspaceType: "STANDARD",
    setWorkspaceType: (workspaceType: string) => set({ workspaceType: workspaceType }),
    workspaceId: "",
    setWorkspaceId: (workspaceId: string) => set({ workspaceId: workspaceId }),
    hasUnsavedChanges: false,
    setHasUnsavedChanges: (hasUnsavedChanges: boolean) => set({ hasUnsavedChanges: hasUnsavedChanges }),
    isSelectEvent: false,
    setIsSelectEvent: (isSelectEvent: boolean) => set({ isSelectEvent: isSelectEvent }),
}))

