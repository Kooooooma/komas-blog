"use client";

import { Flex, Form, Input, Button, message } from "antd";
import { UserOutlined } from "@ant-design/icons";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { login } from "@/libs/auth";

export default function Login() {
    const router = useRouter();
    const [loading, setLoading] = useState(false);
    const [messageApi, contextHolder] = message.useMessage();

    const onFinish = async (values: { employeeId: string }) => {
        setLoading(true);
        try {
            await login(values.employeeId);
            messageApi.success('Login successful');
            router.push('/');
        } catch (error) {
            messageApi.error('Login failed. ' + error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <Flex vertical justify="center" align="center" style={{ height: "100vh", background: 'white' }}>
            {contextHolder}
            <img src="/logo.png" style={{ width: 80, marginBottom: 10 }} />
            <Form
                style={{ width: 300 }}
                onFinish={onFinish}
            >
                <Form.Item
                    name="employeeId"
                    rules={[{ required: true, message: 'Please input your Employee ID!' }]}
                >
                    <Input
                        prefix={<UserOutlined />}
                        placeholder="Employee ID (e.g., EMP001)"
                        size="large"
                        disabled={loading}
                    />
                </Form.Item>
                <Form.Item>
                    <Button type="primary" htmlType="submit" block size="large" loading={loading}>
                        Login
                    </Button>
                </Form.Item>
            </Form>
        </Flex>
    )
}