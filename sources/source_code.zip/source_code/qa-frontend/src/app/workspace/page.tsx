"use client";

import StandardWorkspace from "@/components/workspace/StandardWorkspace";
import OrchestrationWorkspace from "@/components/workspace/OrchestrationWorkspace";
import { useCommonStore } from "@/store/commonStore";

export default function Workspace() {
    const workspaceType = useCommonStore((state) => state.workspaceType);
    return (
        workspaceType === "STANDARD" ? <StandardWorkspace /> : <OrchestrationWorkspace />
    );
}
