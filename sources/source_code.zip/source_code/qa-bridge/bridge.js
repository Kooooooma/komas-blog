import express from 'express';
import axios from 'axios';
import { chromium } from '@playwright/test';
import fs from 'fs';
import path from 'path';
import { exec } from 'child_process';
import { randomUUID } from 'crypto';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const projectRoot = dirname(fileURLToPath(import.meta.url));
const testSpecDir = path.join(projectRoot, 'tests');
const reportsDir = path.join(projectRoot, 'reports');

if (!fs.existsSync(testSpecDir)) {
    fs.mkdirSync(testSpecDir);
}

if (!fs.existsSync(reportsDir)) {
    fs.mkdirSync(reportsDir);
}

const app = express();
const PORT = 3302;
const BACKEND_URL = 'http://localhost:3300';
const BRIDGE_UUID = randomUUID();

async function startBridge() {
    console.log('='.repeat(60));
    console.log(`🔑 Bridge UUID: ${BRIDGE_UUID}`);
    console.log('='.repeat(60));
    console.log('📢 Please enter this UUID in the E2E page to connect.');
    console.log('='.repeat(60));

    app.listen(PORT, () => {
        console.log(`🚀 Bridge server running on port ${PORT}`);
        connectToBackend();
    });
}

function connectToBackend() {
    console.log('📢 Connecting to backend with UUID:', BRIDGE_UUID);
    axios({
        method: 'get',
        url: `${BACKEND_URL}/api/bridge/register?source=bridge&bridgeUuid=${BRIDGE_UUID}`,
        responseType: 'stream'
    }).then(response => {
        console.log('📢 Connected to backend');
        const stream = response.data;

        stream.on('data', (chunk) => {
            const dataStr = chunk.toString();
            console.log('📢 Received data:', dataStr);
            try {
                const lines = dataStr.split('\n').filter(line => line.trim() !== '');
                lines.forEach(line => {
                    try {
                        // SSE format: data:{json}
                        let jsonStr = line;
                        if (line.startsWith('data:')) {
                            jsonStr = line.substring(5).trim();
                        }
                        if (!jsonStr) return;

                        const event = JSON.parse(jsonStr);
                        console.log('📢 Parsed event:', event);

                        if (event.type === 'PING') {
                            handlePingEvent();
                        } else if (event.type === 'RECORD') {
                            handleRecordEvent(event);
                        } else if (event.type === 'RUN') {
                            handleRunEvent(event);
                        }
                    } catch (e) {
                        // ignore parse errors for non-JSON lines
                    }
                });
            } catch (error) {
                console.error('❌ Error parsing event data:', error);
            }
        });

        stream.on('end', () => {
            console.log('❌ Connection ended, reconnecting in 5 seconds...');
            setTimeout(connectToBackend, 5000);
        });

        stream.on('error', (err) => {
            console.error('❌ Stream error:', err);
            setTimeout(connectToBackend, 5000);
        });

    }).catch(err => {
        console.error('❌ Connection failed:', err.message);
        setTimeout(connectToBackend, 5000);
    });
}

async function handleRecordEvent(event) {
    const { url, workspaceId, caseName } = event;
    console.log('📢 Starting record for URL:', url);

    const browser = await chromium.launchPersistentContext('', {
        headless: false,
        viewport: null,
        args: ['--start-maximized']
    });

    const page = await browser.newPage();
    const recordedEvents = [];

    recordedEvents.push({ id: randomUUID(), type: 'visit', selector: '', value: url });

    // Expose function to capture events from browser to bridge
    await page.exposeFunction('bridgeRecordEvent', (type, selector, value) => {
        console.log('📢 Recorded:', type, 'on', selector, value ? 'with ' + value : '');
        recordedEvents.push({ id: randomUUID(), type: type.toLowerCase(), selector: selector.toLowerCase(), value: value || '' });
    });

    await page.addInitScript(() => {
        function getSelector(element) {
            // @TODO to be enhanced
            if (element.id) return '#' + element.id;
            let selector = element.tagName.toLowerCase();
            if (element.className) {
                selector += '.' + element.className.trim().split(/\s+/).join('.');
            }
            return selector;
        }

        document.addEventListener('click', (e) => {
            window.bridgeRecordEvent('click', getSelector(e.target));
        }, true); // capture event at the beginning

        document.addEventListener('change', (e) => { // 'change' is better for final value than 'input'
            window.bridgeRecordEvent('fill', getSelector(e.target), e.target.value);
        }, false); // change event not bubble
    });

    await page.goto(url);

    // Wait for browser close
    browser.on('close', async () => {
        console.log('📢 Browser closed. Sending recorded events...');
        notifyBackend({
            type: 'RECORD_FINISHED',
            bridgeUuid: BRIDGE_UUID,
            recordedEvents: JSON.stringify(recordedEvents)
        });
    });
}

async function handleRunEvent(event) {
    const { testCaseId, executionId, contract } = event;
    console.log(`📢 Received run request for execution ${executionId}`);

    // Save contract to file
    const testFilePath = path.join(testSpecDir, `${executionId}.spec.js`);
    fs.writeFileSync(testFilePath, contract);

    const executionReportDir = path.join(reportsDir, executionId);
    if (!fs.existsSync(executionReportDir)) {
        fs.mkdirSync(executionReportDir, { recursive: true });
    }

    const runEnv = {
        ...process.env,
        PLAYWRIGHT_HTML_REPORT: executionReportDir
    };

    console.log(`Executing test: ${testFilePath}`);
    console.log(`Report will be saved to: ${executionReportDir}`);

    exec(`npx playwright test ${executionId}.spec.js --headed --reporter=html`, { cwd: projectRoot, env: runEnv, shell: true }, async (error, stdout, stderr) => {
        if (error) {
            console.error('❌ exec error:', error);
        }
        console.log('📢 stdout:', stdout);
        if (stderr) console.error('❌ stderr:', stderr);

        const reportIndexPath = path.join(executionReportDir, 'index.html');
        let reportContent = '';
        if (fs.existsSync(reportIndexPath)) {
            reportContent = fs.readFileSync(reportIndexPath, 'utf-8');
        }

        notifyBackend({
            type: 'EXECUTION_FINISHED',
            executionId: executionId,
            testCaseId: testCaseId,
            bridgeUuid: BRIDGE_UUID,
            executionStatus: error ? 'FAILURE' : 'SUCCESS',
            reportContent: reportContent
        });
    });
}

function handlePingEvent() {
    console.log('📢 Received ping, sending pong...');
    notifyBackend({
        type: 'PONG',
        bridgeUuid: BRIDGE_UUID,
    });
}

async function notifyBackend(payload) {
    try {
        await axios.post(`${BACKEND_URL}/api/bridge/notify/user`, payload);
        console.log('📢 Notification sent:', payload.type);
    } catch (err) {
        console.error('❌ Failed to send notification:', err.message);
    }
}

startBridge();
