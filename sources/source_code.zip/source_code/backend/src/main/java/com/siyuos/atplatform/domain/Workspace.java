package com.siyuos.atplatform.domain;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.UUID;

@Entity
@Table(name = "workspaces")
@Data
@NoArgsConstructor
public class Workspace {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private UUID userId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = true) // Allow null for existing data, default handled in Java
    private WorkspaceType type = WorkspaceType.STANDARD;

    public enum WorkspaceType {
        STANDARD, // 标准 Workspace - 创建和管理单个 Case
        ORCHESTRATION // 编排 Workspace - 泳道编排多 Case 执行
    }

    public Workspace(String name, UUID userId) {
        this.name = name;
        this.userId = userId;
        this.type = WorkspaceType.STANDARD;
    }

    public Workspace(String name, UUID userId, WorkspaceType type) {
        this.name = name;
        this.userId = userId;
        this.type = type;
    }
}
