package com.siyuos.atplatform.framework.dto;

import lombok.Builder;
import lombok.Data;
import java.util.List;

@Data
@Builder
public class StepMetadata {
    private String key; // Unique ID inferred from method name
    private String name;
    private String description;
    private String category;
    private String pattern;
    private String keyword; // Gherkin keyword: Given, When, Then, And
    private List<StepParameter> parameters;

    @Data
    @Builder
    public static class StepParameter {
        private String name;
        private String type; // STRING, INT, BOOLEAN
        private String defaultValue;
    }
}
