package com.siyuos.atplatform.repository;

import com.siyuos.atplatform.domain.Lane;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface LaneRepository extends JpaRepository<Lane, UUID> {
    List<Lane> findByWorkspaceIdOrderByOrderIndex(UUID workspaceId);

    void deleteByWorkspaceId(UUID workspaceId);
}
