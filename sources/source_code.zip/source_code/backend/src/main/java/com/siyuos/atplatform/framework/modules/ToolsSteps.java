package com.siyuos.atplatform.framework.modules;

import org.springframework.stereotype.Component;

import com.siyuos.atplatform.framework.annotation.ActionStep;

import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ToolsSteps {
    @ActionStep(name = "JMS Agent", description = "JMS Agent", category = "Mock")
    @Given("Inject {string } with JMS Agent")
    public void jmsAgent(String service) {
        log.info("[Mock] Inject {} with JMS Agent", service);
    }
}
