package com.siyuos.atplatform.controller;

import com.siyuos.atplatform.framework.dto.StepMetadata;
import com.siyuos.atplatform.framework.service.StepRegistryService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/steps")
public class StepMetadataController {

    private final StepRegistryService stepRegistryService;

    public StepMetadataController(StepRegistryService stepRegistryService) {
        this.stepRegistryService = stepRegistryService;
    }

    @GetMapping
    public List<StepMetadata> getAllSteps() {
        return stepRegistryService.getAllSteps();
    }

    @GetMapping("/by-category")
    public Map<String, List<StepMetadata>> getStepsByCategory() {
        return stepRegistryService.getStepsByCategory();
    }
}
