package com.siyuos.atplatform.domain;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.UUID;
import java.time.LocalDateTime;

@Entity
@Table(name = "test_executions")
@Data
@NoArgsConstructor
public class TestExecution {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private UUID testCaseId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ExecutionStatus status;

    @Lob
    @Column(columnDefinition = "CLOB")
    private String logs; // Execution logs

    private LocalDateTime startTime;
    private LocalDateTime endTime;

    public enum ExecutionStatus {
        PENDING,
        RUNNING,
        SUCCESS,
        FAILURE
    }

    public TestExecution(UUID testCaseId, ExecutionStatus status, LocalDateTime startTime) {
        this.testCaseId = testCaseId;
        this.status = status;
        this.startTime = startTime;
    }
}
