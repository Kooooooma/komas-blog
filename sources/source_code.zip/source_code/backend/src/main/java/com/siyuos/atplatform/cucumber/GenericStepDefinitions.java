package com.siyuos.atplatform.cucumber;

import io.cucumber.java.en.Given;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class GenericStepDefinitions {

    private static final Logger logger = LoggerFactory.getLogger(GenericStepDefinitions.class);

    private int result = 0;

    @Given("I am on login page")
    public void loginPage() {
        logger.info("Navigated to Login Page (Mock)");
    }

    @io.cucumber.java.en.When("i input {int} and {int}")
    public void inputNumbers(int a, int b) {
        logger.info("Calculating: {} + {}", a, b);
        this.result = a + b;
    }

    @io.cucumber.java.en.Then("i would see {int}")
    public void verifyResult(int expected) {
        logger.info("Verifying result. Expected: {}, Actual: {}", expected, result);
        org.junit.jupiter.api.Assertions.assertEquals(expected, result, "Verification Failed: Result mismatch");
    }

    @Given("^.*fail.*$")
    public void failStep() {
        logger.error("Simulating failure for step containing 'fail'");
        throw new RuntimeException("Simulated Failure");
    }

    // Generic fallback for any other step that DOES NOT contain 'fail', 'input',
    // 'see', or 'login'
    @Given("^(?!.*fail)(?!.*input)(?!.*see)(?!.*login).*$")
    public void passStep() {
        logger.info("Executing Generic Step (Pass)");
    }
}
