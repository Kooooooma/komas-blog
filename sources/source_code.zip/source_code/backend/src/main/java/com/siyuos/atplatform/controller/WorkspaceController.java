package com.siyuos.atplatform.controller;

import com.siyuos.atplatform.domain.Workspace;
import com.siyuos.atplatform.domain.TestCase;
import com.siyuos.atplatform.repository.WorkspaceRepository;
import com.siyuos.atplatform.repository.TestCaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/workspace")
@CrossOrigin(origins = "http://localhost:3301")
public class WorkspaceController {

    @Autowired
    private WorkspaceRepository workspaceRepository;

    @GetMapping("/user/{userId}")
    public List<Workspace> getWorkspacesByUser(@PathVariable UUID userId) {
        return workspaceRepository.findByUserId(userId);
    }

    @PostMapping
    public Workspace createWorkspace(@RequestBody Workspace workspace) {
        return workspaceRepository.save(workspace);
    }

    @PutMapping("/{id}")
    public Workspace updateWorkspace(@PathVariable UUID id, @RequestBody Map<String, String> payload) {
        Workspace workspace = workspaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Workspace not found"));

        if (payload.containsKey("name")) {
            workspace.setName(payload.get("name"));
        }

        return workspaceRepository.save(workspace);
    }

    @DeleteMapping("/{id}")
    public void deleteWorkspace(@PathVariable UUID id) {
        Workspace workspace = workspaceRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Workspace not found"));

        // 1. Find all test cases in this workspace
        List<TestCase> testCases = testCaseRepository.findByWorkspaceId(id);

        // 2. Delete report files for each test case
        for (TestCase testCase : testCases) {
            deleteReportsForTestCase(testCase.getId());
        }

        // 3. Delete all test cases
        testCaseRepository.deleteAll(testCases);

        // 4. Delete the workspace itself
        workspaceRepository.delete(workspace);
    }

    private void deleteReportsForTestCase(UUID caseId) {
        try {
            // Delete cucumber reports
            java.nio.file.Path cucumberReportDir = java.nio.file.Paths.get("..", "reports", "cucumber",
                    caseId.toString());
            if (java.nio.file.Files.exists(cucumberReportDir)) {
                deleteDirectory(cucumberReportDir);
            }

            // Delete cypress reports
            java.nio.file.Path cypressReportDir = java.nio.file.Paths.get("..", "reports", "cypress",
                    caseId.toString());
            if (java.nio.file.Files.exists(cypressReportDir)) {
                deleteDirectory(cypressReportDir);
            }
        } catch (Exception e) {
            System.err.println("Failed to delete reports for case " + caseId + ": " + e.getMessage());
            // Continue with deletion even if report cleanup fails
        }
    }

    private void deleteDirectory(java.nio.file.Path directory) throws java.io.IOException {
        java.nio.file.Files.walk(directory)
                .sorted(java.util.Comparator.reverseOrder())
                .forEach(path -> {
                    try {
                        java.nio.file.Files.delete(path);
                    } catch (java.io.IOException e) {
                        System.err.println("Failed to delete " + path + ": " + e.getMessage());
                    }
                });
    }

    @Autowired
    private TestCaseRepository testCaseRepository;
}
