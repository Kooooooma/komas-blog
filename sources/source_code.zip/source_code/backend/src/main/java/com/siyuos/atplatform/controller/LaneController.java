package com.siyuos.atplatform.controller;

import com.siyuos.atplatform.domain.Lane;
import com.siyuos.atplatform.domain.LaneCaseMapping;
import com.siyuos.atplatform.domain.TestCase;
import com.siyuos.atplatform.repository.LaneCaseMappingRepository;
import com.siyuos.atplatform.repository.LaneRepository;
import com.siyuos.atplatform.repository.TestCaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 泳道管理 API
 */
@RestController
@RequestMapping("/api/lane")
@CrossOrigin(origins = "http://localhost:3301")
public class LaneController {

    @Autowired
    private LaneRepository laneRepository;

    @Autowired
    private LaneCaseMappingRepository laneCaseMappingRepository;

    @Autowired
    private TestCaseRepository testCaseRepository;

    /**
     * 获取 Workspace 下所有泳道及其 Cases
     */
    @GetMapping("/workspace/{workspaceId}")
    public List<Map<String, Object>> getLanesByWorkspace(@PathVariable UUID workspaceId) {
        List<Lane> lanes = laneRepository.findByWorkspaceIdOrderByOrderIndex(workspaceId);

        return lanes.stream().map(lane -> {
            Map<String, Object> laneData = new HashMap<>();
            laneData.put("id", lane.getId());
            laneData.put("name", lane.getName());
            laneData.put("orderIndex", lane.getOrderIndex());
            laneData.put("lastExecutionStatus", lane.getLastExecutionStatus());
            laneData.put("lastExecutionId", lane.getLastExecutionId());

            // 获取泳道内的 Cases
            List<LaneCaseMapping> mappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndex(lane.getId());
            List<Map<String, Object>> cases = mappings.stream().map(mapping -> {
                Map<String, Object> caseData = new HashMap<>();
                caseData.put("mappingId", mapping.getId());
                caseData.put("testCaseId", mapping.getTestCaseId());
                caseData.put("orderIndex", mapping.getOrderIndex());
                caseData.put("lastExecutionStatus", mapping.getLastExecutionStatus());

                // 获取 TestCase 详情
                testCaseRepository.findById(mapping.getTestCaseId()).ifPresent(tc -> {
                    caseData.put("name", tc.getName());
                    caseData.put("type", tc.getType().name());
                    caseData.put("workspaceId", tc.getWorkspaceId());
                });

                return caseData;
            }).collect(Collectors.toList());

            laneData.put("cases", cases);
            return laneData;
        }).collect(Collectors.toList());
    }

    /**
     * 创建新泳道
     */
    @PostMapping
    public Lane createLane(@RequestBody Map<String, Object> payload) {
        UUID workspaceId = UUID.fromString((String) payload.get("workspaceId"));
        String name = (String) payload.getOrDefault("name", "New Lane");

        // 获取当前最大 orderIndex
        List<Lane> existingLanes = laneRepository.findByWorkspaceIdOrderByOrderIndex(workspaceId);
        int nextOrder = existingLanes.isEmpty() ? 0 : existingLanes.get(existingLanes.size() - 1).getOrderIndex() + 1;

        Lane lane = new Lane(workspaceId, name, nextOrder);
        return laneRepository.save(lane);
    }

    /**
     * 更新泳道名称
     */
    @PutMapping("/{id}/name")
    public Lane updateLaneName(@PathVariable UUID id, @RequestBody Map<String, String> payload) {
        Lane lane = laneRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Lane not found"));

        if (payload.containsKey("name")) {
            lane.setName(payload.get("name"));
        }

        return laneRepository.save(lane);
    }

    /**
     * 删除泳道
     */
    @DeleteMapping("/{id}")
    @Transactional
    public ResponseEntity<Void> deleteLane(@PathVariable UUID id) {
        // 先删除泳道内的 Case 映射
        laneCaseMappingRepository.deleteByLaneId(id);
        // 再删除泳道
        laneRepository.deleteById(id);
        return ResponseEntity.ok().build();
    }

    /**
     * 向泳道添加 Case
     */
    @PostMapping("/{laneId}/case")
    public LaneCaseMapping addCaseToLane(@PathVariable UUID laneId, @RequestBody Map<String, String> payload) {
        UUID testCaseId = UUID.fromString(payload.get("testCaseId"));

        // 验证 TestCase 存在
        testCaseRepository.findById(testCaseId)
                .orElseThrow(() -> new RuntimeException("TestCase not found"));

        // 获取当前最大 orderIndex
        List<LaneCaseMapping> existingMappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndex(laneId);
        int nextOrder = existingMappings.isEmpty() ? 0
                : existingMappings.get(existingMappings.size() - 1).getOrderIndex() + 1;

        LaneCaseMapping mapping = new LaneCaseMapping(laneId, testCaseId, nextOrder);
        return laneCaseMappingRepository.save(mapping);
    }

    /**
     * 从泳道移除 Case
     */
    @DeleteMapping("/{laneId}/case/{mappingId}")
    public ResponseEntity<Void> removeCaseFromLane(@PathVariable UUID laneId, @PathVariable UUID mappingId) {
        laneCaseMappingRepository.deleteById(mappingId);
        return ResponseEntity.ok().build();
    }

    /**
     * 重排泳道内 Case 顺序（拖拽后调用）
     */
    @PutMapping("/{laneId}/case/reorder")
    @Transactional
    public List<LaneCaseMapping> reorderCases(@PathVariable UUID laneId,
            @RequestBody List<Map<String, Object>> orderedMappings) {
        List<LaneCaseMapping> updated = new ArrayList<>();

        for (int i = 0; i < orderedMappings.size(); i++) {
            UUID mappingId = UUID.fromString((String) orderedMappings.get(i).get("mappingId"));
            LaneCaseMapping mapping = laneCaseMappingRepository.findById(mappingId)
                    .orElseThrow(() -> new RuntimeException("Mapping not found"));
            mapping.setOrderIndex(i);
            updated.add(laneCaseMappingRepository.save(mapping));
        }

        return updated;
    }
}
