package com.siyuos.atplatform.dto;

import lombok.Data;
import java.util.UUID;

public class AuthDto {
    @Data
    public static class LoginRequest {
        private String employeeId;
    }

    @Data
    public static class AuthResponse {
        private UUID userId;
        private UUID workspaceId;
        private String workspaceName;
        private String token; // Optional for now
        private String employeeId;

        public AuthResponse(UUID userId, UUID workspaceId, String workspaceName, String employeeId) {
            this.userId = userId;
            this.workspaceId = workspaceId;
            this.workspaceName = workspaceName;
            this.employeeId = employeeId;
        }
    }
}
