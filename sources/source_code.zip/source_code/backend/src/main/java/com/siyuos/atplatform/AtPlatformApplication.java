package com.siyuos.atplatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtPlatformApplication {

    public static void main(String[] args) {
        SpringApplication.run(AtPlatformApplication.class, args);
    }

}
