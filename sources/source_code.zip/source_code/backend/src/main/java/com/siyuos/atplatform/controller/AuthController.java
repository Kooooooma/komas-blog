package com.siyuos.atplatform.controller;

import com.siyuos.atplatform.domain.User;
import com.siyuos.atplatform.domain.Workspace;
import com.siyuos.atplatform.dto.AuthDto;
import com.siyuos.atplatform.repository.UserRepository;
import com.siyuos.atplatform.repository.WorkspaceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3301")
public class AuthController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private WorkspaceRepository workspaceRepository;

    @PostMapping("/login")
    public AuthDto.AuthResponse login(@RequestBody AuthDto.LoginRequest request) {
        String employeeId = request.getEmployeeId();

        // Find or Create User
        User user = userRepository.findByEmployeeId(employeeId)
                .orElseGet(() -> userRepository.save(new User(employeeId)));

        // Find or Create Default Workspace
        List<Workspace> workspaces = workspaceRepository.findByUserId(user.getId());
        Workspace workspace;
        if (workspaces.isEmpty()) {
            workspace = workspaceRepository.save(new Workspace("Default Workspace", user.getId()));
        } else {
            workspace = workspaces.get(0);
        }

        return new AuthDto.AuthResponse(user.getId(), workspace.getId(), workspace.getName(), user.getEmployeeId());
    }
}
