package com.siyuos.atplatform.framework.modules;

import org.springframework.stereotype.Component;

import com.siyuos.atplatform.framework.annotation.ActionStep;

import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class DBSteps {
    @ActionStep(name = "Connect to DB", description = "Connect to DB", category = "Database")
    @Given("I connect to DB {string}")
    public void connectToDB(String server) {
        log.info("[Mock] Connect to DB: {}", server);
    }

    @ActionStep(name = "Execute SQL", description = "Execute SQL", category = "Database")
    @Given("I execute SQL {string}")
    public void executeSQL(String sql) {
        log.info("[Mock] Execute SQL: {}", sql);
    }
}
