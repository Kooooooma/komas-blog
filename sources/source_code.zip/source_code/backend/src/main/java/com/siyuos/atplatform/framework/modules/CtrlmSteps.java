package com.siyuos.atplatform.framework.modules;

import org.springframework.stereotype.Component;

import com.siyuos.atplatform.framework.annotation.ActionStep;

import io.cucumber.java.en.Given;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class CtrlmSteps {
    @ActionStep(name = "Login to CtrlM", description = "Login to CtrlM", category = "CtrlM")
    @Given("I login to CtrlM Server {string}")
    public void loginToCtrlM(String server) {
        log.info("[Mock] Login to CtrlM Server: {}", server);
    }

    @ActionStep(name = "Order Job", description = "Order Job", category = "CtrlM")
    @Given("I order job {string}")
    public void orderJob(String job) {
        log.info("[Mock] Order Job: {}", job);
    }

    @ActionStep(name = "Reorder Job", description = "Reorder Job", category = "CtrlM")
    @Given("I reorder job {string}")
    public void reOrderJob(String job) {
        log.info("[Mock] Reorder Job: {}", job);
    }

    @ActionStep(name = "Free Job", description = "Free Job", category = "CtrlM")
    @Given("I free job {string}")
    public void freeJob(String job) {
        log.info("[Mock] Free Job: {}", job);
    }
}
