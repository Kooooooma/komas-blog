package com.siyuos.atplatform.controller;

import com.siyuos.atplatform.domain.TestCase;
import com.siyuos.atplatform.repository.TestCaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:3301")
public class TestCaseController {

    @Autowired
    private TestCaseRepository testCaseRepository;

    @PostMapping("/testcase")
    public TestCase saveTestCase(@RequestBody TestCase testCase) {
        return testCaseRepository.save(testCase);
    }

    @GetMapping("/testcase/{id}")
    public TestCase getTestCase(@PathVariable UUID id) {
        return testCaseRepository.findById(id).orElseThrow(() -> new RuntimeException("TestCase not found"));
    }

    @GetMapping("/workspace/{id}")
    public List<TestCase> getTestCasesByWorkspace(@PathVariable UUID id) {
        return testCaseRepository.findByWorkspaceId(id);
    }

    @PatchMapping("/testcase/{id}/name")
    public TestCase updateTestCaseName(@PathVariable UUID id, @RequestBody java.util.Map<String, String> payload) {
        TestCase testCase = testCaseRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("TestCase not found"));
        testCase.setName(payload.get("name"));
        return testCaseRepository.save(testCase);
    }

    @DeleteMapping("/testcase/{id}")
    public void deleteTestCase(@PathVariable UUID id) {
        testCaseRepository.deleteById(id);
    }
}
