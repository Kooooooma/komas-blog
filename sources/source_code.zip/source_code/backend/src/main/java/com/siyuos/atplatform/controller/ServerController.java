package com.siyuos.atplatform.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/servers")
public class ServerController {

    @GetMapping
    public List<String> getServers() {
        return Arrays.asList("root@192.168.1.100", "admin@10.0.0.5", "testuser@localhost");
    }
}
