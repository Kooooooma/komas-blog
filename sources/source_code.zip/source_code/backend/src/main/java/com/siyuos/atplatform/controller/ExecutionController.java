package com.siyuos.atplatform.controller;

import com.siyuos.atplatform.domain.TestExecution;
import com.siyuos.atplatform.domain.TestCase;
import com.siyuos.atplatform.repository.TestExecutionRepository;
import com.siyuos.atplatform.repository.TestCaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.UUID;
import java.util.Map;

@RestController
@RequestMapping("/api/test")
@CrossOrigin(origins = "http://localhost:3301")
public class ExecutionController {

    @Autowired
    private TestExecutionRepository executionRepository;

    @Autowired
    private TestCaseRepository testCaseRepository;

    private final RestTemplate restTemplate = new RestTemplate();
    private final String BRIDGE_URL = "http://localhost:3302";

    /**
     * Preview Gherkin code without executing the test.
     * This ensures frontend sees exactly what backend will execute.
     */
    @PostMapping("/preview")
    public String previewGherkinCode(@RequestBody Map<String, Object> request) {
        try {
            // Create a temporary TestCase object from the request
            TestCase tempCase = new TestCase();
            tempCase.setName((String) request.get("name"));

            // Convert nodes/edges to contract JSON
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            String contract = mapper.writeValueAsString(Map.of(
                    "nodes", request.get("nodes"),
                    "edges", request.get("edges")));
            tempCase.setContract(contract);

            // Generate and return the Gherkin code
            return generateFeatureContent(tempCase);
        } catch (Exception e) {
            return "Error generating preview: " + e.getMessage();
        }
    }

    @PostMapping("/run")
    public TestExecution runTest(@RequestBody Map<String, String> request) {
        UUID testCaseId = UUID.fromString(request.get("testCaseId"));
        TestCase testCase = testCaseRepository.findById(testCaseId)
                .orElseThrow(() -> new RuntimeException("TestCase not found"));

        TestExecution execution = new TestExecution(testCaseId, TestExecution.ExecutionStatus.PENDING,
                LocalDateTime.now());
        executionRepository.save(execution);

        // Asynchronous execution logic
        new Thread(() -> {
            try {
                if (testCase.getType() == TestCase.TestCaseType.CUCUMBER) {
                    runCucumberTest(execution, testCase);
                } else if (testCase.getType() == TestCase.TestCaseType.CYPRESS) {
                    runCypressTest(execution, testCase);
                } else {
                    throw new RuntimeException("Unknown Test Case Type");
                }
            } catch (Exception e) {
                execution.setStatus(TestExecution.ExecutionStatus.FAILURE);
                execution.setLogs("Execution failed: " + e.getMessage());
                execution.setEndTime(LocalDateTime.now());
                executionRepository.save(execution);
            }
        }).start();

        return execution;
    }

    private void runCucumberTest(TestExecution execution, TestCase testCase) {
        try {
            execution.setStatus(TestExecution.ExecutionStatus.RUNNING);
            executionRepository.save(execution);

            // 1. Generate Feature File
            String featureContent = generateFeatureContent(testCase);
            java.nio.file.Path tempDir = java.nio.file.Files.createTempDirectory("at-platform-features");
            java.nio.file.Path featurePath = tempDir.resolve("test_" + execution.getId() + ".feature");
            java.nio.file.Files.writeString(featurePath, featureContent);

            // 2. Prepare Output Capture
            java.io.ByteArrayOutputStream outputStream = new java.io.ByteArrayOutputStream();
            java.io.PrintStream capture = new java.io.PrintStream(outputStream);
            java.io.PrintStream originalOut = System.out;
            System.setOut(capture); // Capture StdOut

            try {
                // 3. Run Cucumber CLI
                String reportPath = tempDir.resolve("cucumber-report.html").toAbsolutePath().toString();
                String[] args = {
                        "-g", "com.siyuos.atplatform.cucumber", // Glue path
                        "-p", "html:" + reportPath, // HTML Report
                        "-p", "pretty", // Console Output
                        featurePath.toAbsolutePath().toString() // Feature File
                };

                byte exitStatus = io.cucumber.core.cli.Main.run(args);

                // 4. Restore StdOut and Process Results
                System.setOut(originalOut);
                String logs = outputStream.toString();

                if (exitStatus == 0) {
                    execution.setStatus(TestExecution.ExecutionStatus.SUCCESS);
                    testCase.setLastExecutionStatus("SUCCESS");
                } else {
                    execution.setStatus(TestExecution.ExecutionStatus.FAILURE);
                    testCase.setLastExecutionStatus("FAILURE");
                }
                testCase.setLastExecutionId(execution.getId());
                testCaseRepository.save(testCase);

                execution.setLogs(logs);
                execution.setEndTime(LocalDateTime.now());

                // Read Report Content (Optional: Store URL or content)
                // Read Report Content (Optional: Store URL or content)
                if (java.nio.file.Files.exists(java.nio.file.Paths.get(reportPath))) {
                    // Save to structured directory: reports/cucumber/{caseId}/{executionId}.html
                    java.nio.file.Path rootReportDir = java.nio.file.Paths.get("..", "reports", "cucumber");
                    java.nio.file.Path caseDir = rootReportDir.resolve(testCase.getId().toString());

                    if (!java.nio.file.Files.exists(caseDir))
                        java.nio.file.Files.createDirectories(caseDir);

                    java.nio.file.Path destReport = caseDir.resolve(execution.getId() + ".html");
                    java.nio.file.Files.copy(java.nio.file.Paths.get(reportPath), destReport,
                            java.nio.file.StandardCopyOption.REPLACE_EXISTING);
                }

                executionRepository.save(execution);

            } catch (Exception e) {
                System.setOut(originalOut); // Ensure restored on error
                throw e;
            }

        } catch (Exception e) {
            execution.setStatus(TestExecution.ExecutionStatus.FAILURE);
            execution.setLogs("Execution failed: " + e.getMessage());
            execution.setEndTime(LocalDateTime.now());
            executionRepository.save(execution);
            e.printStackTrace();
        }
    }

    private String generateFeatureContent(TestCase testCase) {
        StringBuilder feature = new StringBuilder();
        feature.append("Feature: ").append(testCase.getName()).append("\n");

        try {
            com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
            com.fasterxml.jackson.databind.JsonNode root = mapper.readTree(testCase.getContract());

            if (root.has("nodes") && root.get("nodes").size() > 0) {
                java.util.List<com.fasterxml.jackson.databind.JsonNode> allNodes = new java.util.ArrayList<>();
                root.get("nodes").forEach(allNodes::add);

                // Build adjacency map from edges
                java.util.Map<String, java.util.Set<String>> adjacency = new java.util.HashMap<>();
                if (root.has("edges")) {
                    root.get("edges").forEach(edge -> {
                        String source = edge.get("source").asText();
                        String target = edge.get("target").asText();
                        adjacency.computeIfAbsent(source, k -> new java.util.HashSet<>()).add(target);
                        adjacency.computeIfAbsent(target, k -> new java.util.HashSet<>()).add(source);
                    });
                }

                // Find connected components using Union-Find
                java.util.Map<String, String> parent = new java.util.HashMap<>();
                for (com.fasterxml.jackson.databind.JsonNode node : allNodes) {
                    String nodeId = node.get("id").asText();
                    parent.put(nodeId, nodeId);
                }

                // Union-Find helper functions
                java.util.function.Function<String, String> find = new java.util.function.Function<String, String>() {
                    public String apply(String id) {
                        if (!parent.get(id).equals(id)) {
                            parent.put(id, this.apply(parent.get(id)));
                        }
                        return parent.get(id);
                    }
                };

                java.util.function.BiConsumer<String, String> union = (id1, id2) -> {
                    String root1 = find.apply(id1);
                    String root2 = find.apply(id2);
                    if (!root1.equals(root2)) {
                        parent.put(root1, root2);
                    }
                };

                // Union nodes that are connected by edges
                for (java.util.Map.Entry<String, java.util.Set<String>> entry : adjacency.entrySet()) {
                    String source = entry.getKey();
                    for (String target : entry.getValue()) {
                        union.accept(source, target);
                    }
                }

                // Group nodes by their root (connected component)
                java.util.Map<String, java.util.List<com.fasterxml.jackson.databind.JsonNode>> components = new java.util.HashMap<>();
                for (com.fasterxml.jackson.databind.JsonNode node : allNodes) {
                    String nodeId = node.get("id").asText();
                    String componentRoot = find.apply(nodeId);
                    components.computeIfAbsent(componentRoot, k -> new java.util.ArrayList<>()).add(node);
                }

                // Generate a Scenario for each connected component
                int scenarioNumber = 1;
                for (java.util.List<com.fasterxml.jackson.databind.JsonNode> componentNodes : components.values()) {
                    feature.append("  Scenario: Scenario ").append(scenarioNumber++).append("\n");

                    // Sort nodes in this component by Y position
                    componentNodes.sort((a, b) -> {
                        double y1 = a.get("position").get("y").asDouble();
                        double y2 = b.get("position").get("y").asDouble();
                        return Double.compare(y1, y2);
                    });

                    // Generate steps for this scenario
                    for (com.fasterxml.jackson.databind.JsonNode node : componentNodes) {
                        String nodeType = node.get("type").asText();

                        if ("step".equals(nodeType)) {
                            // Handle basic step nodes
                            String stepType = node.get("data").get("type").asText();
                            String stepValue = node.get("data").get("value").asText();
                            String keyword = stepType.charAt(0) + stepType.substring(1).toLowerCase();
                            feature.append("    ").append(keyword).append(" ").append(stepValue).append("\n");

                        } else if ("action".equals(nodeType)) {
                            // Handle action nodes (extensible for all plugins)
                            com.fasterxml.jackson.databind.JsonNode metadata = node.get("data").get("metadata");
                            com.fasterxml.jackson.databind.JsonNode values = node.get("data").get("values");

                            String pattern = metadata.get("pattern").asText();
                            com.fasterxml.jackson.databind.JsonNode parameters = metadata.get("parameters");

                            // Replace placeholders with actual values
                            String line = pattern;
                            int paramIndex = 0;

                            // Use regex to find all placeholders like {string}, {int}, etc.
                            java.util.regex.Pattern placeholderPattern = java.util.regex.Pattern.compile("\\{[^}]*\\}");
                            java.util.regex.Matcher matcher = placeholderPattern.matcher(pattern);
                            StringBuilder result = new StringBuilder();
                            int lastEnd = 0;

                            while (matcher.find()) {
                                result.append(pattern, lastEnd, matcher.start());

                                if (paramIndex < parameters.size()) {
                                    com.fasterxml.jackson.databind.JsonNode param = parameters.get(paramIndex);
                                    String paramName = param.get("name").asText();

                                    // Get value from node data, or use default
                                    String value = "";
                                    if (values != null && values.has(paramName)) {
                                        value = values.get(paramName).asText();
                                    }

                                    // Special case: keyPath defaults to "keys/" if empty
                                    if ("keyPath".equals(paramName) && (value == null || value.isEmpty())) {
                                        value = "keys/";
                                    }

                                    // Quote string values
                                    if (matcher.group().contains("string")) {
                                        result.append("\"").append(value).append("\"");
                                    } else {
                                        result.append(value);
                                    }
                                }

                                lastEnd = matcher.end();
                                paramIndex++;
                            }
                            result.append(pattern.substring(lastEnd));
                            line = result.toString();

                            // Determine Gherkin keyword based on pattern semantics (extensible)
                            String keyword = metadata.has("keyword") ? metadata.get("keyword").asText() : "Given";

                            feature.append("    ").append(keyword).append(" ").append(line).append("\n");
                        }
                    }

                    // Add blank line between scenarios
                    feature.append("\n");
                }
            }
        } catch (Exception e) {
            feature.append("  Scenario: Error\n");
            feature.append("    Given Parsing Failed: ").append(e.getMessage()).append("\n");
        }

        return feature.toString();
    }

    private void runCypressTest(TestExecution execution, TestCase testCase) {
        // Existing logic to call the Bridge
        execution.setStatus(TestExecution.ExecutionStatus.RUNNING);
        executionRepository.save(execution);

        restTemplate.postForObject(BRIDGE_URL + "/run/cypress",
                Map.of("executionId", execution.getId(),
                        "contract", testCase.getContract(),
                        "caseId", testCase.getId()),
                String.class);
    }

    @PostMapping("/report/{id}")
    public ResponseEntity<String> uploadReport(@PathVariable UUID id, @RequestBody Map<String, Object> report) {
        TestExecution execution = executionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Execution not found"));

        String statusStr = (String) report.get("status");
        execution.setStatus(TestExecution.ExecutionStatus.valueOf(statusStr.toUpperCase()));
        execution.setLogs((String) report.get("logs"));
        execution.setEndTime(LocalDateTime.now());

        TestCase testCase = testCaseRepository.findById(execution.getTestCaseId())
                .orElseThrow(() -> new RuntimeException("TestCase not found"));
        testCase.setLastExecutionStatus(statusStr.toUpperCase());
        testCase.setLastExecutionId(execution.getId());
        testCaseRepository.save(testCase);

        // Save report to disk
        String reportContent = (String) report.get("report");
        if (reportContent != null && !reportContent.isEmpty()) {
            try {
                java.nio.file.Path rootReportDir = java.nio.file.Paths.get("..", "reports", "cypress");
                java.nio.file.Path caseDir = rootReportDir.resolve(testCase.getId().toString());
                if (!java.nio.file.Files.exists(caseDir)) {
                    java.nio.file.Files.createDirectories(caseDir);
                }
                java.nio.file.Path reportPath = caseDir.resolve(execution.getId() + ".html");
                java.nio.file.Files.writeString(reportPath, reportContent);
            } catch (Exception e) {
                e.printStackTrace();
                execution.setLogs(execution.getLogs() + "\nFailed to save report: " + e.getMessage());
            }
        }

        executionRepository.save(execution);
        return ResponseEntity.ok("Report Received");
    }

    @GetMapping("/{id}")
    public TestExecution getExecution(@PathVariable UUID id) {
        return executionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Execution not found"));
    }

    @GetMapping("/report/{id}")
    public ResponseEntity<org.springframework.core.io.Resource> getReport(@PathVariable UUID id)
            throws java.io.IOException {
        TestExecution execution = executionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Execution not found"));
        TestCase testCase = testCaseRepository.findById(execution.getTestCaseId())
                .orElseThrow(() -> new RuntimeException("TestCase not found"));

        String typeDir = testCase.getType() == TestCase.TestCaseType.CUCUMBER ? "cucumber" : "cypress";
        java.nio.file.Path reportPath = java.nio.file.Paths.get("..", "reports", typeDir,
                testCase.getId().toString(), id + ".html");

        if (!java.nio.file.Files.exists(reportPath)) {
            // Fallback for older reports or if file missing
            reportPath = java.nio.file.Paths.get("reports").resolve(id + ".html");
            if (!java.nio.file.Files.exists(reportPath))
                return ResponseEntity.notFound().build();
        }

        org.springframework.core.io.Resource resource = new org.springframework.core.io.UrlResource(reportPath.toUri());
        return ResponseEntity.ok()
                .header(org.springframework.http.HttpHeaders.CONTENT_DISPOSITION,
                        "inline; filename=\"" + id + ".html\"")
                .contentType(org.springframework.http.MediaType.TEXT_HTML)
                .body(resource);
    }
}
