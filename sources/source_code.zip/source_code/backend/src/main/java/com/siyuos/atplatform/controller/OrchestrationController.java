package com.siyuos.atplatform.controller;

import com.siyuos.atplatform.domain.Lane;
import com.siyuos.atplatform.domain.LaneCaseMapping;
import com.siyuos.atplatform.domain.TestCase;
import com.siyuos.atplatform.repository.LaneCaseMappingRepository;
import com.siyuos.atplatform.repository.LaneRepository;
import com.siyuos.atplatform.repository.TestCaseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

/**
 * 编排执行 API - 支持泳道的顺序/并行执行
 */
@RestController
@RequestMapping("/api/orchestration")
@CrossOrigin(origins = "http://localhost:3301")
public class OrchestrationController {

    @Autowired
    private LaneRepository laneRepository;

    @Autowired
    private LaneCaseMappingRepository laneCaseMappingRepository;

    @Autowired
    private TestCaseRepository testCaseRepository;

    // 存储执行状态
    private final Map<UUID, Map<String, Object>> executionStatus = new ConcurrentHashMap<>();

    /**
     * 执行单个泳道（同步顺序执行泳道内所有 Case）
     */
    @PostMapping("/lane/{laneId}/run")
    public ResponseEntity<Map<String, Object>> runLane(@PathVariable UUID laneId) {
        Lane lane = laneRepository.findById(laneId)
                .orElseThrow(() -> new RuntimeException("Lane not found"));

        UUID executionId = UUID.randomUUID();
        lane.setLastExecutionId(executionId);
        lane.setLastExecutionStatus("RUNNING");
        laneRepository.save(lane);

        // 异步执行泳道
        CompletableFuture.runAsync(() -> executeLane(lane, executionId));

        Map<String, Object> response = new HashMap<>();
        response.put("executionId", executionId);
        response.put("laneId", laneId);
        response.put("status", "RUNNING");

        return ResponseEntity.ok(response);
    }

    /**
     * 执行 Workspace 下所有泳道（并行执行各泳道，每个泳道内顺序执行）
     */
    @PostMapping("/workspace/{workspaceId}/run")
    public ResponseEntity<Map<String, Object>> runAllLanes(@PathVariable UUID workspaceId) {
        List<Lane> lanes = laneRepository.findByWorkspaceIdOrderByOrderIndex(workspaceId);

        if (lanes.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "No lanes found in workspace"));
        }

        UUID orchestrationId = UUID.randomUUID();

        // 初始化执行状态
        Map<String, Object> status = new ConcurrentHashMap<>();
        status.put("workspaceId", workspaceId);
        status.put("startTime", System.currentTimeMillis());
        status.put("totalLanes", lanes.size());
        status.put("completedLanes", 0);
        status.put("status", "RUNNING");
        status.put("laneStatuses", new ConcurrentHashMap<String, String>());
        executionStatus.put(orchestrationId, status);

        // 并行执行所有泳道
        List<CompletableFuture<Void>> futures = lanes.stream()
                .map(lane -> {
                    UUID laneExecutionId = UUID.randomUUID();
                    lane.setLastExecutionId(laneExecutionId);
                    lane.setLastExecutionStatus("RUNNING");
                    laneRepository.save(lane);

                    return CompletableFuture.runAsync(() -> {
                        executeLane(lane, laneExecutionId);
                        updateOrchestrationStatus(orchestrationId, lane);
                    });
                })
                .collect(Collectors.toList());

        // 等待所有泳道完成后更新总状态
        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenRun(() -> finalizeOrchestration(orchestrationId));

        Map<String, Object> response = new HashMap<>();
        response.put("orchestrationId", orchestrationId);
        response.put("workspaceId", workspaceId);
        response.put("lanesCount", lanes.size());
        response.put("status", "RUNNING");

        return ResponseEntity.ok(response);
    }

    /**
     * 获取 Workspace 执行状态统计
     */
    @GetMapping("/workspace/{workspaceId}/status")
    public ResponseEntity<Map<String, Object>> getWorkspaceStatus(@PathVariable UUID workspaceId) {
        List<Lane> lanes = laneRepository.findByWorkspaceIdOrderByOrderIndex(workspaceId);

        int totalCases = 0;
        int successCases = 0;
        int failedCases = 0;
        int pendingCases = 0;

        List<Map<String, Object>> laneStats = new ArrayList<>();

        for (Lane lane : lanes) {
            List<LaneCaseMapping> mappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndex(lane.getId());

            int laneSuccess = 0;
            int laneFailed = 0;
            int lanePending = 0;

            for (LaneCaseMapping mapping : mappings) {
                totalCases++;
                String status = mapping.getLastExecutionStatus();
                if ("SUCCESS".equals(status)) {
                    successCases++;
                    laneSuccess++;
                } else if ("FAILURE".equals(status)) {
                    failedCases++;
                    laneFailed++;
                } else {
                    pendingCases++;
                    lanePending++;
                }
            }

            Map<String, Object> laneStat = new HashMap<>();
            laneStat.put("laneId", lane.getId());
            laneStat.put("laneName", lane.getName());
            laneStat.put("status", lane.getLastExecutionStatus());
            laneStat.put("totalCases", mappings.size());
            laneStat.put("successCases", laneSuccess);
            laneStat.put("failedCases", laneFailed);
            laneStat.put("pendingCases", lanePending);
            laneStats.add(laneStat);
        }

        Map<String, Object> result = new HashMap<>();
        result.put("totalLanes", lanes.size());
        result.put("totalCases", totalCases);
        result.put("successCases", successCases);
        result.put("failedCases", failedCases);
        result.put("pendingCases", pendingCases);
        result.put("successRate", totalCases > 0 ? (double) successCases / totalCases * 100 : 0);
        result.put("lanes", laneStats);

        return ResponseEntity.ok(result);
    }

    /**
     * 执行泳道内的所有 Case（顺序执行）
     */
    private void executeLane(Lane lane, UUID executionId) {
        List<LaneCaseMapping> mappings = laneCaseMappingRepository.findByLaneIdOrderByOrderIndex(lane.getId());

        boolean allSuccess = true;

        for (LaneCaseMapping mapping : mappings) {
            try {
                // 获取 TestCase
                TestCase testCase = testCaseRepository.findById(mapping.getTestCaseId())
                        .orElseThrow(() -> new RuntimeException("TestCase not found"));

                // 调用现有的执行 API
                String result = executeTestCase(testCase);

                mapping.setLastExecutionStatus(result);
                mapping.setLastExecutionId(executionId);
                laneCaseMappingRepository.save(mapping);

                if (!"SUCCESS".equals(result)) {
                    allSuccess = false;
                }
            } catch (Exception e) {
                mapping.setLastExecutionStatus("FAILURE");
                mapping.setLastExecutionId(executionId);
                laneCaseMappingRepository.save(mapping);
                allSuccess = false;
            }
        }

        // 更新泳道执行状态
        lane.setLastExecutionStatus(allSuccess ? "SUCCESS" : "FAILURE");
        laneRepository.save(lane);
    }

    /**
     * 执行单个 TestCase（复用现有执行逻辑）
     */
    private String executeTestCase(TestCase testCase) {
        try {
            RestTemplate restTemplate = new RestTemplate();
            String type = testCase.getType().name();
            String url = "http://localhost:3300/api/test/run/" + type;

            Map<String, String> request = new HashMap<>();
            request.put("testCaseId", testCase.getId().toString());

            @SuppressWarnings("unchecked")
            Map<String, Object> response = restTemplate.postForObject(url, request, Map.class);

            // 等待执行完成并获取结果
            // 注意：这里简化处理，实际可能需要轮询或使用回调
            Thread.sleep(5000); // 等待执行

            // 从 TestCase 获取最新状态
            TestCase updated = testCaseRepository.findById(testCase.getId()).orElse(testCase);
            return updated.getLastExecutionStatus() != null ? updated.getLastExecutionStatus() : "PENDING";
        } catch (Exception e) {
            return "FAILURE";
        }
    }

    private synchronized void updateOrchestrationStatus(UUID orchestrationId, Lane lane) {
        Map<String, Object> status = executionStatus.get(orchestrationId);
        if (status != null) {
            int completed = (int) status.getOrDefault("completedLanes", 0) + 1;
            status.put("completedLanes", completed);

            @SuppressWarnings("unchecked")
            Map<String, String> laneStatuses = (Map<String, String>) status.get("laneStatuses");
            laneStatuses.put(lane.getId().toString(), lane.getLastExecutionStatus());
        }
    }

    private void finalizeOrchestration(UUID orchestrationId) {
        Map<String, Object> status = executionStatus.get(orchestrationId);
        if (status != null) {
            status.put("endTime", System.currentTimeMillis());

            @SuppressWarnings("unchecked")
            Map<String, String> laneStatuses = (Map<String, String>) status.get("laneStatuses");
            boolean allSuccess = laneStatuses.values().stream().allMatch("SUCCESS"::equals);
            status.put("status", allSuccess ? "SUCCESS" : "FAILURE");
        }
    }
}
