package com.siyuos.atplatform.domain;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.UUID;

/**
 * 泳道与 Case 的关联关系
 * 引用已有的 TestCase，不复制数据
 */
@Entity
@Table(name = "lane_case_mappings")
@Data
@NoArgsConstructor
public class LaneCaseMapping {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private UUID laneId; // 所属泳道

    @Column(nullable = false)
    private UUID testCaseId; // 引用的 TestCase ID

    @Column(nullable = false)
    private Integer orderIndex = 0; // 在泳道内的执行顺序

    @Column
    private String lastExecutionStatus; // 该 Case 在此泳道中的最后执行状态

    @Column
    private UUID lastExecutionId;

    public LaneCaseMapping(UUID laneId, UUID testCaseId, Integer orderIndex) {
        this.laneId = laneId;
        this.testCaseId = testCaseId;
        this.orderIndex = orderIndex;
    }
}
