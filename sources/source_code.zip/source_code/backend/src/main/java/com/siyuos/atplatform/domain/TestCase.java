package com.siyuos.atplatform.domain;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.UUID;

@Entity
@Table(name = "test_cases")
@Data
@NoArgsConstructor
public class TestCase {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private UUID workspaceId;

    @Column(nullable = false)
    private String name;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TestCaseType type;

    @Lob
    @Column(columnDefinition = "CLOB")
    private String contract; // JSON string representing the flow

    @Column
    private String lastExecutionStatus;

    @Column
    private UUID lastExecutionId;

    public enum TestCaseType {
        CUCUMBER,
        CYPRESS
    }

    public TestCase(UUID workspaceId, String name, TestCaseType type, String contract) {
        this.workspaceId = workspaceId;
        this.name = name;
        this.type = type;
        this.contract = contract;
    }
}
