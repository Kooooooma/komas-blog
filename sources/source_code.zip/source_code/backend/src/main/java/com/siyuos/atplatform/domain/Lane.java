package com.siyuos.atplatform.domain;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.UUID;

/**
 * 泳道实体 - 用于编排 Workspace 中的 Case 执行顺序
 * 同一泳道内的 Case 顺序执行，不同泳道之间并行执行
 */
@Entity
@Table(name = "lanes")
@Data
@NoArgsConstructor
public class Lane {
    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @Column(nullable = false)
    private UUID workspaceId; // 所属编排 Workspace

    @Column(nullable = false)
    private String name; // 泳道名称

    @Column(nullable = false)
    private Integer orderIndex = 0; // 泳道顺序（用于 UI 排列）

    @Column
    private String lastExecutionStatus; // PENDING, RUNNING, SUCCESS, FAILURE

    @Column
    private UUID lastExecutionId;

    public Lane(UUID workspaceId, String name, Integer orderIndex) {
        this.workspaceId = workspaceId;
        this.name = name;
        this.orderIndex = orderIndex;
    }
}
