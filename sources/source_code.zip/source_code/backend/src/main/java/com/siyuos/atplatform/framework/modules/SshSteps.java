package com.siyuos.atplatform.framework.modules;

import com.siyuos.atplatform.framework.annotation.ActionStep;
import io.cucumber.java.en.Given;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class SshSteps {

    private static final Logger logger = LoggerFactory.getLogger(SshSteps.class);

    @ActionStep(name = "Connect to SSH", description = "Establishes an SSH connection to a remote server", category = "Network")
    @Given("I connect to server {string} with key {string}")
    public void connectToServer(String target, String keyPath) {
        String[] parts = target.split("@");
        String user = parts.length > 0 ? parts[0] : "root";
        String host = parts.length > 1 ? parts[1] : "localhost";

        // Define default key if empty or implicit
        if (keyPath == null || keyPath.isEmpty()) {
            keyPath = "keys/";
        }

        logger.info("[Mock] Connecting to SSH Server: {} (User: {}, Host: {}), Key: {}", target, user, host, keyPath);
    }

    @ActionStep(name = "Execute Command", description = "Executes a command on the connected server", category = "Network")
    @Given("I execute command {string}")
    public void executeCommand(String command) {
        logger.info("[Mock] Executing Command: {}", command);
    }
}
