package com.siyuos.atplatform.framework.service;

import com.siyuos.atplatform.framework.annotation.ActionStep;
import com.siyuos.atplatform.framework.dto.StepMetadata;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.java.en.Then;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;

import java.lang.reflect.Method;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class StepRegistryService {

    private final ApplicationContext applicationContext;
    private List<StepMetadata> registry = new ArrayList<>();

    public StepRegistryService(ApplicationContext applicationContext) {
        this.applicationContext = applicationContext;
    }

    @EventListener(ContextRefreshedEvent.class)
    public void scanForSteps() {
        this.registry.clear();
        // Scan all beans to find methods annotated with step definitions
        String[] beanNames = applicationContext.getBeanDefinitionNames();
        for (String beanName : beanNames) {
            Object bean = applicationContext.getBean(beanName);
            // Avoid proxy issues if possible, though simple reflection works on beans
            Class<?> clazz = bean.getClass();
            // Handle CGLIB proxies
            if (clazz.getName().contains("$$")) {
                clazz = clazz.getSuperclass();
            }

            for (Method method : clazz.getDeclaredMethods()) {
                StepMetadata metadata = StepMetadata.builder().build();
                boolean hasStepAnnotation = false;

                if (method.isAnnotationPresent(ActionStep.class)) {
                    ActionStep annotation = method.getAnnotation(ActionStep.class);

                    List<StepMetadata.StepParameter> params = new ArrayList<>();
                    for (Parameter p : method.getParameters()) {
                        params.add(StepMetadata.StepParameter.builder()
                                .name(p.getName())
                                .type(p.getType().getSimpleName().toUpperCase())
                                .build());
                    }

                    metadata.setKey(clazz.getSimpleName() + "." + method.getName());
                    metadata.setName(annotation.name());
                    metadata.setDescription(annotation.description());
                    metadata.setCategory(annotation.category());
                    metadata.setParameters(params);
                    hasStepAnnotation = true;
                }

                if (hasStepAnnotation && method.isAnnotationPresent(Given.class)) {
                    Given givenAnnotation = method.getAnnotation(Given.class);
                    metadata.setKeyword("Given");
                    metadata.setPattern(givenAnnotation.value());
                }

                if (hasStepAnnotation && method.isAnnotationPresent(When.class)) {
                    When whenAnnotation = method.getAnnotation(When.class);
                    metadata.setKeyword("When");
                    metadata.setPattern(whenAnnotation.value());
                }

                if (hasStepAnnotation && method.isAnnotationPresent(Then.class)) {
                    Then thenAnnotation = method.getAnnotation(Then.class);
                    metadata.setKeyword("Then");
                    metadata.setPattern(thenAnnotation.value());
                }

                // Only add to registry if the method has at least one step annotation
                if (hasStepAnnotation) {
                    registry.add(metadata);
                }
            }
        }
    }

    public List<StepMetadata> getAllSteps() {
        return registry;
    }

    public Map<String, List<StepMetadata>> getStepsByCategory() {
        return registry.stream()
                .filter(metadata -> metadata.getCategory() != null)
                .collect(Collectors.groupingBy(StepMetadata::getCategory));
    }
}
