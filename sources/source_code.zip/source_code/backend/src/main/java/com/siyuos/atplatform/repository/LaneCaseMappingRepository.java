package com.siyuos.atplatform.repository;

import com.siyuos.atplatform.domain.LaneCaseMapping;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface LaneCaseMappingRepository extends JpaRepository<LaneCaseMapping, UUID> {
    List<LaneCaseMapping> findByLaneIdOrderByOrderIndex(UUID laneId);

    void deleteByLaneId(UUID laneId);

    void deleteByTestCaseId(UUID testCaseId); // 当原 Case 被删除时清理引用

    long countByLaneId(UUID laneId);
}
